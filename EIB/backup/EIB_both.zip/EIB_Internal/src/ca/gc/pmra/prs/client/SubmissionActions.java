package ca.gc.pmra.prs.client;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;

/**
 * Provides functionality for all the commands that may be invoked by the user
 * using the menu bar items, tool bar buttons or the menu item shortcuts and
 * accelerators.
 * 
 * @author Teddy Mihail tmihail@newbook.com
 */
public class SubmissionActions implements ActionListener {
	/** ActionListener executing all commands; a singleton. */
	private static SubmissionActions sa = null;

	/** Stores the last directory visited during a file chose operation. */
	private static File lastDirOpen = null;

	/**
	 * Get a pointer to the SubmissionActionListener instance. <br>
	 * It creates one if needed.
	 */
	public static SubmissionActions getSubmissionActionListener() {
		if (sa == null) {
			sa = new SubmissionActions();
		}

		return sa;
	}

	public static void setLastDirOpen(File dir) {
		lastDirOpen = dir;
	}

	public static File getLastDirOpen() {
		return lastDirOpen;
	}

	/**
	 * The method called when an Action Event occurs on one of the objects using
	 * this listener. <br>
	 * The commands are selected based on their names. The command names are
	 * defined in the {@link CommandNames}class. Each command is executed.
	 * 
	 * @param e
	 *            the ActionEvent that triggers the command
	 */
	public void actionPerformed(ActionEvent e) {

		String command = e.getActionCommand();

		if (command.equalsIgnoreCase(CommandNames.EXIT)) {
			doExit();
		} else if (command.equalsIgnoreCase(CommandNames.ABOUT)) {
			doAbout();
		} else if (command.equalsIgnoreCase(CommandNames.NEW_SUBMISSION)) {
			doNew();
		} else if (command.equalsIgnoreCase(CommandNames.IMPORT)) {
			doImport();
		} else if (command.equalsIgnoreCase(CommandNames.CLOSE_SUBMISSION)) {
			doCloseSubmission();
		} else if (command.equalsIgnoreCase(CommandNames.SHOW_HIDE_DETAILS)) {
			doShowHideDetails();
		} else if (command.equalsIgnoreCase(CommandNames.ADD_ENTRY)) {
			doAddRow();
		} else if (command.equalsIgnoreCase(CommandNames.INSERT_ENTRY)) {
			doInsertRow();
		} else if (command.equalsIgnoreCase(CommandNames.REMOVE_ENTRY)) {
			doRemoveRow();
		} else if (command.equalsIgnoreCase(CommandNames.COPY_ENTRY)) {
			doCopyRow();
		} else if (command.equalsIgnoreCase(CommandNames.SAVE_SUBMISSION)) {
			doSave();
		} else if (command.equalsIgnoreCase(CommandNames.OPEN_SUBMISSION)) {
			doOpen();
		} else if (command.equalsIgnoreCase(CommandNames.SAVEAS_SUBMISSION)) {
			doSaveAs();
		} else if (command.equalsIgnoreCase(CommandNames.FINALIZE_SUBMISSION)) {
			doFinalize();
		} else if (command.equalsIgnoreCase(CommandNames.VALIDATE_SUBMISSION)) {
			doValidate();
		} else if (command.equalsIgnoreCase(CommandNames.PREFERENCE)) {
			doPreference();
		} else if (command.equalsIgnoreCase(CommandNames.CHECK_UPDATES)) {
			doCheckUpdate();
		} else if (command.equalsIgnoreCase(CommandNames.HELP)) {
			doHelp();
		} else {
			doNotImplemented(command);
		}

		SubmissionMenuBar.checkMenuItem();
		SubmissionToolBar.checkButton();
	}

	/**
	 * <code>Switch language</code> command implementation.
	 */
	public void doPreference() {

		Preference.showPreference();
	}

	/**
	 * <code>Exit</code> command implementation.
	 */
	public void doExit() {
		if (!checkIsModified()) {
			return;
		}
		System.exit(0);
	}

	/**
	 * <code>About</code> command implementation. <br>
	 * Shows a dialog box with information about the version and build number of
	 * the application.
	 */

	/**
	 * Original code with unselectable build version text
	 * 
	 * private void doAbout() {
	 * JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(),
	 * *Resources.getString("about.message", Version.getVersion(),
	 * Version.getBuild()), *Resources.getString("about.box.title", Resources
	 * .getString("app.name")), JOptionPane.PLAIN_MESSAGE); }
	 */

	/*
	 * new code to display selectable text in the message box shoing build
	 * version - DS
	 */

	private void doAbout() {

		JTextArea textAreaAbout = new JTextArea(Resources.getString("about.message", Version.getVersion(), Version.getBuild()));
		textAreaAbout.setSize(600, 400);
		textAreaAbout.setEditable(false);
		textAreaAbout.setBackground((new JLabel()).getBackground());
		textAreaAbout.setFont((new JLabel()).getFont());
		
		
		JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(),textAreaAbout, Resources.getString("about.box.title", Resources.getString("app.name")), JOptionPane.PLAIN_MESSAGE);
	}

	/**
	 * <code>New</code> command implementation.
	 */
	private void openSubmission() {

		// Remove the index table and its index data
		SubmissionBuilder.removeIndex();
		// Reset the coding information in resources
		Resources.resetCoding();

		// Set the label showing the that we have a new submission
		SubmissionBuilder.setFrameTitle(Resources.getString("app.title",
				Resources.getString("index.label.newsubmission")));

		// Add the empty submission data and its empty table
		SubmissionBuilder.newIndex();

	}

	/**
	 * <code>Close</code> command implementation.
	 */
	private void doCloseSubmission() {
		// check if the current e-index is modified
		if (!checkIsModified()) {
			return;
		}

		// Close the details view, if open
		if (SubmissionBuilder.getDetailsPane() != null) {
			SubmissionBuilder.removeDetailsPane();
		}

		// Remove the index table and its index data
		SubmissionBuilder.removeIndex();
		// Reset the coding information in resources
		Resources.resetCoding();
		// Set the label showing that no index is open
		SubmissionBuilder.setFrameTitle(Resources.getString("app.name"));
		SubmissionBuilder.setOpenFileName(null);
	}

	/**
	 * <code>Show/Hide Details</code> command implementation.
	 */
	private void doShowHideDetails() {
		if (SubmissionBuilder.getDetailsPane() == null) {
			// add the details pane on the GUI
			SubmissionBuilder.addDetailsPane();
		} else {
			// remove the details pane from the GUI
			SubmissionBuilder.removeDetailsPane();
		}
	}

	/**
	 * <code>Add</code> command implementation. <br>
	 * Adds a row in the index table and adds a new record in the internal
	 * representation if the e-index, at the end of the e-index.
	 */
	private void doAddRow() {
		SubmissionData data = SubmissionBuilder.getIndexData();
		if (data != null) {
			data.addEntry();
		}
		SubmissionTable table = SubmissionBuilder.getIndexTable();
		if (table != null) {
			table.addRow();
		}

		// if the new entry is the first, show detail
		if (SubmissionBuilder.getDetailsPane() == null
				&& SubmissionBuilder.getIndexData().getNumberOfEntries() == 1) {
			SubmissionBuilder.addDetailsPane();
		}
	}

	/**
	 * <code>Insert</code> command implementation. <br>
	 * Adds a row in the index table and adds a new record in the internal
	 * representation if the e-index, above the selected record (row).
	 */
	private void doInsertRow() {
		SubmissionTable table = SubmissionBuilder.getIndexTable();
		if (table == null) {
			return;
		}

		SubmissionData data = SubmissionBuilder.getIndexData();
		int position = table.getSelectedRow();

		if (data != null && position != -1) {
			data.insertEntry(position);
		}
		if (table != null) {
			table.insertRow(position);
		}
	}

	/**
	 * <code>Insert</code> command implementation. <br>
	 * Adds a row in the index table and adds a new record in the internal
	 * representation if the e-index, above the selected record (row).
	 */
	private void doCopyRow() {
		SubmissionTable table = SubmissionBuilder.getIndexTable();
		if (table == null) {
			return;
		}

		SubmissionData data = SubmissionBuilder.getIndexData();
		if (data == null || data.getNumberOfEntries() == 0) {
			return;
		}

		int position = table.getSelectedRow();
		if (position == -1) {
			return;
		}

		data.copyEntry(position, position);
		data.modifyValue(position + 1, IndexEntry.FILELOCATION, "");
		data.modifyValue(position + 1, IndexEntry.FILENAME, "");

		data.modifyValue(position + 1, IndexEntry.PMRA_DOC_NO, "");
		data.modifyValue(position + 1, IndexEntry.APP_NO, "");

		data.modifyValue(position + 1, IndexEntry.CROSS_REF, "");
		data.modifyValue(position + 1, IndexEntry.CONFIDENTIAL, "");
		data.modifyValue(position + 1, IndexEntry.APPLICANT_DER, "");

		data.modifyValue(position + 1, IndexEntry.DOX_MD29, "");

		// if cross refrence is NOT yes, set confidential to not selected.
		// if cross refrence is yes, carry confidential value.
		//String cross = (String) data.getEntry(position +
		// 1).getValue(SubmissionData.CROSS_REF);
		//if ( cross == null || !cross.equalsIgnoreCase("Y")) {
		//    data.modifyValue(position + 1, SubmissionData.CONFIDENTIAL, "");
		//}

		String dox_md28 = data.getEntry(position + 1).getValue(
				IndexEntry.DOX_MD28);
		if (dox_md28 != null && dox_md28.trim().length() > 0) {
			data.modifyValue(position + 1, IndexEntry.DOX_MD29, dox_md28);
			data.modifyValue(position + 1, IndexEntry.DOX_MD28, "");
			data.modifyValue(position + 1, IndexEntry.CONFIDENTIAL, "");
		}

		table.copyRow(position + 1);
	}

	/**
	 * <code>Remove</code> command implementation. <br>
	 * Removes the selected row from the index table and the corresponding
	 * record from the internal representation of the e-index.
	 */
	private void doRemoveRow() {

		SubmissionTable table = SubmissionBuilder.getIndexTable();
		SubmissionData data = SubmissionBuilder.getIndexData();
		if (data != null && table != null && data.getNumberOfEntries() > 0) {
			int position = -1;
			position = table.getSelectedRow();
			if (position != -1) {

				if (!SubmissionBuilder.getIndexData().isEmpty(position)) {
					int confirm = Utils.showAskDelete();
					if (confirm != JOptionPane.YES_OPTION) {
						return;
					}
				}

				data.removeEntry(position);
				table.removeSelectedRow(position);
			}
		}
	}

	/**
	 * <code>Save</code> command implementation. <br>
	 * Save the currently open e-index in the XML file from where it was open.
	 * <br>
	 * If we have a new e-index, it asks the user to choose a file name and
	 * location.
	 * 
	 * @return boolean -<code>true</code> is success, <code>false</code> if
	 *         fail.
	 */
	private boolean doSave() 
	{
		String openFileName = SubmissionBuilder.getOpenFileName();
		
		if (openFileName == null) 
			return doSaveAs();
		
		SubmissionData data = SubmissionBuilder.getIndexData();
		
		try 
		{
			data.saveAsXML(openFileName);
			data.setModified(false);
			return true;
		} 
		catch (Exception e) 
		{
			e.printStackTrace(System.out);
			return false;
		}
	}

	/**
	 * <code>Save As</code> command implementation. <br>
	 * Asks the user to choose a file name and location where to save the
	 * currently open e-index.
	 * 
	 * @return boolean -<code>true</code> is success, <code>false</code> if
	 *         fail.
	 */
	private boolean doSaveAs() {
		SubmissionData data = SubmissionBuilder.getIndexData();
		
		if (data == null) 
			return true;
		
		try 
		{
			String fileName = null;
			String fullFileName = null;
			//boolean saved = false;

			Utils.FileChooserAutoExtention fc = new Utils.FileChooserAutoExtention(lastDirOpen, Constants.E_INDEX_FILE_EXT);
			fc.setDialogTitle(Resources.getString("saveas.dialog.title"));
			int returnVal = fc.showSaveDialog(SubmissionBuilder.getAppFrame());
			lastDirOpen = fc.getCurrentDirectory();
			
			if (returnVal != JFileChooser.APPROVE_OPTION) 
				return false;

			fileName = fc.getSelectedFileAutoExtension();
			//fileName = check_Characters(fc.getSelectedFileAutoExtension());			
			//if(fileName==null)
				//return false;			
			
			// must end with .xml
			if (fileName != null && !fileName.trim().toUpperCase().endsWith(".XML"))
				fileName = fileName + ".xml";
			
			fullFileName = lastDirOpen + File.separator + fileName;
			
			if ((new File(fullFileName)).exists()) 
			{
				int ret = Utils.showAskFileExists(fullFileName);
				
				if (ret == JOptionPane.NO_OPTION || ret == JOptionPane.CLOSED_OPTION) 
					return false;
			}
		
			SubmissionBuilder.setOpenFileName(fullFileName);
			SubmissionBuilder.setFrameTitle(Resources.getString("app.title", fileName));
			data.saveAsXML(SubmissionBuilder.getOpenFileName());
			data.setModified(false);

			return true;
		} 
		catch (Exception e) 
		{
			e.printStackTrace(System.out);
			return false;
		}
	}
	
	/* TODO
	 * move this method to one common spot. Remove multiple same methods
	 */
	/*private String check_Characters(String str)
	{
        if( str != null)
        {  
        	// check for special characacters 
        	//char[] specialCharacters = {'\'', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',  '�', 
        			//'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�' ,'�'};

        	char[] specialCharacters = {'\'','�','�','�','�','�','�','�','�','�','�','�','�'
        	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
        	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
        	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'
        	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'};       	
        	
        	if( specialCharacters != null ) 
            {
            	StringBuffer tmpStr = new StringBuffer("");
                for( int i=0; i<str.length(); i++ ) 
                {
                	char c = str.charAt(i);
                    boolean found = false;

                    for( int j=0; j<specialCharacters.length; j++ ) 
                    {
                    	if( c == specialCharacters[j] ) 
                    	{
                    		found = true;
                    		String warningString = "\t" + Resources.getString("saveas.special.char.err", String.valueOf(c)) + "\n";
							JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.ERROR_MESSAGE);
                            //break;
                    		return null;
                        }
                    } 
                    
                    if( !found ) 
                        tmpStr.append(c); 
                }
                    
                str = tmpStr.toString();
            }
        }	
        return str;
	}*/
	
	/**
	 * <code>Open</code> command implementation. <br>
	 * Presents the user with a file finder dialog to chose what file to open.
	 */
	
	/* ---------------------------------------------------------------------------------
	 * March 2011 for internal version 
	 * 
	 * Change the accessory from private to public for implementing opening a new form
	 * after application started  
	 */
	//private void doNew() {
	// to
	public void doNew() {
	//-----------------------------------------------------------------------------------
		// check if the current e-index is modified
		if (!checkIsModified()) {
			return;
		}

		// If the command was originated from the user
		// (menu item or tool bar button) ask the user to select
		// an encoding schema
		
		//March 2011 for internal version
		//set the encode to PMRA
		int selected = Constants.CODING_DACO;
		
		//------------------------------------------------------
		//March 2011 Commented for internal version
		//
		/*int selected = Utils.showSelectEncoding();
		if (selected == JOptionPane.CANCEL_OPTION
				|| selected == JOptionPane.CLOSED_OPTION) {

			return;
		}*/
		//-----------------------------------------------------
		SubmissionBuilder.setCodingStandard(selected);

		openSubmission();

		//------------------------------------------------------
		//March 2011 for internal version
		//add an row
		SubmissionBuilder.setOpenFileName(null);
		doAddRow();
		//-------------------------------------------------------
	}

	/**
	 * <code>Import</code> command implementation. <br>
	 * Imports an index XML file into an existing application. The content of
	 * the file is appended to the submission table of the existing application.
	 */
	private void doImport() {
		// Get the submission data and the index table objects
		SubmissionData data = SubmissionBuilder.getIndexData();
		SubmissionTable table = SubmissionBuilder.getIndexTable();
		IndexEntry entry;
		
		String fileName = null;
		String fullFileName = null;

		// Set up the filechooser
		JFileChooser fc = new JFileChooser(lastDirOpen);
		fc.setDialogTitle(Resources.getString("open.import.title"));
		
		FileFilter currentFileFilter = fc.getFileFilter();
		fc.removeChoosableFileFilter(currentFileFilter);
		
		// XML files only
		ExtFileFilter exff = new ExtFileFilter();
		exff.addExtention(Constants.E_INDEX_FILE_EXT);
		fc.addChoosableFileFilter(exff);
		
		int returnVal = fc.showOpenDialog(SubmissionBuilder.getAppFrame());
		if (returnVal != JFileChooser.APPROVE_OPTION) {
			return;
		}
		
		if(!fc.getSelectedFile().exists()){
			JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), Resources.getString("file.open.notexist", fc.getSelectedFile().getName()), "alert", JOptionPane.ERROR_MESSAGE);
			doImport();
			return;
		}
		
		//For the calculation of total numbers of rows before and after the import
		int initialNumOfRows = 0;
		int totalNumOfRows = 0;
		int addedNumOfRows = 0;		
		
		// Get the file
		fileName = fc.getSelectedFile().getName();
		lastDirOpen = fc.getCurrentDirectory();
		fullFileName = lastDirOpen + File.separator + fileName;
		
		data = SubmissionBuilder.getIndexData();
		initialNumOfRows = data.getNumberOfEntries();
		
		try {
			// Read and process input from XML file
				// SubmissionBuilder.setOpenFileName(fullFileName);
				//String imported = Resources.getString("file.import.imported");
			
				if (data != null) {
					data.is_import = true;
					data.readFromXML(fullFileName);
					data.setModified(true);
					data.is_import = false;
				}
				
				totalNumOfRows = data.getNumberOfEntries();
				
				for (int i = 0; i < data.getNumberOfEntries(); i++) {
					table.addRow();
					entry = data.getEntry(i);
					
					for (int j = 0; j < entry.getSize(); j++) {
						if (entry.getTableColumnNumber(j) > -1) {
							table.setCellStringAt(entry.getValue(j), i, entry
									.getTableColumnNumber(j));
						}
					}
				}
				
				// Update the content of the table
				table.refreshTable();
				
				if (SubmissionBuilder.getDetailsPane() == null) {
					SubmissionBuilder.addDetailsPane();
				}
				
				table.setRefreshing(false);

				//Display a message with the numeber of imported rows				
				addedNumOfRows = totalNumOfRows - initialNumOfRows;
				
				if (addedNumOfRows > 0)
				javax.swing.JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), Resources.getString("file.import.beginmessage")  + 
						" " + addedNumOfRows + " " + Resources.getString("file.import.endmessage"));
				
		} catch (Exception e) {
			// e.printStackTrace(System.out);
		} finally {
			Cursor cursor = ((Component) SubmissionBuilder.getAppFrame())
			.getCursor();
			((Component) SubmissionBuilder.getAppFrame()).setCursor(cursor);
		}
	}

	/**
	 * <code>Open</code> command implementation. <br>
	 * Presents the user with a file finder dialog to chose what file to open.
	 */
	private void doOpen() {
		SubmissionData data = SubmissionBuilder.getIndexData();
		Cursor cursor = ((Component) SubmissionBuilder.getAppFrame()).getCursor();

		try 
		{
			if (!checkIsModified())
				return;
			
			String fileName = null;
			String fullFileName = null;
			
			JFileChooser fc = new JFileChooser(lastDirOpen);
			fc.setDialogTitle(Resources.getString("open.dialog.title"));
			fc.removeChoosableFileFilter(fc.getFileFilter());
			//fc.addChoosableFileFilter(new AllFileFilter());
			ExtFileFilter exff = new ExtFileFilter();
			exff.addExtention(Constants.ZIP_FILE_EXT);
			exff.addExtention(Constants.E_INDEX_FILE_EXT);
			fc.addChoosableFileFilter(exff);
			int returnVal = fc.showOpenDialog(SubmissionBuilder.getAppFrame());

			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}
			
			if(!fc.getSelectedFile().exists()){
				//fc.getSelectedFile().getName()
				JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), Resources.getString("file.open.notexist", fc.getSelectedFile().getName()), "alert", JOptionPane.ERROR_MESSAGE);
				doOpen();
				return;
			}
			
			if (fc.getSelectedFile().getName().endsWith(Constants.ZIP_FILE_EXT)){
				
		        Object[] options = { Resources.getString("string.ok"),
                        			 Resources.getString("string.cancel") };
				
        		//int replace_file = JOptionPane.showConfirmDialog(SubmissionBuilder.getAppFrame(), Resources.getString("open.existing.prz"), Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.OK_CANCEL_OPTION  );
        		int replace_file = JOptionPane.showOptionDialog(SubmissionBuilder.getAppFrame(),
        				 Resources.getString("open.existing.prz"),
        				 Resources.getString("string.warning"),
        				 JOptionPane.OK_CANCEL_OPTION,
        				 JOptionPane.WARNING_MESSAGE,
        				 null,
        				 options,
        				 Resources.getString("string.cancel"));

        		if (replace_file!=0)
        			return;				
			}

			if (data != null) 
			{
				// Remove the index table and its index data
				SubmissionBuilder.removeIndex();
			}

			 openSubmission();
			 fileName = fc.getSelectedFile().getName();
			 lastDirOpen = fc.getCurrentDirectory();
			 fullFileName = lastDirOpen + File.separator + fileName;
			 data = SubmissionBuilder.getIndexData();
			 ((Component) SubmissionBuilder.getAppFrame()).setCursor(new Cursor(Cursor.WAIT_CURSOR));
			
			if (fullFileName.endsWith(Constants.ZIP_FILE_EXT)) 
			{				
				SubmissionBuilder.setOpenFileName(null);
				SubmissionBuilder.setPRZOpenFileName(fileName);
				SubmissionBuilder.setFrameTitle(Resources.getString("app.title", fileName));
				SubmissionBuilder.setLastAction(Resources.getString("file.open.name"));
				data.readFromZIP(fullFileName);
			}
			else 
			{
				SubmissionBuilder.setPRZOpenFileName(null);
				SubmissionBuilder.setOpenFileName(fullFileName);
				SubmissionBuilder.setFrameTitle(Resources.getString("app.title", fileName));
				SubmissionBuilder.setLastAction(Resources.getString("file.open.name"));
				data.readFromXML(fullFileName);
			}
			
			//if (data != null) 
			//{
				// Remove the index table and its index data
				//SubmissionBuilder.removeIndex();
			//}
			
			//openSubmission();
			//fileName = fc.getSelectedFile().getName();
			//lastDirOpen = fc.getCurrentDirectory();
			//fullFileName = lastDirOpen + File.separator + fileName;
			//data = SubmissionBuilder.getIndexData();
			//((Component) SubmissionBuilder.getAppFrame()).setCursor(new Cursor(Cursor.WAIT_CURSOR));
			
			//SubmissionBuilder.setFrameTitle(Resources.getString("app.title", fileName));
			//SubmissionBuilder.setLastAction(Resources.getString("file.open.name"));
			//data.readFromZIP(fullFileName);			

			//IndexEntry entry;
			SubmissionTable table = SubmissionBuilder.getIndexTable();
			table.refreshTable();
			/****************************
			 for (int i = 0; i < data.getNumberOfEntries(); i++) {                
			 
			 table.addRow();
			 entry = data.getEntry(i);

			 for (int j = 0; j < entry.getSize(); j++) {
			 if (entry.getTableColumnNumber(j) > -1) {
			 table.setCellStringAt(entry.getValue(j), i, entry.getTableColumnNumber(j));
			 }
			 }
			 }    
			 **********************/
			if (SubmissionBuilder.getDetailsPane() == null) {
				SubmissionBuilder.addDetailsPane();
			}
		} 
		catch (Exception e) 
		{
			//e.printStackTrace();
		} 
		finally
		{
			((Component) SubmissionBuilder.getAppFrame()).setCursor(cursor);
		}
	}

	private void doFinalize() {
		Runnable packProgress = new Runnable() {
			public void run() {
				SubmissionActions.this.pack();
			}
		};

		try {
			Thread packThread = new Thread(packProgress, "packProgress");
			packThread.start();
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	/**
	 * <code>Finalize</code> implementation. <br>
	 * Validates the currently open e-index. If the validation succeeds, all the
	 * files pointed to by the e-index are collected in a temporary directory;
	 * the e-index is also saved in the same directory, as an XML file; and a
	 * ZIP archive is made with all these files. <br>
	 * The user is presented with a file finder dialog so they can select a name
	 * and location for the generated archive. <br>
	 * In the saved e-index file, the name of the archive is given as location
	 * for all files.
	 */
	private void pack() {

		SubmissionData data = SubmissionBuilder.getIndexData();
		// Do nothing if we don't have data
		if (data == null) {
			return;
		}

		// Validate the e-index data
		data.validate();
		String msg = "";

		// Show the validation errors or warnings if existing.
		//
		if (data.getErrorGlobal().length() > 0) {
			msg = data.getErrorGlobal();
			Utils.showReportDialog(Constants.FINALIZE_ERROR_DIALOG, false, msg);
			data.cleanErrors();
			// If we have errors we stop executing Finalize
			return;
		} else if (data.getErrorFields().size() > 0) {
			for (int i = 0; i < data.getErrorFields().size(); i++) {
				msg += data.getErrorEntries().get(i) + "\n"
						+ data.getErrorFields().get(i);
			}
			Utils.showReportDialog(Constants.FINALIZE_ERROR_DIALOG, true, msg);
			data.cleanErrors();
			// If we have errors we stop executing Finalize
			return;
		} else if (data.getWarningGlobal().length() > 0) {
			msg = data.getWarningGlobal();
			int ret = Utils.showReportDialog(Constants.FINALIZE_WARNING_DIALOG, false, msg);
			data.cleanWarnings();
			// If we have warnings the user decides wether to continue
			// finalizing
			
			if (ret != Constants.CONTINUE_FINALIZE) {
				return;
			}
		} else if (data.getWarningFields().size() > 0) {
			for (int i = 0; i < data.getWarningFields().size(); i++) {
				msg += data.getWarningEntries().get(i) + "\n"
						+ data.getWarningFields().get(i);
			}
			int ret = Utils.showReportDialog(Constants.FINALIZE_WARNING_DIALOG,
					true, msg);
			data.cleanWarnings();
			// If we have warnings the user decides wether to continue
			// finalizing
			if (ret != Constants.CONTINUE_FINALIZE) {
				return;
			}
		} 
		else if(data.getEmptyGlobal().length() > 0)
		{
			msg = data.getEmptyGlobal();
			Utils.showReportDialog(Constants.FINALIZE_EMPTY_DIALOG, false, msg);
			data.cleanEmpty();
			return;
		}
		else if (data.getEmptyFields().size() > 0) 
		{
			for (int i = 0; i < data.getEmptyFields().size(); i++) 
			{
				msg += data.getEmptyEntries().get(i)+" "+data.getEmptyFields().get(i);
			}
			Utils.showReportDialog(Constants.FINALIZE_EMPTY_DIALOG, true, msg);
			data.cleanEmpty();
			// If we have errors we stop executing Finalize
			return;
		}

		// Everything is good; we passed the validation.
		// We do the actual packaging of all the files.
		try 
		{
			String sourceFileName;
			
			/*******************************************************************
			 * // first, test for the existance of all the files that are
			 * specified for (int i = 0; i < data.getNumberOfEntries(); i++) {
			 * sourceFileName =
			 * data.getEntry(i).getValue(SubmissionData.FILELOCATION); if
			 * (sourceFileName != null && sourceFileName.length() != 0 && !(new
			 * File(sourceFileName).exists())) { Object[] options = {
			 * Resources.getString("string.stop") };
			 * 
			 * int ret =
			 * JOptionPane.showOptionDialog(SubmissionBuilder.getAppFrame(),
			 * Resources.getString("ask.file.not.found", sourceFileName),
			 * Resources.getString("app.name"), JOptionPane.NO_OPTION,
			 * JOptionPane.ERROR_MESSAGE, null, options,
			 * Resources.getString("string.stop"));
			 * 
			 * return; } }
			 ******************************************************************/

			// The zip file name
			// Ask the user to select a file name and location (similar to save
			// as).
			String zipFileName = null;
			String zipFullFileName = null;
			Utils.FileChooserAutoExtention fc = new Utils.FileChooserAutoExtention(lastDirOpen, Constants.ZIP_FILE_EXT);

			fc.setDialogTitle(Resources.getString("finalize.dialog.title"));
			int returnVal = fc.showSaveDialog(SubmissionBuilder.getAppFrame());
			lastDirOpen = fc.getCurrentDirectory();
			
			if (returnVal != JFileChooser.APPROVE_OPTION) 
				return;

			zipFileName = fc.getSelectedFileAutoExtension();
			zipFullFileName = lastDirOpen + File.separator + zipFileName;

			String eindexFileName = "";
			if (zipFileName.endsWith(Constants.ZIP_FILE_EXT)) 
			{
				eindexFileName = zipFileName.substring(0, zipFileName.length() - Constants.ZIP_FILE_EXT.length()) + Constants.E_INDEX_FILE_EXT;
			} 
			else 
			{
				eindexFileName = zipFileName + Constants.E_INDEX_FILE_EXT;
			}

			String eindexFullFileName = lastDirOpen + File.separator + eindexFileName;
			
			if ((new File(zipFullFileName)).exists()) 
			{
				int ret = Utils.showAskFileExists(zipFullFileName);
				
				if (ret == JOptionPane.NO_OPTION || ret == JOptionPane.CLOSED_OPTION) 
					return;
			}

			if ((new File(eindexFullFileName)).exists()) 
			{
				int ret = Utils.showAskFileExists(eindexFullFileName);
				if (ret == JOptionPane.NO_OPTION || ret == JOptionPane.CLOSED_OPTION) 
					return;
			}

			ProgressDialog progressDialog = new ProgressDialog(SubmissionBuilder.getAppFrame());
			progressDialog.setTitle(Resources.getString("finalize.dialog.title"));
			progressDialog.setSize(new Dimension(400, 200));
			progressDialog.setModal(true);
			progressDialog.start();
			
			progressDialog.setMessage(Resources.getString("finalize.save.xml"));
			progressDialog.sleep();
			if (progressDialog.isCanceled()) 
				return;
			
			// Save the e-index...
			data.saveAsXML(eindexFullFileName);
			
			// Make a temporary directory where all the files are collected
			File tmpDir = File.createTempFile("PRS", null);
			String packDirName = tmpDir.getAbsolutePath();
			tmpDir.delete();
			tmpDir.mkdir();

			// Copy all the files in the newly created directory
			String fileName;
			String destinationFileName;
			
			progressDialog.sleep();
			// now we can collect the files
			for (int i = 0; i < data.getNumberOfEntries(); i++)
			{
				fileName = data.getEntry(i).getValue(IndexEntry.FILENAME);
				sourceFileName = data.getEntry(i).getValue(IndexEntry.FILELOCATION);
				destinationFileName = packDirName + File.separator + fileName;

				if (sourceFileName != null && sourceFileName.length() != 0 && (new File(sourceFileName).exists())) 
				{
					progressDialog.setMessage(Resources.getString("finalize.collect.file", fileName));
					
					progressDialog.sleep();
					if (progressDialog.isCanceled()) 
						return;
					
					Utils.copyFile(sourceFileName, destinationFileName);
					String md5Hash = "";
					try 
					{
						md5Hash = Utils.getHashText(sourceFileName, "MD5");
					} 
					catch (Exception e) 
					{
						Utils.showExceptionDialog(e);
					}
					
					data.getEntry(i).setValue(IndexEntry.CHECKSUM, md5Hash);
				}
			}

			progressDialog.sleep();
			if (progressDialog.isCanceled()) 
				return;			

			/*if(SubmissionBuilder.getOpenFileName()==null)
			{
				SubmissionBuilder.setOpenFileName(eindexFullFileName);
				doSave();
				SubmissionBuilder.setFrameTitle(Resources.getString("app.title", eindexFileName));
			}*/
			
			// Save the eIndex file in this directory
			String eIndexFileName = packDirName + File.separator + Constants.E_INDEX_FILE_NAME;
			data.saveAsXML(eIndexFileName, "");
			
			progressDialog.setMessage(Resources.getString("finalize.zip.file"));			
			
			progressDialog.sleep();
			if (progressDialog.isCanceled()) 
				return;
			
			// Make the zip file
			Utils.zipFiles(packDirName, zipFullFileName);
			
			// Clean the temp directory
			Utils.cleanDirectory(packDirName);

			progressDialog.setMessage(Resources.getString("finalize.file.complete",zipFileName));
			progressDialog.cancelButton.setEnabled(false);
			progressDialog.okButton.setEnabled(true);
		}
		catch (Exception e) 
		{
			e.printStackTrace(System.out);
		}
	}

	/**
	 * <code>Validate</code> implementation. <br>
	 * Check the validity of the data: errors are considered missing of data
	 * from required fields and files not found in the location pointed to by
	 * the e-index entry. <br>
	 * Warnings are shown if data is missing from optional fields, or if no
	 * entry is found in the e-index.
	 */
	private void doValidate() {

		SubmissionData data = SubmissionBuilder.getIndexData();
		// We stop if no data is found
		if (data == null) {
			return;
		}

		// Perform the validation
		data.validate();
		String msg = "";

		// Show the errors or the warnings, if any.
		//
		if (data.getErrorGlobal().length() > 0) {
			msg = data.getErrorGlobal();
			Utils.showReportDialog(Constants.VALIDATION_ERROR_DIALOG, false,
					msg);
		} else if (data.getErrorFields().size() > 0) {
			for (int i = 0; i < data.getErrorFields().size(); i++) {
				msg += data.getErrorEntries().get(i) + "\n"
						+ data.getErrorFields().get(i);
			}
			Utils
					.showReportDialog(Constants.VALIDATION_ERROR_DIALOG, true,
							msg);
		} else if (data.getWarningGlobal().length() > 0) {
			msg = data.getWarningGlobal();
			Utils.showReportDialog(Constants.VALIDATION_WARNING_DIALOG, false,
					msg);
		} else if (data.getWarningFields().size() > 0) {
			for (int i = 0; i < data.getWarningFields().size(); i++) {
				msg += data.getWarningEntries().get(i) + "\n"
						+ data.getWarningFields().get(i);
			}
			Utils.showReportDialog(Constants.VALIDATION_WARNING_DIALOG, true,
					msg);
			data.cleanWarnings();
		} 
		else if (data.getEmptyGlobal().length() > 0) 
		{
			msg = data.getEmptyGlobal();
			Utils.showReportDialog(Constants.VALIDATION_EMPTY_DIALOG, false, msg);
			
		} 
		else if (data.getEmptyFields().size() > 0) 
		{
			msg = (String) data.getEmptyFields().elementAt(0);
			Utils.showReportDialog(Constants.VALIDATION_EMPTY_DIALOG, true, msg);
			data.cleanEmpty();
		}
		else {
			msg = Resources.getString("validation.ok.msg");
			Utils.showReportDialog(Constants.VALIDATION_OK_DIALOG, false, msg);
		}

	}

	/**
	 * Verify if the currently open e-index is modified since open or since last
	 * save. <br>
	 * If it is modified it asks the user to save it.
	 * 
	 * @return - boolean <br>
	 *         <code>true</code> if the data is not modified or if the user
	 *         saved it <br>
	 *         <code>false</code> otherwise
	 */
	private boolean checkIsModified() 
	{
		// Verify if the index has been modified
		// If it has been modified, ask the user if save it
		// If the user says YES, save it
		SubmissionData data = SubmissionBuilder.getIndexData();
		if (data != null && data.isModified()) 
		{
			int ret = Utils.showAskSave();

			if (ret == JOptionPane.CANCEL_OPTION || ret == JOptionPane.CLOSED_OPTION) 
			{
				return false;
			} 
			else if (ret == JOptionPane.YES_OPTION) 
			{
				return doSave();
			}
		}
		return true;
	}

	/**
	 * Check software update
	 */
	private void doCheckUpdate()
	{
		CheckUpgrade.menualCheck();
	}

	/**
	 * help message
	 */
	private void doHelp() {

		JTextArea textArea = new JTextArea(Resources
				.getString("help.box.message"));
		textArea.setEditable(false);
		textArea.setBackground((new JLabel()).getBackground());
		textArea.setFont((new JLabel()).getFont());
		JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(),
				textArea, Resources.getString("help.box.title"),
				JOptionPane.PLAIN_MESSAGE);

	}

	/**
	 * "Executes" all the un-known commands: shows a dialog box telling the user
	 * that the command is not implemented.
	 */
	private void doNotImplemented(String command) {
		JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(),
				Resources.getString("notimpl.message", command), Resources
						.getString("notimpl.box.title", Resources
								.getString("app.name")),
				JOptionPane.PLAIN_MESSAGE);
	}

}