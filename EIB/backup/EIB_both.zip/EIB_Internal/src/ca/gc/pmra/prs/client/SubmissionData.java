package ca.gc.pmra.prs.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Internal data representation. <br>
 * This data structure is used to store the e-index data. <br>
 * At most one instance of the SubmissionData class may exist in the system at
 * any given time. <br>
 * <br>
 * The submission data, also named e-index internal representation, is organized
 * as a Vector of entries. <br>
 * Each entry is organized as a two dimensional array of Strings.
 * 
 * @author Teddy Mihail tmihail@newbook.com
 */
public class SubmissionData 
{
    // This is the submission data
    private Vector indexData = null;

    // Is it modified?
    private boolean modified = false;

    // Is it valid?
    private boolean valid = false;
    public boolean is_import = false;

    // Generated while executing a validation
    private Vector warningEntries = null;

    private Vector warningFields = null;

    private String warningGlobal = null;

    // Generated while validating as part of finalize.
    private Vector errorEntries = null;

    private Vector errorFields = null;

    private String errorGlobal = null;
    
    private Vector emptyEntries = null;

    private Vector emptyFields = null;

    private String emptyGlobal = null;

    //For schema validation
    static private final String SCHEMA_FILE_NAME = "e-index.xsd";
    
    /**
     * Constructor. <br>
     * Initialize all the internal data members.
     */
    public SubmissionData() 
    {
        indexData = new Vector();
        
        warningEntries = new Vector();
        warningFields = new Vector();
        warningGlobal = "";
        
        errorEntries = new Vector();
        errorFields = new Vector();
        errorGlobal = "";
        
        emptyEntries = new Vector();
        emptyFields = new Vector();
        emptyGlobal = "";    
        
    }

    /**
     * Create a new instance of IndexEntry
     * 
     * @return an instance of IndexEntry
     */
    public IndexEntry getEntryInstance() 
    {
        return new IndexEntry();
    }

    /**
     * Get the entire submission data.
     * 
     * @return Vector e-index data
     */
    public Vector getSubmissionData() 
    {
        return indexData;
    }

    // Accessors for data members
    public void setModified(boolean value)
    {
        modified = value;
        valid = false;
    }

    public boolean isModified() 
    {
        return modified;
    }

    public boolean isValid() 
    {
        return valid;
    }

    public Vector getErrorFields() 
    {
        return errorFields;
    }

    public Vector getErrorEntries() 
    {
        return errorEntries;
    }
    
    public String getErrorGlobal() 
    {
        return errorGlobal;
    }    
    
    public Vector getWarningFields() 
    {
        return warningFields;
    }    
    
    public Vector getWarningEntries() 
    {
        return warningEntries;
    }

    public String getWarningGlobal() 
    {
        return warningGlobal;
    }

    public Vector getEmptyFields() 
    {
        return emptyFields;
    }    
    
    public Vector getEmptyEntries() 
    {
        return emptyEntries;
    }

    public String getEmptyGlobal() 
    {
        return emptyGlobal;
    }
    
    public void cleanErrors() 
    {
        errorEntries = new Vector();
        errorFields = new Vector();
        errorGlobal = "";
    }

    public void cleanWarnings() 
    {
        warningEntries = new Vector();
        warningFields = new Vector();
        warningGlobal = "";
    }
    
    public void cleanEmpty() 
    {
        emptyEntries = new Vector();
        emptyFields = new Vector();
        emptyGlobal = "";
    }   

    /**
     * Get an entry.
     * 
     * @param position
     *            index of the entry in the vector
     * 
     * @return IndexEntry the entry
     */
    public IndexEntry getEntry(int position) 
    {
        return (IndexEntry) indexData.get(position);
    }

    /**
     * Add a new, empty entry at the end of the vector.
     * 
     * @return IndexEntry the new empty entry
     */
    public IndexEntry addEntry() 
    {
        IndexEntry e = new IndexEntry();
        indexData.add(e);
        setModified(true);
        return e;
    }

    /**
     * Add an entry at the end of the vector.
     * 
     * @param newEntry
     *            entry to be added
     * 
     * @return IndexEntry the entry that has been added
     */
    public IndexEntry addEntry(IndexEntry newEntry) 
    {
        indexData.add(newEntry);
        setModified(true);
        return newEntry;
    }

    /**
     * Insert a new, empty entry at the given index in the vector.
     * 
     * @param position
     *            index for the new entry in the vector
     * 
     * @return IndexEntry the new empty entry
     */
    public IndexEntry insertEntry(int position) 
    {
        IndexEntry e = new IndexEntry();
        indexData.add(position, e);
        setModified(true);
        return e;
    }

    /**
     * Copy an entry at the given index in the vector.
     * 
     * @param source
     *            index for the source entry in the vector
     * 
     * @param dest
     *            index for the new entry in the vector
     * 
     * @return IndexEntry the new empty entry
     */
    public IndexEntry copyEntry(int source, int dest)
    {
        IndexEntry e1 = new IndexEntry();

        IndexEntry e = getEntry(source);
        if (e != null) {
            e1 = (IndexEntry) e.clone();
        }
        indexData.add(dest + 1, e1);
        setModified(true);
        return e;
    }

    /**
     * Insert an entry at the given index in the vector.
     * 
     * @param position
     *            index for the new entry in the vector
     * @param newEntry
     *            entry to be added
     * 
     * @return IndexEntry the new entry
     */
    public IndexEntry insertEntry(int position, IndexEntry newEntry) 
    {
        indexData.add(position, newEntry);
        setModified(true);
        return newEntry;
    }

    /**
     * Remove an entry from the given index in the vector.
     * 
     * @param position
     *            index of the entry to be removed from the vector
     */
    public void removeEntry(int position) 
    {
        indexData.remove(position);
        setModified(true);
    }

    /**
     * Move the entry from <code>position</code> to <code>position-1</code>
     * in the vector.
     * 
     * @param position
     *            initial index of the entry in the vector
     * 
     * @return IndexEntry - the entry that has been moved
     */
    public IndexEntry moveUpEntry(int position) 
    {
        IndexEntry e = (IndexEntry) indexData.get(position);
        indexData.remove(position);
        indexData.add(position - 1, e);
        setModified(true);
        return e;
    }

    /**
     * Move the entry from <code>position</code> to <code>position+1</code>
     * in the vector.
     * 
     * @param position
     *            initial index of the entry in the vector
     * 
     * @return IndexEntry - the entry that has been moved
     */
    public IndexEntry moveDownEntry(int position) 
    {
        IndexEntry e = (IndexEntry) indexData.get(position);
        indexData.remove(position);
        indexData.add(position + 1, e);
        setModified(true);
        return e;
    }

    /**
     * Modify the value of the specified filed in the specified entry.
     * 
     * @param entryPosition
     *            index of entry in the vector
     * @param fieldNb
     *            field of the entry to be modified
     * @param value
     *            the new value for the field
     * 
     * @return IndexEntry - the entry that has been modified
     */
    public IndexEntry modifyValue(int entryPosition, int fieldNb, String value) 
    {
        IndexEntry newEntry = (IndexEntry) indexData.get(entryPosition);
        
        if(!newEntry.getValue(fieldNb).equals(value))
        {
        	newEntry.setValue(fieldNb, value);
            setModified(true);        	
        }
        //newEntry.setValue(fieldNb, value);
        indexData.setElementAt(newEntry, entryPosition);
        //setModified(true);
        return newEntry;
    }

    /**
     * Get the size (number of entries) of the e-index.
     * 
     * @return size of the e-index
     */
    public int getNumberOfEntries() 
    {
        return indexData.size();
    }

    public boolean isEmpty(int entryPosition) 
    {
        IndexEntry entry = (IndexEntry) indexData.get(entryPosition);

        for (int entryField = 0; entryField < entry.getSize(); entryField++) 
        {
            String entryValue = entry.getValue(entryField);
            
            if (entryValue.length() != 0) 
                return false;
        }
        return true;
    }
    
    /**
     * Validate the e-index. <br>
     * The entries that are not valid and the validation errors and/or warnings
     * are stored in the appropriate vectors of strings. These are subsequently
     * used to build the diagnostic message(s) displayed to the user.
     */
    public void validate() 
    {
        // clean messages
        cleanErrors();
        cleanWarnings();

        // Set valid to true
        valid = true;
    
        IndexEntry entry;
        String entryValue;
        boolean entryError = false;
        boolean entryWarning = false;
        boolean entryEmpty = false;
        
        String errorString = "";
        String warningString = "";
        String emptyString = "";

        final String leftIndent = "\t";
        final String emptyField = Resources.getString("validation.mandatory_filed");

        /*if (getNumberOfEntries() == 0) 
        {
            warningGlobal = Resources.getString("validation.warning.noentries");
            return;
        }*/
 
        if (getNumberOfEntries() == 0)
        {
            valid = false;
            entryEmpty = true;

            emptyString += leftIndent + Resources.getString("validation.warning.noentries") + "\n";
            
            emptyEntries.add(" ");
            emptyFields.add(emptyString);  
        }
        else
        {
	        for (int entryCount = 0; entryCount < getNumberOfEntries(); entryCount++) 
	        {
	            entry = getEntry(entryCount);
	            entryError = false;
	            entryWarning = false;
	            errorString = "";
	            warningString = "";
	 
	            
	            if (entry.getValue(IndexEntry.DOX_MD28) != null && entry.getValue(IndexEntry.DOX_MD28).length() > 0) 
	            {
	                if (entry.getValue(IndexEntry.CONFIDENTIAL).length() == 0) 
	                {
	                    valid = false;
	                    entryError = true;
	                    errorString += leftIndent + emptyField + Resources.getString("field.confidential") + "\n";
	                }
	            }
	            else
	            { 	
		            // first, there is no file name duplicate of all the files that are
		            // specified
		            String sourceFileName1 = entry.getValue(IndexEntry.FILENAME);
		            
		            //System.out.println("sourceFileName1 = "+sourceFileName1);
		            
		            
		            if (sourceFileName1 != null && sourceFileName1.length() != 0) 
		            {
		                for (int j = entryCount + 1; j < getNumberOfEntries(); j++) 
		                {
		                    String sourceFileName2 = getEntry(j).getValue(IndexEntry.FILENAME);
		
		                    if (sourceFileName2 != null && sourceFileName2.length() != 0 && sourceFileName1.equalsIgnoreCase(sourceFileName2)) 
		                    {
		                        valid = false;
		                        entryError = true;
		                        errorString += leftIndent + Resources.getString("validation.file.name.duplicate", sourceFileName1, String.valueOf(j + 1)) + "\n";
		                    }
		                }
		            }
	
		            // second, test for the existence of all the files that are
		            // specified
		            String sourceFileName2 = entry.getValue(IndexEntry.FILELOCATION);
		            if (sourceFileName2 != null && sourceFileName2.length() != 0 && !(new File(sourceFileName2).exists())) 
		            {
		                valid = false;
		                entryError = true;
		                	
		                errorString += leftIndent + Resources.getString("validation.file.not.found", sourceFileName2) + "\n";
		            } 
		            else if ((sourceFileName2 == null || sourceFileName2.length() == 0) &&
		            		(entry.getValue(IndexEntry.FILENAME) != null &&
		            		entry.getValue(IndexEntry.FILENAME).length() != 0)) 
		            {
		            	
		                valid = false;
		                entryError = true;
		                errorString += leftIndent + Resources.getString("validation.file.not.found", entry.getValue(IndexEntry.FILENAME)) + "\n";
		                
		                //If the file we are validating is a PRZ file, do not display an error for the file location.
		                if (SubmissionBuilder.getOpenPRZFileName() != null)
		                {  
		                	valid = true;
		                	entryError = false;  //Or attempt to get it from the XML file
		                 }
		            }
	
		            for (int entryField = 0; entryField < entry.getSize(); entryField++) 
		            {
		                entryValue = entry.getValue(entryField);
		                switch (entryField) 
		                {
			                case IndexEntry.DOCID:
			                    if (entryValue.length() == 0) 
			                    {
			                        valid = false;
			                        entryError = true;
			                        errorString += leftIndent + emptyField + Resources.getString("field.docid") + "\n";
			                    }
			                    break;
			                case IndexEntry.CONFIDENTIAL:
			                    if (entryValue.length() == 0) 
			                    {
			                        valid = false;
			                        entryError = true;
			                        errorString += leftIndent + emptyField + Resources.getString("field.confidential") + "\n";
			                    }
			                    break;
		                    	//-----------------------------------------------------------
		                    	//March 2011 for internal version
		                    	//commented below
			                    /*
			                case IndexEntry.APPLICANT_DER:
			                    if (entryValue.length() == 0) 
			                    {
			                        
			                    	valid = false;
			                        entryError = true;
			                        errorString += leftIndent + emptyField + Resources.getString("field.applicant_der") + "\n";
			                    }
			                    break; */
			                    //-------------------------------------------------------------
			                case IndexEntry.CROSS_REF:
			                    if (entryValue.length() == 0) 
			                    {
			                        valid = false;
			                        entryError = true;
			                        errorString += leftIndent + emptyField + Resources.getString("field.cross_ref") + "\n";
			                    }
			                    break;
			                    
			                case IndexEntry.DOX_MD36:
			                	if(entryValue.length()>0 && entryValue.length()<3){
				                      valid = false;
			                          entryError = true;
			                          errorString += leftIndent + emptyField + Resources.getString("validation.docOwner.fieldLength") + "\n";
			                	}	
			                	break;    
			                
			                case IndexEntry.PMRA_DOC_NO:
			                    if (entry.getValue(IndexEntry.CROSS_REF) != null && entry.getValue(IndexEntry.CROSS_REF).equalsIgnoreCase("Y")) 
			                    {
			                        if (entryValue.length() == 0) 
			                        {
			                            entryWarning = true;
			                            warningString += leftIndent + Resources.getString("field.pmra_doc_number") + "\n";
			                        }
			                    }
			                    break;
			                case IndexEntry.APP_NO:
			                    if (entry.getValue(IndexEntry.CROSS_REF) != null && entry.getValue(IndexEntry.CROSS_REF).equalsIgnoreCase("Y")) 
			                    {
			                        if (entryValue.length() == 10) 
			                        {
			                            if (entryValue.indexOf(" ") < 1 && entryValue.indexOf(" ") != -1) 
			                            {
			                                valid = false;
			                                entryError = true;
			                                errorString += leftIndent + emptyField + Resources.getString("field.app_number") + "\n";
			                            }
			                        } 
			                        else if (entryValue.trim().length() <= 1) 
			                        {
			                            entryWarning = true;
			                            warningString += leftIndent + Resources.getString("field.app_number") + "\n";
			                        } 
			                        else 
			                        {
			                            valid = false;
			                            entryError = true;
			                            errorString += leftIndent + emptyField + Resources.getString("field.app_number") + "\n";
			                        }
			                    }
			                    break;
			                case IndexEntry.FILELOCATION:
			                    if (entry.getValue(IndexEntry.CROSS_REF) != null && !entry.getValue(IndexEntry.CROSS_REF).equalsIgnoreCase("Y")) 
			                    {
			                        if (entryValue.length() == 0) 
			                        {
			                            entryWarning = true;
			                            warningString += leftIndent + Resources.getString("field.filelocation") + "\n";
			                        } 
			                        else if (entryValue.length() > 0) 
			                        {
			                            File f = new File(entryValue);
			                            if (!f.exists()) 
			                            {
			                                entryWarning = true;
			                                warningString += leftIndent + Resources.getString("validation.file_not_found") + entryValue + "\n";
			                            }
			                        }
			                    }
			                    break;
			                case IndexEntry.AUTHOR:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.author") + "\n";
			                    }
			                    break;
			                case IndexEntry.TITLE:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.title") + "\n";
			                    }
			                    break;
			                case IndexEntry.LABNAME:
			                    if (entryValue.length() == 0)
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.labname") + "\n";
			                    }
			                    break;
			                case IndexEntry.REPORTNB: // Lab report number
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.reportnb") + "\n";
			                    }
			                    break;
			                case IndexEntry.REPORT_NUMBER:
			                    if (entryValue.length() == 0)
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.report_number") + "\n";
			                    }
			                    break;
			                case IndexEntry.REPORTDATE:
			                    if (entryValue.length() == 0)
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.reportdate") + "\n";
			                    }
			                    break;
			                case IndexEntry.NOPAGES:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.nopages") + "\n";
			                    }
			                    break;
			                case IndexEntry.EPAMRIDNO:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.epamridno") + "\n";
			                    }
			                    break;
			                case IndexEntry.STATUS:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.status") + "\n";
			                    }
			                    break;
			                case IndexEntry.VOLNB:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.volnb") + "\n";
			                    }
			                    break;
			                case IndexEntry.CITY:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.labcity") + "\n";
			                    }
			                    break;
			                case IndexEntry.COUNTRY:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.labcountry") + "\n";
			                    }
			                    break;
			                case IndexEntry.PUBLISHED:
			                    if (entryValue.length() == 0) 
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.published") + "\n";
			                    }
			                    break;
			                /*case IndexEntry.DOCUMENTGROUP:
			                    if (entryValue.length() == 0)
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.document_group") + "\n";
			                    }
			                    break;
			                    */
			                case IndexEntry.FILENAME:
			                    if (entry.getValue(IndexEntry.CROSS_REF) != null && !entry.getValue(IndexEntry.CROSS_REF).equalsIgnoreCase("Y")) 
			                    {
			                        if (entryValue.length() == 0) 
			                        {
			                            entryWarning = true;
			                            warningString += leftIndent + Resources.getString("field.filename") + "\n";
			                        }
			                    }
			                    break;
			                /*case IndexEntry.COMMENTS:
			                    if (entryValue.length() == 0)
			                    {
			                        entryWarning = true;
			                        warningString += leftIndent + Resources.getString("field.comments") + "\n";
			                    }
			                    break;	
			                    */
		                    //-----------------------------------------------------------
		                    //March 2011 for internal version
		                    //added in:			                  
			                case IndexEntry.DOX_MD27:
			                    if (entryValue.length() == 0) 
			                    {
			                    	entryWarning = true;
		                            warningString += leftIndent + Resources.getString("field.contextid") + "\n";
			                    }
			                	break;
			                case IndexEntry.DOX_MD30:
			                    if (entryValue.length() == 0) 
			                    {
			                    	entryWarning = true;
		                            warningString += leftIndent + Resources.getString("field.review_stream") + "\n";
			                    }
			                	break;
			                //------------------------------------------------------------
		                }
		            }            
	            }
	            
	            if (entryError) 
	            {
	                errorEntries.add(Resources.getString("validation.entry") + " " + (entryCount + 1));
	                errorFields.add(errorString);
	            } 
	            else if (entryWarning)
	            {
	                warningEntries.add(Resources.getString("validation.entry") + " " + (entryCount + 1));
	                warningFields.add(warningString);
	            }
	        }
        }
    }

    /**
     * Save the e-index as an XML file. Use this method to save the e-index as a
     * stand alone file (not part of the ZIP package).
     * 
     * @param fileName
     *            full path and name of the XML file
     */
    public void saveAsXML(String fileName) throws ParserConfigurationException, TransformerConfigurationException, TransformerException 
    {
        saveAsXML(fileName, null);
    }

    /**
     * Save the e-index as an XML file. Use this method to save the e-index as a
     * file to be included as part of the ZIP package; the individual file
     * locations are replaced with the value provided as the second argument.
     * 
     * @param fileName
     *            full path and name of the XML file
     * @param location
     *            string that will replace the location of the individual files
     *            <br>
     *            If <code>null</code> no replacement takes place.
     */
    public void saveAsXML(String fileName, String location) throws ParserConfigurationException, TransformerConfigurationException, TransformerException
    {
        // Create an empty DOM Document
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.newDocument();

        // add a reference to the eindex.xsl file      
        ProcessingInstruction xsl_ref = doc.createProcessingInstruction("xml-stylesheet","type=\"text/xsl\" href=\"eindex.xsl\"");
        doc.appendChild(xsl_ref);

        // Insert the e-index element
        Element eIndex = doc.createElement("e-index");
        eIndex.setAttribute("version", XSDVersion.getXSDVersion());
        doc.appendChild(eIndex);

        // meta element
        Element meta = doc.createElement("meta");
        // eIndex.appendChild(meta);

        // field create company
        Element field = doc.createElement("field");
        field.setAttribute("id", IndexEntry.META_COMPANY);
        Element value = doc.createElement("value");
        field.appendChild(value);
        Text text = doc.createTextNode("PMRA");
        value.appendChild(text);
        meta.appendChild(field);

        // field create build
        field = doc.createElement("field");
        field.setAttribute("id", IndexEntry.META_BUILD);
        value = doc.createElement("value");
        field.appendChild(value);
        text = doc.createTextNode(Version.getVersion() + "-" + Version.getBuild());
        value.appendChild(text);
        meta.appendChild(field);

        // field create langauge
        field = doc.createElement("field");
        field.setAttribute("id", IndexEntry.META_LANGUAGE);
        value = doc.createElement("value");
        field.appendChild(value);
        text = doc.createTextNode(Preference.getLanguage());
        value.appendChild(text);
        meta.appendChild(field);

        // field create date
        field = doc.createElement("field");
        field.setAttribute("id", IndexEntry.META_CREATE_DATE);
        value = doc.createElement("value");
        field.appendChild(value);
        text = doc.createTextNode(getCurrentDate());
        value.appendChild(text);
        meta.appendChild(field);

        // field coding scheme
        field = doc.createElement("field");
        field.setAttribute("id", IndexEntry.META_CODING_SCHEME);
        value = doc.createElement("value");
        field.appendChild(value);
        text = doc.createTextNode(SubmissionBuilder.getCodingStandardStr());
        value.appendChild(text);
        meta.appendChild(field);

        // field number of entries
        field = doc.createElement("field");
        field.setAttribute("id", IndexEntry.META_RECORD_COUNT);
        value = doc.createElement("value");
        field.appendChild(value);
        text = doc.createTextNode(Integer.toString(getNumberOfEntries()));
        value.appendChild(text);
        meta.appendChild(field);

        // done with meta element
        eIndex.appendChild(meta);

        // We generate an entry element for each entry row
        IndexEntry entry;
        Element entryEl;
        for (int entryCount = 0; entryCount < getNumberOfEntries(); entryCount++) {
            entry = getEntry(entryCount);
            entryEl = doc.createElement("entry");
            entryEl.setAttribute("id", "e" + entryCount);

            for (int j = 0; j < entry.getSize(); j++) {
                field = doc.createElement("field");
                field.setAttribute("idref", entry.getName(j));
                // I think we don't need this one for now (Teddy, Jan 23, 2004)
                // field.setAttribute("type", entry.getType(j));
                value = doc.createElement("value");
                field.appendChild(value);

		

                // RS: special case for file location
                if (location != null && j == IndexEntry.FILELOCATION) {
                    text = doc.createTextNode(location);
                }
                // RS: added new special case for docId:
                else if (j == IndexEntry.DOCID) {
                    // Need to split up the field into separate DACOs
                    String dacos[] = entry.getValue(j).split(",");
                    // dacos[] will have at least one element
                    text = doc.createTextNode(dacos[0]);
                    value.appendChild(text);

                    for (int k = 1; k < dacos.length; k++) {
                        // for each additional one, make a new value element
                        value = doc.createElement("value");
                        field.appendChild(value);
                        text = doc.createTextNode(dacos[k]);
                        // for the last one, the text will appended below (like
                        // the other
                        // "ifs" in this code block)
                        if (k != dacos.length - 1)
                            value.appendChild(text);
                    }
                } 

		else if(j == IndexEntry.DM_SOURCE){
		text= doc.createTextNode("APPL");
		}
		else {
                    text = doc.createTextNode(entry.getValue(j));
                }

                value.appendChild(text);
                entryEl.appendChild(field);
            }
	
            eIndex.appendChild(entryEl);
        }

        // Write the DOM Document to the file with fileName
        DOMSource source = new DOMSource(doc);
        File file = new File(fileName);
        StreamResult result = new StreamResult(fileName);
        Transformer xformer = TransformerFactory.newInstance().newTransformer();
        xformer.setOutputProperty(OutputKeys.METHOD, "xml");
        xformer.setOutputProperty(OutputKeys.INDENT, "yes");
        xformer.transform(source, result);
    }

    /**
     * Read an XML file and construct the application data
     * @param fileName
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public void readFromXML(String fileName)throws ParserConfigurationException, SAXException, IOException, FileNotFoundException 
    {
		// Read the file in a DOM Document
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		// Make sure the XML document is valid and well-formed
		dbf.setValidating(false);
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = null;

		try 
		{
			doc = db.parse(new File(fileName));
		} 
		catch (SAXParseException spe) 
		{
			// The XML file is not in a proper format
			javax.swing.JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), Resources.getString("file.open.xmlvalidate"));
		}
		
		if (doc != null) 
		{
			// Get the coding scheme from the XML file
			Element metaNode = (Element) doc.getElementsByTagName("meta").item(0);
			NodeList metaFields = metaNode.getElementsByTagName("field");
			Element metaField;
			String id;
			String value;
			
			for (int i = 0; i < metaFields.getLength(); i++) 
			{
				metaField = (Element) metaFields.item(i);
				id = metaField.getAttribute("id");

				if ("Coding_Scheme".equalsIgnoreCase(id)) 
				{
					value = getValue(metaField);
					
					//March 2011 Commented for internal version
					//check PMRA for all operation  
					//

					/* ---------
					if(is_import)
					{ 
					-----------*/
//						make sure there the same coding scheme
						if(value.equals(SubmissionBuilder.getCodingStandardStr()))
						{				
							SubmissionBuilder.setCodingStandard(value);
						}
						else
						{
							/* TODO 
							 * COME UP WITH A MORE ELEGENT SOLUTION FOR THIS
							 */
							// DACO is not a data numbering system - it is an unfortunate abbreviation and euphimism.
							// Since the term DACO is being used in the eindex xml as the scheme name, have to over ride here.
							

							//March 2011
							//Commented for internal version  
							//check PMRA for all operation
							/* ----------------------------
							String 	arg1 = "",
									arg2 = "";
							
							if(SubmissionBuilder.getCodingStandardStr().equalsIgnoreCase("DACO"))
								arg2 = "PMRA";
							else
								arg2 = SubmissionBuilder.getCodingStandardStr();
							
							if(value.equalsIgnoreCase("DACO"))
								arg1 = "PMRA";
							else
								arg1 = value;
							-------------------------*/

							//March 2011
							//Added for internal version  
							//check PMRA for all operation
							String 	arg1 = value,
									arg2 = "PMRA";
							//--------------------------------
							String warningString = "\t" + Resources.getString("file.import.error.msg", arg1, arg2) + "\n";
							JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.ERROR_MESSAGE);
							return;
						}
					//March 2011, Commented for internal version
					//check PMRA for all operation  
					//

					/* ---------
					}
					else
					{
						SubmissionBuilder.setCodingStandard(value);
					}
					-------------*/
				}
			}
	
			// For each entry elemnt in the XML file, create an entry
			// in the e-index
			NodeList entryEls = doc.getElementsByTagName("entry");
			NodeList fieldEls;
			IndexEntry e;
			String idref;
			Element fieldEl;
			String line = null;
			
			for (int i = 0; i < entryEls.getLength(); i++) 
			{
				e = addEntry();
				fieldEls = ((Element) entryEls.item(i)).getElementsByTagName("field");
				
				for (int j = 0; j < fieldEls.getLength(); j++) 
				{
					fieldEl = (Element) fieldEls.item(j);
					idref = fieldEl.getAttribute("idref");
	
					// Look for expired code in the input
					if (idref.equalsIgnoreCase("daco_id")) 
					{
						NodeList valueEls = fieldEl.getElementsByTagName("value");
						String dacoString = "";
						for (int valueCounter = 0; valueCounter < valueEls.getLength(); valueCounter++) 
						{
							Element valueEl = (Element) valueEls.item(valueCounter);
							Node textNode = valueEl.getFirstChild();
							
							if (textNode != null)
								dacoString = textNode.getNodeValue();
	
							if(dacoString != "")
							{
							
								try 
								
								{
									line = Resources.getCodeDescription(SubmissionBuilder.getCodingStandardInt(), dacoString);
								} 
								catch (Exception ex) 
								{
									if (dacoString != null && dacoString.length() > 0)
									{
										try
										{
											line = Resources.getCodeDescription(Constants.CODING_EXPIREDDACO,dacoString);
										}
										catch (Exception expire) 
										{
											int rowNumber = i + 1;
											javax.swing.JOptionPane.showMessageDialog(
													SubmissionBuilder.getAppFrame(), Resources.getString("file.open.validate")
													+ "( "+ dacoString+ " ) "+ 
													Resources.getString("file.open.validate.rownumber")
													+ rowNumber);	
										}
									}
									else
									{
										//ex.printStackTrace();
									}
								}
							}
						}
					}
					
					if (IndexEntry.FIELD_ID_DOC_ID.equalsIgnoreCase(idref)) 
					{
						// setEIndexFieldValue(e, DOCID, fieldEl);
						// RS: special case for DocID: need to concatenate
						// multiple values into a comma delimited string
						// (the SubmissionBuilder "legacy" internal representation).
						setDocId(e, fieldEl);
					} 
					else if (e.getFieldNumberByName(idref) >= 0) 
					{
						int fn = e.getFieldNumberByName(idref);
						setEIndexFieldValue(e, fn, fieldEl);
					}
				}
			}
			setModified(false);
		
		}//If doc != null
	}

    /**
	 * Read the e-index data from an PRZ file.
	 * 
	 * @param fileName
	 *            full path and name of the XML file
	 */
    public void readFromZIP(String fileName) throws ParserConfigurationException, SAXException, IOException {
        String indexFilename = null;
        ZipInputStream in = new ZipInputStream(new FileInputStream(fileName));
        ZipEntry ze;
        
        while ((ze = in.getNextEntry()) != null) 
        {
            if (ze.getName() != null && ze.getName().equals(Constants.E_INDEX_FILE_NAME)) 
            {
                File indexFile = File.createTempFile(Constants.ZIP_FILE_EXT.substring(1), Constants.E_INDEX_FILE_EXT);
                indexFilename = indexFile.getPath();
                FileOutputStream out = new FileOutputStream(indexFile);
                // Transfer bytes from the file to the ZIP file
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) 
                {
                    out.write(buf, 0, len);
                }
                // Complete the entry
                in.closeEntry();
                out.close();

                break;
            }
        }
        in.close();

        if (indexFilename != null) {
            readFromXML(indexFilename);
        }
    }

    private String getCurrentDate() {
        // YYYYMMDDHHMMSS
        // return (new SimpleDateFormat("yyyyMMddHHmmss")).format(new Date());
        return (new SimpleDateFormat(Resources.getString("date.format"))).format(new Date());
    }

    private void setEIndexFieldValue(IndexEntry e, int fieldNumber, Element fieldEl) {
        // Element valueEl =
        // (Element)fieldEl.getElementsByTagName("value").item(0);
        // Node textNode = valueEl.getFirstChild();
        // String value = (textNode == null) ? "" : textNode.getNodeValue();
        e.setValue(fieldNumber, getValue(fieldEl));
    }

    /**
     * Special case for DocID: need to concatenate multiple values into a comma
     * delimited string
     */
    private void setDocId(IndexEntry e, Element fieldEl) {
        // e.setValue(fieldNumber, getValue(fieldEl));
        NodeList valueEls = fieldEl.getElementsByTagName("value");
        String dacos = "";
        for (int i = 0; i < valueEls.getLength(); i++) {
            Element valueEl = (Element) valueEls.item(i);
            Node textNode = valueEl.getFirstChild();
            dacos += (textNode == null) ? "" : textNode.getNodeValue();
            if (i != valueEls.getLength() - 1)
                dacos += ","; // add the delimiter for the next one
        }

        e.setValue(IndexEntry.DOCID, dacos);
    }

    private String getValue(Element fieldEl) {
        Element valueEl = (Element) fieldEl.getElementsByTagName("value").item(0);
        Node textNode = valueEl.getFirstChild();
        String value = (textNode == null) ? "" : textNode.getNodeValue();
        return value;
    }
    
	/*public String check_Characters(String str)
	{
        if( str != null)
        {  
        	// check for special characacters 
        	//char[] specialCharacters = {'\'', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',  '�', 
        			//'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�' ,'�'};

        	char[] specialCharacters = {'\'','�','�','�','�','�','�','�','�','�','�','�','�'
        	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
        	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
        	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'
        	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'};       	

        	if( specialCharacters != null ) 
            {
            	StringBuffer tmpStr = new StringBuffer("");
                for( int i=0; i<str.length(); i++ ) 
                {
                	char c = str.charAt(i);
                    boolean found = false;

                    for( int j=0; j<specialCharacters.length; j++ ) 
                    {
                    	if( c == specialCharacters[j] ) 
                    	{
                    		found = true;
                    		String warningString = "\t" + Resources.getString("saveas.special.char.err", String.valueOf(c)) + "\n";
							JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.ERROR_MESSAGE);
                            //break;
                    		return null;
                        }
                    } 
                    
                    if( !found ) 
                        tmpStr.append(c); 
                }
                    
                str = tmpStr.toString();
            }
        }	
        return str;
	}*/

    public static void main(String[] args) throws ParserConfigurationException, TransformerConfigurationException, TransformerException, SAXException, IOException {

        SubmissionData sd = new SubmissionData();
        /*
         * sd.addEntry(); sd.addEntry(); sd.addEntry();
         * 
         * sd.modifyValue(2, SubmissionData.AUTHOR, "a2"); sd.modifyValue(0,
         * SubmissionData.AUTHOR, "a0"); sd.modifyValue(2, SubmissionData.OWNER,
         * "o2");
         */

        // sd.readFromXML("file_in.xml");
        sd.readFromXML("file_in_full.xml");

        String[][] entry;
        for (int i = 0; i < sd.getNumberOfEntries(); i++) {
            entry = sd.getEntry(i).getEntry();

        }

        sd.saveAsXML("file_out_full.xml");

    }
}