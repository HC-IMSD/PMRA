package ca.gc.pmra.prs.client;

/** 
 * Provides the application with XSD version information.
 * <br>
 * <br>Automatically generated at compilation time.
 */
public class XSDVersion
{
    // Version number is provided as a property in the ant 
    // build.xml file used to build the project 
    private static final String XSDVERSION = "2.7";

    /**
     * Get the XSDversion number.
     * 
     * @return String - version number
     */
    public static String getXSDVersion()
    {
        return XSDVERSION;
    }
}