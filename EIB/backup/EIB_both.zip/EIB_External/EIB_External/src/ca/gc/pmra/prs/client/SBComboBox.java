package ca.gc.pmra.prs.client;

import java.awt.Component;
import java.awt.SystemColor;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import javax.swing.ComboBoxEditor;
import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Class that represent a drop down GUI component.
 */
public class SBComboBox extends JComboBox {

    /**
     * Enable Color of background
     */
    private java.awt.Color enableBackground;

    /**
     * Base constructor.
     */
    public SBComboBox() {

        super();

        addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                SBComboBox.this.fireChanged();
            }
        });
    }

    public SBComboBox(Object[] items) {

        super(items);

        addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                SBComboBox.this.fireChanged();
            }
        });
    }

    public SBComboBox(Vector vec) {
        super(vec);

        addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                SBComboBox.this.fireChanged();
            }
        });
    }

    /**
     * Overrides the super class so that when an editor is set on any ECComboBox a focus listener can be added. Whenever the popup is visible and the user tabs out of the editor component the popup
     * should be closed.
     * 
     * @param anEditor
     *            The editor for the combo box.
     */
    public void setEditor(ComboBoxEditor anEditor) {
        super.setEditor(anEditor);

        if (anEditor != null) {
            Component c = anEditor.getEditorComponent();
            if (c != null) {
                c.addFocusListener(new FocusAdapter() {
                    public void focusLost(FocusEvent fe) {
                        hidePopup();
                   
                    }
                });
            }
        }
    }

    /**
     * Returns the value contained in this Component.
     * 
     * @return the value
     * @see #setValue
     */
    public Object getValue() {
        Object obj = getItemAt(getSelectedIndex());

        return obj;
    }

    /**
     * Sets the value of this Component.
     * 
     * @param value
     *            the new value to be set
     * @see #getText
     */
    public void setValue(Object value) {
        // Reset the value if null
        if (value == null) {
            setSelectedIndex(0);
        } else {
            setSelectedItem(value);
        }
    }

    /**
     * Sets the selected item in the combo box display area to the object in the argument. If <code>anObject</code> is in the list, the display area shows <code>anObject</code> selected.
     * <p>
     * If <code>anObject</code> is <i>not </i> in the list and the combo box is uneditable, it will not change the current selection. For editable combo boxes, the selection will change to
     * <code>anObject</code>.
     * <p>
     * If this constitutes a change in the selected item, <code>ItemListener</code> s added to the combo box will be notified with one or two <code>ItemEvent</code>s. If there is a current
     * selected item, an <code>ItemEvent</code> will be fired and the state change will be <code>ItemEvent.DESELECTED</code>. If <code>anObject</code> is in the list and is not currently
     * selected then an <code>ItemEvent</code> will be fired and the state change will be <code>ItemEvent.SELECTED</code>.
     * <p>
     * <code>ActionListener</code> s added to the combo box will be notified with an <code>ActionEvent</code> when this method is called.
     * 
     * @param anObject
     *            the list object to select; use <code>null</code> to clear the selection
     * @beaninfo preferred: true description: Sets the selected item in the JComboBox.
     */
    public void setSelectedItem(Object anObject) {

        if (anObject == null || anObject.toString().trim().length() == 0) {
            setSelectedIndex(0);
        } else {
            super.setSelectedItem(anObject);
            
        }
    }

    /**
     * Enables or disables this component, depending on the value of the parameter b. An enabled component can respond to user input and generate events. Components are enabled initially by default. A
     * repaint() is done after setting the new state.
     * 
     * @param enable
     *            the boolean to be set
     * @see #isEnabled
     */
    public void setEnabled(boolean enable) {
        if (isEnabled())
            enableBackground = getBackground();

        super.setEnabled(enable);

        if (getEditor() != null && getEditor().getEditorComponent() != null) {

            if (!enable) {
                getEditor().getEditorComponent().setBackground(SystemColor.control);
            } else {
                getEditor().getEditorComponent().setBackground(enableBackground);
            }
        }
    }

    /**
     * Adds the specified listener to receive notification when value is changed.
     * 
     * @param l
     *            the listener.
     */
    public void addChangeListener(ChangeListener l) {
        if (l == null)
            return;

        listenerList.add(ChangeListener.class, l);
    }

    /**
     * Remove the specified listener
     * 
     * @param l
     *            the listener.
     */
    public void removeChangeListener(ChangeListener l) {
        if (l == null)
            return;

        listenerList.remove(ChangeListener.class, l);
    }

    /**
     * notify the value change
     */
    private void fireChanged() {
        Object[] listener = listenerList.getListenerList();
        if (listener == null)
            return;

        for (int i = 0; i < listener.length; i++) {
            if (listener[i] instanceof ChangeListener) {
                ((ChangeListener) listener[i]).stateChanged(new ChangeEvent(this));
            }
        }
  
    }
    
    public void UpdateUI()
    {
    	super.updateUI();
    }

}