package ca.gc.pmra.prs.client;

public class CommandNames
{
    // File menu
    public static final String NEW_SUBMISSION = "new_submission";
    public static final String OPEN_SUBMISSION = "open_submission";
    public static final String CLOSE_SUBMISSION = "close_submission";
    public static final String SAVE_SUBMISSION = "save_submission";
    public static final String SAVEAS_SUBMISSION = "saveas_submission";
    public static final String IMPORT = "import";
    public static final String EXIT = "exit";

    // Edit menu
    //public static final String CUT = "cut";
    //public static final String COPY = "copy";
    //public static final String PASTE = "paste";
    public static final String ADD_ENTRY = "add_entry";
    public static final String REMOVE_ENTRY = "remove_entry";
    public static final String INSERT_ENTRY = "insert_entry";
    public static final String COPY_ENTRY = "copy_entry";
    public static final String MOVE_UP = "move_up";
    public static final String MOVE_DOWN = "move_down";

    // Tools menu
    public static final String SHOW_DETAILS = "show_details";
    public static final String HIDE_DETAILS = "hide_details";
    public static final String SHOW_HIDE_DETAILS = "show_hide_details";
    public static final String PREFERENCE = "preference";
    public static final String VALIDATE_SUBMISSION = "validate_submission";
    public static final String FINALIZE_SUBMISSION = "finalize_submission";

    // Help menu
    public static final String HELP = "help";
    public static final String ABOUT = "about";
    public static final String CHECK_UPDATES = "check_updates";



}