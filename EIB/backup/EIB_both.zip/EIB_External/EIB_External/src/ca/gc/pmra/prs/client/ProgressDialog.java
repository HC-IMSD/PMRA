/*
 * Created on Jun 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ca.gc.pmra.prs.client;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * @author edward-yang.xu
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ProgressDialog extends JDialog {
    
    JLabel messageLabel;

    private boolean canceled = false;
    //private Thread progressDialogThread = null;
    public JButton okButton, cancelButton;
    
    public ProgressDialog() 
    {
        super();
        buildGui();
    }
    
    public ProgressDialog(Frame owner) 
    {
        super(owner);
        buildGui();
    }

    /**
     * Convenience method to put the interface together.
     */    
    private void buildGui() 
    {
        setResizable(true);
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridBagLayout());
        messageLabel = new JLabel("");  
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        okButton = new JButton(Resources.getString("string.ok"));
        okButton.setEnabled(false);
        okButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent ae) 
            {
                close();
            }
        });   
        
        cancelButton = new JButton(Resources.getString("string.cancel"));
        cancelButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent ae) 
            {
                canceled = true;
                close();
            }
        });   

        JPanel message_panel = new JPanel(new GridLayout(3, 1));
        message_panel.add(new JLabel("  "));
        message_panel.add(messageLabel);
        message_panel.add(new JLabel("  "));        
 
        JPanel button_panel = new JPanel(new GridLayout(1, 2));
        button_panel.add(okButton);
        button_panel.add(cancelButton);
        
        contentPane.add(message_panel, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        contentPane.add(button_panel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));   
        
        //this.
        setSize(new Dimension(450, 150));
        //setPreferredSize(new Dimension(450, 150));

        
        pack();
        setLocationRelativeTo(SubmissionBuilder.getAppFrame());
        
        addWindowListener(new WindowAdapter() 
        {
            public void windowClosing(WindowEvent we) 
            {
                canceled = true;
                close();
            }
        });
    }
    
    /** 
     * Indicate that the operation is complete.
     */
    public void close() 
    {
        setVisible(false);
        dispose();
    }
    
    /**
     * Returns <code>true</code> if the user hits the Cancel button in the progress dialog
     * or the X in the dialog frame, <code>false</code> otherwise.
     *
     * @return  Boolean indicating whether the progress was cancelled or terminated normally.
     */
    public boolean isCanceled() 
    {
        return canceled;
    }
    
    /**
     * This method is used to cancel the progress dialog. Typically it is
     * called when an exception in the processing occurs.
     */
    public void cancel() 
    {
        canceled = true;
        close();
    }
    
    /**
     * set message
     */
    public void setMessage(String message)
    {
        messageLabel.setText(message);
    }
    
    /**
     * set title
     */
    public void setTitle(String title) 
    {
        super.setTitle(title);
    }

    public void start() 
    {
        Runnable progressDialogRun = new Runnable() 
        {
            public void run() 
            {
                ProgressDialog.this.setVisible(true);
            }
        };

        try 
        {
        	Thread progressDialogThread = new Thread(progressDialogRun, "progressDialogThread");
            progressDialogThread.start();
        } 
        catch (Exception e) 
        {
            // TODO: handle exception
        }
    }
    
    public void sleep()
    {
        try 
        {
            long numMillisecondsToSleep = 2000; // 2 seconds
            Thread.sleep(numMillisecondsToSleep);
        } 
        catch (InterruptedException e) 
        {
        	System.err.println("Thread Error");
        }
    }
}
