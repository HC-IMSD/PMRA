/*
 * Created on Mar 21, 2005
 */
package ca.gc.pmra.prs.client;

/**
 * @author edward-yang.xu
 */
public class Code implements Comparable{

    String key = null;

    String desc = null;

    /**
     * @param code
     * @param desc
     */
    public Code(String key, String desc) {
        super();
        this.key = key;
        this.desc = desc;
    }

    /**
     * @return Returns the key.
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key
     *            The key to set.
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * @return Returns the desc.
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc
     *            The frenchDesc to set.
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String toString() {
        return desc;
    }
    
    public boolean equals(Object obj) {
        if (obj == null || ! (obj instanceof Code)) return false;
        
        if ( key != null && ((Code)obj).getKey() != null ) {
            return key.equals(((Code)obj).getKey());
        }
        
        return true;
        
    }
    
    public int compareTo(Object obj) {
        if ( toString() != null && ((Code)obj).toString() != null ) {
            return toString().compareTo(((Code)obj).toString());
        }
        
        return 1;
        
        
    }
}