package ca.gc.pmra.prs.client;

import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.border.BevelBorder;

/**
 * Toolbar of the application.
 * 
 * @author Teddy Mihail tmihail@newbook.com
 */
public class SubmissionToolBar {

    /** All the commands are executed by the ActionListener */
    private static ActionListener al;

    private static JButton fileCloseButton = null;

    private static JButton fileSaveButton = null;

    private static JButton editAddButton = null;

    private static JButton editInsertButton = null;

    private static JButton editCopyButton = null;

    private static JButton editRemoveButton = null;

    private static JButton toolDetailsButton = null;

    private static JButton toolValidateButton = null;

    private static JButton toolFinalButton = null;

    /**
     * Create a toolbar.
     * 
     * @param toolBarCaption
     *            string to be displayed as title of the toolbar when shown as a
     *            separate box
     * @param listener
     *            ActionListener executing the commands from the tool bar
     * 
     * @return JToolBar - the newly created toolbar
     */
public static JToolBar createToolBar(String toolBarCaption, ActionListener listener) {
        JToolBar toolBar;

        al = listener;
        //Create the tool bar.
        toolBar = new JToolBar(toolBarCaption);
        
        toolBar.setFloatable(false);

        //New
        toolBar.add(makeToolButton(Resources.getString("file.new.button.icon"),
                                   CommandNames.NEW_SUBMISSION,
                                   Resources.getString("file.new.tip"),
                                   Resources.getString("file.new")));
        //Open
        toolBar.add(makeToolButton(Resources.getString("file.open.button.icon"),
                                   CommandNames.OPEN_SUBMISSION,
                                   Resources.getString("file.open.tip"),
                                   Resources.getString("file.open")));
        //Save
        fileSaveButton = makeToolButton(Resources.getString("file.save.button.icon"),
                CommandNames.SAVE_SUBMISSION,
                Resources.getString("file.save.tip"),
                Resources.getString("file.save"));
        toolBar.add(fileSaveButton);
        //Close
        fileCloseButton = makeToolButton(Resources.getString("file.close.button.icon"),
                CommandNames.CLOSE_SUBMISSION,
                Resources.getString("file.close.tip"),
                Resources.getString("file.close"));
        toolBar.add(fileCloseButton);

        // toolBar.addSeparator();
        toolBar.addSeparator(new Dimension(30, (new Double(toolBar.getPreferredSize().getHeight()).intValue())));


        //Show/hide details
        toolDetailsButton = makeToolButton(Resources.getString("tools.show.details.button.icon"),
                                       CommandNames.SHOW_HIDE_DETAILS,
                                       Resources.getString("tools.show.details.tip"),
                                       Resources.getString("tools.show.details"));
        toolBar.add(toolDetailsButton);

        //Add
        editAddButton = makeToolButton(Resources.getString("edit.add.button.icon"),
                CommandNames.ADD_ENTRY,
                Resources.getString("edit.add.tip"),
                Resources.getString("edit.add"));
        toolBar.add(editAddButton);
        
        //Insert
        editInsertButton = makeToolButton(Resources.getString("edit.insert.button.icon"),
                CommandNames.INSERT_ENTRY,
                Resources.getString("edit.insert.tip"),
                Resources.getString("edit.insert"));
        toolBar.add(editInsertButton);
        
        //Copy
        editCopyButton = makeToolButton(Resources.getString("edit.copy.button.icon"),
                CommandNames.COPY_ENTRY,
                Resources.getString("edit.copy.tip"),
                Resources.getString("edit.copy"));
        toolBar.add(editCopyButton);
        
        //Remove
        editRemoveButton = makeToolButton(Resources.getString("edit.remove.button.icon"),
                CommandNames.REMOVE_ENTRY,
                Resources.getString("edit.remove.tip"),
                Resources.getString("edit.remove"));
        toolBar.add(editRemoveButton);
        
        //toolBar.addSeparator();
        toolBar.addSeparator(new Dimension(30, (new Double(toolBar.getPreferredSize().getHeight()).intValue())));
        
        
        //Validate
        toolValidateButton = makeToolButton(Resources.getString("tools.validate.button.icon"),
                CommandNames.VALIDATE_SUBMISSION,
                Resources.getString("tools.validate.tip"),
                Resources.getString("tools.validate"));
        toolBar.add(toolValidateButton);
        // Finalize
        toolFinalButton = makeToolButton(Resources.getString("tools.finalize.button.icon"),
                CommandNames.FINALIZE_SUBMISSION,
                Resources.getString("tools.finalize.tip"),
                Resources.getString("tools.finalize"));
        toolBar.add(toolFinalButton);
        
        /***********************************************************************
         * //Move Up
         * toolBar.add(makeToolButton(Resources.getString("edit.moveup.button.icon"),
         * CommandNames.MOVE_UP, Resources.getString("edit.moveup.tip"),
         * Resources.getString("edit.moveup"))); //Move Down
         * toolBar.add(makeToolButton(Resources.getString("edit.movedown.button.icon"),
         * CommandNames.MOVE_DOWN, Resources.getString("edit.movedown.tip"),
         * Resources.getString("edit.movedown")));
         **********************************************************************/
        
        toolBar.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

        return toolBar;

    }
    /**
     * Make a new button.
     * 
     * @param imageName
     *            file name and location for button's icon
     * @param actionCommand
     *            name of the command associated with this button
     * @param toolTipText
     *            string to be show as tool tip
     * @param altText
     *            text to be set on the button if the icon file is not found
     * 
     * @return JButton - the newly created button
     */
    private static JButton makeToolButton(String imageName, String actionCommand, String toolTipText, String altText) {
        //Create and initialize the button.
        JButton button = new JButton();
        button.setActionCommand(actionCommand);
        button.setToolTipText(toolTipText);
        button.addActionListener(al);

        if (imageName.length() > 0) {
            ImageIcon icon = Resources.getIcon(imageName);
            button.setIcon(icon);
        } else {
            button.setText(altText);
        }
        return button;
    }
    
    /*
     * Check Button
     */
    public static void checkButton() {
        fileCloseButton.setEnabled(true);
        fileSaveButton.setEnabled(true);
        editAddButton.setEnabled(true);
        editInsertButton.setEnabled(true);
        editCopyButton.setEnabled(true);
        editRemoveButton.setEnabled(true);
        toolDetailsButton.setEnabled(true);
        toolValidateButton.setEnabled(true);
        toolFinalButton.setEnabled(true);
        
        // chck whether or not the file is opened
        String openFileName = SubmissionBuilder.getOpenFileName();
        SubmissionData data = SubmissionBuilder.getIndexData();
        if (openFileName == null && data == null) {
            
            fileCloseButton.setEnabled(false);
            fileSaveButton.setEnabled(false);
            editAddButton.setEnabled(false);
            editInsertButton.setEnabled(false);
            editCopyButton.setEnabled(false);
            editRemoveButton.setEnabled(false);
            toolDetailsButton.setEnabled(false);
            toolValidateButton.setEnabled(false);
            toolFinalButton.setEnabled(false);

            return;
        }

        // check detail button
        if (SubmissionBuilder.getDetailsPane() != null) {
            // Change the appearance of Show/Hide tool bar button
            ImageIcon icon = Resources.getIcon(Resources.getString("tools.hide.details.button.icon"));
            toolDetailsButton.setIcon(icon);
            toolDetailsButton.setToolTipText(Resources.getString("tools.hide.details.tip"));
        } else {

            // Change the appearance of Show/Hide tool bar button
            ImageIcon icon = Resources.getIcon(Resources.getString("tools.show.details.button.icon"));
            toolDetailsButton.setIcon(icon);
            toolDetailsButton.setToolTipText(Resources.getString("tools.show.details.tip"));
        }
        
        if (SubmissionBuilder.getIndexData().getNumberOfEntries() > 0) {
            toolDetailsButton.setEnabled(true);            
        } else {
            toolDetailsButton.setEnabled(false);
        }
        
        // check edit button
        SubmissionTable table = SubmissionBuilder.getIndexTable();
        if (table == null || data == null) {
            editAddButton.setEnabled(false);
            editInsertButton.setEnabled(false);
            editCopyButton.setEnabled(false);
            editRemoveButton.setEnabled(false);
        } else {
            int position = table.getSelectedRow();
            if (position == -1 || data.getNumberOfEntries() == 0) {
                editInsertButton.setEnabled(false);
                editCopyButton.setEnabled(false);
                editRemoveButton.setEnabled(false);
            }
        }

    }
}