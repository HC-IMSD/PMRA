package ca.gc.pmra.prs.client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

/**
 * Menu bar of the application.
 * 
 * @author Teddy Mihail tmihail@newbook.com
 */
public class SubmissionMenuBar {
    /** All the commands are executed by the ActionListener */
    private static ActionListener al;

    private static JMenuItem fileCloseMenuItem = null;

    private static JMenuItem fileSaveMenuItem = null;

    private static JMenuItem fileSaveAsMenuItem = null;

    private static JMenuItem editAddMenuItem = null;

    private static JMenuItem editInsertMenuItem = null;

    private static JMenuItem editCopyMenuItem = null;

    private static JMenuItem editRemoveMenuItem = null;

    private static JMenuItem toolDetailsMenuItem = null;

    private static JMenuItem toolValidateMenuItem = null;

    private static JMenuItem toolFinalMenuItem = null;
    
    //For import
    private static JMenuItem fileImport = null;

    private static final String lang = Preference.getLanguage();
    /**
     * Create the menu bar.
     * 
     * @param listener
     *            ActionListener executing the commands from the tool bar
     * 
     * @return JMenuBar - the newly created menu bar
     */
    public static JMenuBar createMenuBar(ActionListener listener) {
        JMenuBar menuBar;
        JMenu menu;
        JMenuItem menuItem;

        al = listener;
        //Create the menu bar.
        menuBar = new JMenuBar();

        String vers = System.getProperty("os.name").toLowerCase(); 
        int event_mask = ActionEvent.ALT_MASK;
        
        if (vers.indexOf("mac") != -1) 
        	event_mask = ActionEvent.META_MASK;
        /*
        
        String vers = System.getProperty("os.name").toLowerCase(); 
        if (s.indexOf("windows") != -1) { 
           jmi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, Event.CTRL_MASK)); 
        } else if (s.indexOf("mac") != -1) { 
           jmi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, Event.META_MASK)); 
        } 
        */            
        

        
        //Build the "File" menu.
        //----------------------
        menu = new JMenu(Resources.getString("menu.file"));
        menu.setMnemonic(KeyEvent.VK_F);
        menu.getAccessibleContext().setAccessibleDescription(Resources.getString("menu.file.accessible"));
        menu.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_F,event_mask), "file_menu");
        // Add the action to the component
        menu.getActionMap().put("file_menu",
            new AbstractAction("file_menu") {
                public void actionPerformed(ActionEvent evt) {
                    JMenu menu = (JMenu)evt.getSource();
                    menu.doClick();
                }
            }
        );
        
        //New
        addMenuItem(menu, Resources.getString("file.new"), KeyEvent.VK_N, KeyEvent.VK_N, event_mask, Resources.getString("file.new.accessible"), Resources.getString("file.new.tip"), CommandNames.NEW_SUBMISSION);
        //Open
        addMenuItem(menu, Resources.getString("file.open"), KeyEvent.VK_O, KeyEvent.VK_O, event_mask, Resources.getString("file.open.accessible"), Resources.getString("file.open.tip"), CommandNames.OPEN_SUBMISSION);
        //Close
        if(lang.equals("en"))
        	fileCloseMenuItem = addMenuItem(menu, Resources.getString("file.close"), KeyEvent.VK_C, -1, 0, Resources.getString("file.close.accessible"), Resources.getString("file.close.tip"), CommandNames.CLOSE_SUBMISSION);
        else if(lang.equals("fr"))
        	fileCloseMenuItem = addMenuItem(menu, Resources.getString("file.close"), KeyEvent.VK_M, -1, 0, Resources.getString("file.close.accessible"), Resources.getString("file.close.tip"), CommandNames.CLOSE_SUBMISSION);        
        //Separator
        menu.addSeparator();
        
        //For import
       fileImport = addMenuItem(menu, Resources.getString("file.import"), 0,  -1, 0, Resources.getString("file.import.accessible"), Resources.getString("file.import.tip"), CommandNames.IMPORT);
        menu.addSeparator();
        
        //Save
        fileSaveMenuItem = addMenuItem(menu, Resources.getString("file.save"), KeyEvent.VK_S, KeyEvent.VK_S, event_mask, Resources.getString("file.save.accessible"), Resources.getString("file.save.tip"), CommandNames.SAVE_SUBMISSION);
        //Save As
        fileSaveAsMenuItem = addMenuItem(menu, Resources.getString("file.saveas"), KeyEvent.VK_A, -1, 0 , Resources.getString("file.saveas.accessible"), Resources.getString("file.saveas.tip"), CommandNames.SAVEAS_SUBMISSION);
        //Separator
        menu.addSeparator();
        //Exit
        if(lang.equals("en"))
        	addMenuItem(menu, Resources.getString("file.exit"), KeyEvent.VK_X, KeyEvent.VK_X, event_mask, Resources.getString("file.exit.accessible"), Resources.getString("file.exit.tip"), CommandNames.EXIT);
        else if(lang.equals("fr"))
        	addMenuItem(menu, Resources.getString("file.exit"), KeyEvent.VK_R, KeyEvent.VK_R, event_mask, Resources.getString("file.exit.accessible"), Resources.getString("file.exit.tip"), CommandNames.EXIT);       
        
        // Add the "File" menu to the menu bar
        menuBar.add(menu);

        //Build the "Edit" menu.
        menu = new JMenu(Resources.getString("menu.edit"));
        menu.setMnemonic(KeyEvent.VK_E);
        menu.getAccessibleContext().setAccessibleDescription(Resources.getString("menu.edit.accessible"));
        menu.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_F,event_mask), "edit_menu");
        // Add the action to the component
        menu.getActionMap().put("edit_menu",
            new AbstractAction("edit_menu") {
                public void actionPerformed(ActionEvent evt) {
                    JMenu menu = (JMenu)evt.getSource();
                    menu.doClick();
                }
            }
        );       
        
        
        //Add
        if(lang.equals("en"))
        	editAddMenuItem = addMenuItem(menu, Resources.getString("edit.add"), KeyEvent.VK_A, KeyEvent.VK_A, event_mask, Resources.getString("edit.add.accessible"), Resources.getString("edit.add.tip"), CommandNames.ADD_ENTRY);
        else if(lang.equals("fr"))
        	editAddMenuItem = addMenuItem(menu, Resources.getString("edit.add"), KeyEvent.VK_J, KeyEvent.VK_J, event_mask, Resources.getString("edit.add.accessible"), Resources.getString("edit.add.tip"), CommandNames.ADD_ENTRY);        
        //Insert
        editInsertMenuItem = addMenuItem(menu, Resources.getString("edit.insert"), 0, KeyEvent.VK_INSERT, event_mask, Resources.getString("edit.insert.accessible"), Resources
                .getString("edit.insert.tip"), CommandNames.INSERT_ENTRY);
        //Copy
        editCopyMenuItem = addMenuItem(menu, Resources.getString("edit.copy"), KeyEvent.VK_C, KeyEvent.VK_C, event_mask, Resources.getString("edit.copy.accessible"), Resources
                .getString("edit.copy.tip"), CommandNames.COPY_ENTRY);
        //Remove
        editRemoveMenuItem = addMenuItem(menu, Resources.getString("edit.remove"), 0, KeyEvent.VK_DELETE, event_mask, Resources.getString("edit.remove.accessible"), Resources
                .getString("edit.remove.tip"), CommandNames.REMOVE_ENTRY);
        

   
        

        /***********************************************************************
         * //Separator menu.addSeparator(); //Move Up addMenuItem(menu,
         * Resources.getString("edit.moveup"), KeyEvent.VK_U, KeyEvent.VK_UP,
         * ActionEvent.ALT_MASK, Resources.getString("edit.moveup.accessible"),
         * Resources.getString("edit.moveup.tip"), CommandNames.MOVE_UP); //Move
         * Down addMenuItem(menu, Resources.getString("edit.movedown"),
         * KeyEvent.VK_D, KeyEvent.VK_DOWN, ActionEvent.ALT_MASK,
         * Resources.getString("edit.movedown.accessible"),
         * Resources.getString("edit.movedown.tip"), CommandNames.MOVE_DOWN);
         **********************************************************************/

        // Add the "Edit" menu to the menu bar
        menuBar.add(menu);

        //Build the "Tools" menu.
        menu = new JMenu(Resources.getString("menu.tools"));
        menu.setMnemonic(KeyEvent.VK_T);
        menu.getAccessibleContext().setAccessibleDescription(Resources.getString("menu.tools.accessible"));
        menu.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_F,event_mask), "tools_menu");
        // Add the action to the component
        menu.getActionMap().put("tools_menu",
            new AbstractAction("tools_menu") {
                public void actionPerformed(ActionEvent evt) {
                    JMenu menu = (JMenu)evt.getSource();
                    menu.doClick();
                }
            }
        );    
        
        //Details
        toolDetailsMenuItem = addMenuItem(menu, Resources.getString("tools.show.details"), KeyEvent.VK_D, KeyEvent.VK_D, event_mask, Resources.getString("tools.show.details.accessible"),
                Resources.getString("tools.show.details.tip"), CommandNames.SHOW_HIDE_DETAILS);

        //Separator
        menu.addSeparator();
        //Validate
        toolValidateMenuItem = addMenuItem(menu, Resources.getString("tools.validate"), 0, KeyEvent.VK_F2, 0, Resources.getString("tools.validate.accessible"), Resources
                .getString("tools.validate.tip"), CommandNames.VALIDATE_SUBMISSION);
        //Finalize
        toolFinalMenuItem = addMenuItem(menu, Resources.getString("tools.finalize"), 0, KeyEvent.VK_F3, 0, Resources.getString("tools.finalize.accessible"), Resources
                .getString("tools.finalize.tip"), CommandNames.FINALIZE_SUBMISSION);

        //Separator
        menu.addSeparator();
        // Switch lanaguage
        addMenuItem(menu, Resources.getString("tools.preference"), KeyEvent.VK_P, KeyEvent.VK_P, event_mask, Resources.getString("tools.preference.accessible"), Resources.getString("tools.preference.tip"), CommandNames.PREFERENCE);

        // Add the "View" menu to the menu bar
        menuBar.add(menu);

        //Build the "Help" menu.
        menu = new JMenu(Resources.getString("menu.help"));
        
        if(lang.equals("en"))
        {
        	menu.setMnemonic(KeyEvent.VK_H);
        }
        else if(lang.equals("fr"))
        {
        	menu.setMnemonic(KeyEvent.VK_A);
        }
        
        menu.getAccessibleContext().setAccessibleDescription(Resources.getString("menu.help.accessible"));
        menu.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_F,event_mask), "tools_help");
        // Add the action to the component
        menu.getActionMap().put("tools_help", new AbstractAction("tools_help") {
                public void actionPerformed(ActionEvent evt) {
                    JMenu menu = (JMenu)evt.getSource();
                    menu.doClick();
                }
            }
        );        
        
        //Help
        addMenuItem(menu, Resources.getString("help.help"), 0, KeyEvent.VK_F1, 0, Resources.getString("help.help.accessible"), Resources.getString("help.help.tip"), CommandNames.HELP);
        //Separator
        menu.addSeparator();
        //Check for Updated
        addMenuItem(menu, Resources.getString("help.update"), KeyEvent.VK_V, KeyEvent.VK_V, event_mask, Resources.getString("help.update.accessible"), Resources.getString("help.update.tip"), CommandNames.CHECK_UPDATES);
        //Separator
        menu.addSeparator();
        //About
        addMenuItem(menu, Resources.getString("help.about"), 0, KeyEvent.VK_F4, 0, Resources.getString("help.about.accessible"), Resources.getString("help.about.tip"), CommandNames.ABOUT);
        // Add the "Help" menu to the menu bar
        menuBar.add(menu);

        return menuBar;
    }

    /**
     * Create a new menu item and attach it to the menu bar.
     * 
     * @param menu
     *            menu where the new menu item is to be attached
     * @param caption
     *            text to be shown on the menu item
     * @param mnemonic
     *            mnemonic key associated with the menu item
     * @param acceleratorKey
     *            accelerator key associated with the menu item
     * @param acceleratorMask
     *            accelerator mask for this menu item
     * @param accessibleDescription
     *            string to be return as accessibility string
     * @param toolTipText
     *            text to be shown as a tool tip for this menu item
     * @param command
     *            the command name associated with the menu item
     * 
     * @return JMenuItem - the new menu item
     */
    private static JMenuItem addMenuItem(JMenu menu, String caption, //shown on
            // the menu
            // item
            int mnemonic, //a KeyEvent constant
            int acceleratorKey, //a KeyEvent constant
            int acceleratorMask, //an ActionEvent constant
            String accessibleDescription, String toolTipText, String command //command
    // associated
    // with
    // the
    // menu
    // item
    ) {

        // The mnemonic it the character that is underlined
        // in the item's caption when pressing Alt key.
        JMenuItem menuItem;
        if (mnemonic != -1) {
            menuItem = new JMenuItem(caption, mnemonic);
        } else {
            menuItem = new JMenuItem(caption);
        }
        menuItem.setActionCommand(command);

        // The accelerator key + accelerator mask (e.g. Ctrl+S for Save)
        // is the combination used to execute this item's command
        if (acceleratorKey != -1) {
            menuItem.setAccelerator(KeyStroke.getKeyStroke(acceleratorKey, acceleratorMask));
        }

        if (accessibleDescription != null) {
            menuItem.getAccessibleContext().setAccessibleDescription(accessibleDescription);
        }
        //if (toolTipText != null) {
          //  menuItem.setToolTipText(toolTipText);
        //}
        menuItem.addActionListener(al);
        menu.add(menuItem);
        return menuItem;
    }

    /*
     * Check Menu items
     */
    public static void checkMenuItem() {
        fileCloseMenuItem.setEnabled(true);
        fileSaveMenuItem.setEnabled(true);
        fileImport.setEnabled(true);
        fileSaveAsMenuItem.setEnabled(true);
        editAddMenuItem.setEnabled(true);
        editInsertMenuItem.setEnabled(true);
        editCopyMenuItem.setEnabled(true);
        editRemoveMenuItem.setEnabled(true);
        toolDetailsMenuItem.setEnabled(true);
        toolValidateMenuItem.setEnabled(true);
        toolFinalMenuItem.setEnabled(true);

        // chck whether or not the file is opened
        String openFileName = SubmissionBuilder.getOpenFileName();
        SubmissionData data = SubmissionBuilder.getIndexData();
        if (openFileName == null && data == null) {

            fileCloseMenuItem.setEnabled(false);
            fileSaveMenuItem.setEnabled(false);
            fileImport.setEnabled(false);
            fileSaveAsMenuItem.setEnabled(false);
            editAddMenuItem.setEnabled(false);
            editInsertMenuItem.setEnabled(false);
            editCopyMenuItem.setEnabled(false);
            editRemoveMenuItem.setEnabled(false);
            toolDetailsMenuItem.setEnabled(false);
            toolValidateMenuItem.setEnabled(false);
            toolFinalMenuItem.setEnabled(false);

            return;
        }
        

        // check detail menu item
        if (SubmissionBuilder.getDetailsPane() != null) {
            // Change the appearance of Show/Hide menu item
            toolDetailsMenuItem.setText(Resources.getString("tools.hide.details"));
            //toolDetailsMenuItem.setToolTipText(Resources.getString("tools.hide.details.tip"));

        } else {
            // Change the appearance of Show/Hide menu item
            toolDetailsMenuItem.setText(Resources.getString("tools.show.details"));
            //toolDetailsMenuItem.setToolTipText(Resources.getString("tools.show.details.tip"));
        }

        if (SubmissionBuilder.getIndexData().getNumberOfEntries() > 0) {
            toolDetailsMenuItem.setEnabled(true);            
        } else {
            toolDetailsMenuItem.setEnabled(false);
        }
        
        // check edit menu items
        SubmissionTable table = SubmissionBuilder.getIndexTable();
        if (table == null || data == null) {
            editAddMenuItem.setEnabled(false);
            editInsertMenuItem.setEnabled(false);
            editCopyMenuItem.setEnabled(false);
            editRemoveMenuItem.setEnabled(false);
        } else {
            int position = table.getSelectedRow();
            if (position == -1 || data.getNumberOfEntries() == 0) {
                editInsertMenuItem.setEnabled(false);
                editCopyMenuItem.setEnabled(false);
                editRemoveMenuItem.setEnabled(false);
            }

        }
    }
}