/* Description:	Text area control.
 * Copyright:	Copyright (c) 2001, Elections Canada
 * $version:	1.0
 * Date		    Author		Changes
 * 2002/01/03	N. Thomassin	Created
 * 2002/07/12   S. Larocque     Added code so that a maximum number of characters can be specified.
 *                              PlainDocument class has been added to handle this.
 * 2002/07/09   E. Xu           Add initValue, getInitValue(), setInitValue(). PR 34
 */
package ca.gc.pmra.prs.client;

import javax.swing.JTextArea;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

/**
 * Class that represent a text area GUI component.
 */
public class SBTextArea extends JTextArea {
    
    /**
     * Enable Color of background
     */
    private java.awt.Color enableBackground;
    
    /**
     * The maximum number of characters that the text area can have.
     */
    private int maxLength;
    

    /**
     * Base construtor.
     */
    public SBTextArea() {
    	 
    }

    /**
     * Constructs a new empty TextArea with the specified number of
     * rows and columns.  A default model is created, and the initial
     * string is null.
     *
     * @param rows the number of rows >= 0
     * @param columns the number of columns >= 0
     */
    public SBTextArea( int rows, int columns ) {
    	
        super( rows, columns );
    }
    
    /**
     * Constructs a new empty <code>TextArea</code> with the specified number of
     * rows, columns and maximum number of characters that the <code>TextArea</code> is allowed.  
     * A document that handles the maximum number of characters is assigned automatically.
     *
     * @param rows the number of rows >= 0
     * @param columns the number of columns >= 0
     * @param maximumLength the maximum number of characters that the <code>textArea</code> can have.
     */
    public SBTextArea( int rows, int columns, int maximumLength) {
        super( rows, columns );
        maxLength = maximumLength;
        setMaxLen(maximumLength );
    }
    
    /**
     * set max length 
     *
     * @param maxLen  the maximum number of columns  
     */
    public void setMaxLen(int maxLen ) {
        maxLength = maxLen;
        setDocument(new MaxLengthDocument());
    }
    
    /**
     * Override this method so that TAB and SHIFT+TAB 
     * will move the focus to the next or previous component.
     */
    public boolean isManagingFocus() {
        return false;
    }
    
    /**
     * Class that will handle the maximun number of characters that the
     * <code>TextArea</code> is allowed to have.
     */
    class MaxLengthDocument extends PlainDocument {
    	
    	//String used as regular expression pattern
    	private String regex = Resources.getString("string.regex");
    	//char[] specialCharacters = Resources.getString("string.regex");
        /**
         * Handles inserting text within its associated component.
         */
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException 
        {
            if( str != null && (getLength()+str.length()) <= maxLength)
            {  
            	// check for special characacters 
            	char[] specialCharacters = {'\'', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',  '�', 
            			'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�' ,'�'};
            	/*char[] specialCharacters = {'\'','�','�','�','�','�','�','�','�','�','�','�','�'
                    	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
                    	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
                    	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'
                    	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'};       	
                */
                if( specialCharacters != null ) 
                {
                	StringBuffer tmpStr = new StringBuffer("");
                    for( int i=0; i<str.length(); i++ ) 
                    {
                    	char c = str.charAt(i);
                        boolean found = false;

                        for( int j=0; j<specialCharacters.length; j++ ) 
                        {
                        	if( c == specialCharacters[j] ) 
                        	{
                        		found = true;
                                break;
                            }
                        } 
                        
                        if( !found ) 
                            tmpStr.append(c);
                            
                    }
                        
                    str = tmpStr.toString();
                }
                	
                super.insertString(offs, str, a);

            }
        }
    }
}
