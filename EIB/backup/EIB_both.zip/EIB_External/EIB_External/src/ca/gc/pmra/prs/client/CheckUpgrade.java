/*
 * Created on Jan 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ca.gc.pmra.prs.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * @author edward-yang.xu
 */
public class CheckUpgrade {

    static public void autoCheck() 
    {
        // no auto check
        if (Preference.NO_MORE.equals(Preference.getUpdateMessage())) 
            return;
        
        if (Preference.LATER.equals(Preference.getUpdateMessage())) 
        {
            Calendar cal = new GregorianCalendar();
            cal.setTimeInMillis(cal.getTimeInMillis() - 14 * 24 * 60 * 60 * 1000);
            Date date1 = cal.getTime();

            Date lastDate = Preference.getLastUpdateMessage();
            if (lastDate != null) 
            {
                if (date1.before(lastDate))
                    return;
            }
            // save the date
            Preference.setLastUpdateMessage((new GregorianCalendar()).getTime());
            Preference.savePreference();
        }

        String message = null;
        int messageType = JOptionPane.INFORMATION_MESSAGE;
        String serverVersion = getServerVersion();
        
        if (serverVersion != null && serverVersion.trim().length() > 0) 
        {
    		String currentVersion = Version.getVersion() + "-" + Version.getBuild();
        	
            if (serverVersion.compareToIgnoreCase(currentVersion) > 0) 
            {
                message = Resources.getString("message.upgrade");
                messageType = JOptionPane.WARNING_MESSAGE;
            }
            /*else if (serverVersion.compareToIgnoreCase(currentVersion) == 0)
            {
                message = Resources.getString("message.noneed_upgrade");
                messageType = JOptionPane.INFORMATION_MESSAGE;
            }
            else
            {
                message = Resources.getString("message.noneed_upgrade");
                messageType = JOptionPane.INFORMATION_MESSAGE;
            } */           
        } 
        else 
        {
            message = Resources.getString("message.no_response");
            messageType = JOptionPane.ERROR_MESSAGE;
        }

        if ( message != null) 
        {
            JTextArea textArea = new JTextArea(message);
            textArea.setEditable(false);
            textArea.setBackground((new JLabel()).getBackground());
            textArea.setFont((new JLabel()).getFont());
            JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), textArea, Resources.getString("upgrade.dialog.title"), messageType);
        }
    }

    static public void menualCheck() 
    {
        if (Preference.getServerURL() == null || Preference.getServerURL().trim().length() == 0) 
        {
            JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), Resources.getString("message.unknown_server"), Resources.getString("upgrade.dialog.title"), JOptionPane.ERROR_MESSAGE);
            return;
        }

        String message;
        int messageType = JOptionPane.INFORMATION_MESSAGE;
        String serverVersion = getServerVersion();
        
        if (serverVersion != null && serverVersion.trim().length() > 0) 
        {
            if (serverVersion.compareToIgnoreCase(Version.getVersion() + "-" + Version.getBuild()) > 0) 
            {
                message = Resources.getString("message.upgrade");
                messageType = JOptionPane.WARNING_MESSAGE;
            }
            else 
            {
                message = Resources.getString("message.noneed_upgrade");
                messageType = JOptionPane.INFORMATION_MESSAGE;
            }
        } 
        else if (serverVersion == null) 
        {
            message = Resources.getString("message.no_response");
            messageType = JOptionPane.ERROR_MESSAGE;
        } 
        else
        {
            message = Resources.getString("message.noneed_upgrade");
            messageType = JOptionPane.INFORMATION_MESSAGE;
        }

        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        textArea.setBackground((new JLabel()).getBackground());
        textArea.setFont((new JLabel()).getFont());
        JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), textArea, Resources.getString("upgrade.dialog.title"), messageType);
    }

    static public String getServerVersion() 
    {
        if (Preference.getServerURL() == null || Preference.getServerURL().trim().length() == 0) 
            return null;
        
        try {
            URL url = new URL(Preference.getServerURL() + "/version.txt");
           
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String inputLine;
            String return_version="";
           
            while ((inputLine = in.readLine()) != null) {
            	return_version = inputLine;
            }
            
            in.close();
            return return_version;
        } 
        catch (MalformedURLException e) {
        	e.printStackTrace();
            return null;
        } 
        catch (IOException e) {
        	e.printStackTrace();
            return null;
        }
    }
}