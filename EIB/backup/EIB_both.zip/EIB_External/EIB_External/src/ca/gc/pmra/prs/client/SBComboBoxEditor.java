

package ca.gc.pmra.prs.client;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ComboBoxEditor;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class SBComboBoxEditor implements ComboBoxEditor, FocusListener, ActionListener, KeyListener {

    private boolean isAjust = false;

    private JComboBox m_comboBox = new JComboBox();

    private JTextField m_textField;

    private ComboBoxDocument m_editor = new ComboBoxDocument();

    private boolean m_autoPopup = true;

    private boolean m_downPopup = true;

    public class BorderlessTextField extends JTextField {
        public void setBorder(Border border) {
        }

        public BorderlessTextField() {
            super();
        }

        public BorderlessTextField(String s, int i) {
            super(s, i);
        }
    }

    public class ComboBoxDocument extends PlainDocument {

        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {

            if (m_autoPopup) {
                m_comboBox.showPopup();
            }

            if (str == null)
                return;
            
            String content = this.getText(0, getLength());
            if (content != null) {
                content = content.substring(0, offs) + str + content.substring(offs);
            } else {
                content = str;
            }

            int[] selection = selectionForString(content, m_comboBox.getModel());
            if (selection != null) {
                super.insertString(offs, str, a);
                if (selection.length == 1) {
                    if (m_comboBox.getSelectedIndex() != selection[0]) {
                        m_comboBox.setSelectedIndex(selection[0]);
                    } else {
                        setItem(m_comboBox.getItemAt(selection[0]));
                    }
                } else {
                    isAjust = true;

                    if (m_comboBox.getSelectedIndex() != selection[0]) {
                        m_comboBox.setSelectedIndex(selection[0]);
                    }

                    isAjust = false;
                }
            }
        }

        public void remove(int offs, int len) throws BadLocationException {

            String content = this.getText(0, getLength());
            if (content != null) {
                if ((offs + len) < getLength())
                    content = content.substring(0, offs) + content.substring(offs + len);
                else
                    content = content.substring(0, offs);
            }

            content = "" + content;

            if (m_autoPopup) {
                m_comboBox.setSelectedIndex(0);
            }

            int[] selection = selectionForString(content, m_comboBox.getModel());
            if (selection != null && selection.length > 0) {
                setText(content);

                isAjust = true;

                if (m_comboBox.getSelectedIndex() != selection[0]) {
                    m_comboBox.setSelectedIndex(selection[0]);
                }

                isAjust = false;

            } else {
                setText("");

                isAjust = true;

                m_comboBox.setSelectedIndex(0);

                isAjust = false;
            }
        }

        public void setText(String str) {
            try {
                super.remove(0, getLength());
                super.insertString(0, str, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public SBComboBoxEditor(JComboBox comboBox) {
        this(comboBox, 9);
    }

    public SBComboBoxEditor(JComboBox comboBox, int editorSize) {
        m_comboBox = comboBox;
        m_textField = new BorderlessTextField("", editorSize);
        //        m_textField = new BorderlessTextField();
        m_textField.setBorder(null);
        m_textField.addFocusListener(this);
        m_textField.setDocument(m_editor);
        m_textField.addActionListener(this);
        m_textField.addKeyListener(this);
    }

    /**
     * Whether or not show popup automatically. For example, when matched selection more than 1, select the first one automatically or show popup
     */
    public void setAutoPopup(boolean b) {
        m_autoPopup = b;
    }

    /**
     * Whether or not show popup when VK_DOWN is press.
     */
    public void setDownPopup(boolean b) {
        m_downPopup = b;
    }

    public Component getEditorComponent() {
        return m_textField;
    }

    public void setItem(Object obj) {

        if (isAjust) {
            return;
        }

        if (obj != null)
            m_editor.setText(obj.toString());
        else
            m_editor.setText("");
    }

    public Object getItem() {
        return m_comboBox.getSelectedItem();
    }

    public Object getText() {
        return m_textField.getText();
    }

    public void selectAll() {
        m_textField.selectAll();
        m_textField.requestFocus();
    }

    public void focusGained(FocusEvent focusevent) {
        selectAll();
    }

    public void focusLost(FocusEvent focusevent) {

        int[] selection = selectionForString(getText().toString(), m_comboBox.getModel());
    
        
        if ((selection != null) && (selection.length >= 1)) {
            if (m_comboBox.getSelectedIndex() != selection[0]) {
                m_comboBox.setSelectedIndex(selection[0]);
                Code code = (Code)m_comboBox.getSelectedItem();
                m_editor.setText(code.getDesc());
                
            } else {
                m_comboBox.setSelectedIndex(selection[0]);
                Code code = (Code)m_comboBox.getSelectedItem();
                m_editor.setText(code.getDesc());
            }
        } else {
            if (m_comboBox.getModel().getSize() > 0) {
                m_comboBox.setSelectedIndex(0);
            }
        }
    }

    public void addActionListener(ActionListener actionlistener) {
        m_textField.addActionListener(actionlistener);
    }

    public void removeActionListener(ActionListener actionlistener) {
        m_textField.removeActionListener(actionlistener);
    }

    public void addFocusListener(FocusListener focuslistener) {
        m_textField.addFocusListener(focuslistener);
    }

    public void removeFocusListener(FocusListener focuslistener) {
        m_textField.removeFocusListener(focuslistener);
    }

    public int[] selectionForString(String str, ComboBoxModel comboboxmodel) {
        int index1 = -1;
        int index2 = -1;
        if (comboboxmodel != null) {
            String s1 = "" + str.toLowerCase();
            for (int i = 0; i < comboboxmodel.getSize(); i++) {
                String s2 = "" + comboboxmodel.getElementAt(i).toString().toLowerCase();
                if (s2.indexOf(s1) == 0) {
                    if (index1 < 0) {
                        index1 = i;
                    } else if (index2 < 0) {
                        index2 = i;
                        break;
                    }
                }
            }
        }

        if ((index1 >= 0) && (index2 >= 0)) {
            int[] tmp = { index1, index2 };
            return tmp;
        } else if ((index1 >= 0) && (index2 < 0)) {
            int[] tmp = { index1 };
            return tmp;
        }

        return null;

    }

    public void actionPerformed(ActionEvent actionevent) {
        int[] selection = selectionForString(getText().toString(), m_comboBox.getModel());

        if ((selection != null) && ((selection.length == 1) || !m_autoPopup)) {
            if (m_comboBox.getSelectedIndex() != selection[0]) {
                m_comboBox.setSelectedIndex(selection[0]);
            } else {
                m_comboBox.setSelectedIndex(selection[0]);
                //setItem( m_comboBox.getItemAt(selection[0]) );
            }
        } else if ((selection != null) && (selection.length == 2) && m_autoPopup) {
            String content = m_textField.getText();
            m_comboBox.setSelectedIndex(selection[0]);
            //setItem( m_comboBox.getItemAt(selection[0]) );
            m_editor.setText(content);
            m_comboBox.showPopup();
        } else if (m_autoPopup) {
            m_comboBox.showPopup();
        }
    }

    public void keyTyped(KeyEvent e) {
        hidePopup(e);
    }

    public void keyPressed(KeyEvent e) {
        hidePopup(e);
    }

    public void keyReleased(KeyEvent e) {
        hidePopup(e);
    }

    public void hidePopup(KeyEvent e) {
        if ((e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_TAB || e.getKeyCode() == KeyEvent.VK_F4) && !m_downPopup) {

            SwingUtilities.invokeLater(new Runnable() {

                public void run() {
                    m_comboBox.hidePopup();
                    m_comboBox.repaint();

                    SBComboBoxEditor.this.actionPerformed(new ActionEvent(this, 0, ""));
                }
            });
        }
    }
}