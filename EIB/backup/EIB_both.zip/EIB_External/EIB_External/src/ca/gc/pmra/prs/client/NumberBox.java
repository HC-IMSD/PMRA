package ca.gc.pmra.prs.client;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;


/**
 * Class that represent a number box GUI component.
 */
public class NumberBox extends SBTextField {
    /**
     * Flag is true if the control value has changed since the last call to
     * <code>setDirty( false )</code>.
     */
    private boolean isDirty;

    /**
     * Fire data change when flag is true. Otherwise, do not fire change 
     */
    private boolean isFireChanged = true;

    /**
     * Base constructor.
     */
    public NumberBox() {
    }

    /**
     * Constructs a new empty <code>ECNumberBox</code> with the specified number of columns.
     * A default model is created and the initial string is set to null.
     *
     * @param columns  the number of columns to use to calculate
     *   the preferred width.  If columns is set to zero, the
     *   preferred width will be whatever naturally results from
     *   the component implementation.
     */
    public NumberBox( int columns ) {
        super( columns );
    }

    /**
     * Constructs a new empty <code>ECNumberBox</code> with the specified number of columns,
     * max length of value.  A default model is created and the initial string is set to null.
     *
     * @param columns  the number of columns to use to calculate
     *   the preferred width.  If columns is set to zero, the
     *   preferred width will be whatever naturally results from
     *   the component implementation.
     * @param maxlen  the max length of value
     */
    public NumberBox( int columns, int maxlen ) {
        super( columns );

        setMaxLen(maxlen);
    }

    /**
     * Constructs a new <code>ECNumberBox</code> initialized with the specified text.
     * A default model is created and the number of columns is 0.
     *
     * @param text the text to be displayed, or null
     */
    public NumberBox( String text ) {
        super( text );
    }

    /**
     * Constructs a new <code>ECNumberBox</code> initialized with the specified text
     * and columns.  A default model is created.
     *
     * @param text the text to be displayed, or null
     * @param columns  the number of columns to use to calculate
     *   the preferred width.  If columns is set to zero, the
     *   preferred width will be whatever naturally results from
     *   the component implementation.
     */
    public NumberBox( String text, int columns ) {
        super( text, columns );
    }

    /**
     * Constructs a new <code>ECNumberBox</code> initialized with the specified text
     * and columns, max length of value.  A default model is created.
     *
     * @param text the text to be displayed, or null
     * @param columns  the number of columns to use to calculate
     *   the preferred width.  If columns is set to zero, the
     *   preferred width will be whatever naturally results from
     *   the component implementation.
     * @param maxlen  the max length of value
     */
    public NumberBox( String text, int columns, int maxlen) {
        super( text, columns );

        m_maxLen = maxlen;
    }

    /**
     * Returns the value contained in this Component.
     *
     * @return an Integer value of this component
     * @see #setValue
     */
    public Object getValue() {
        String value = getText();
        if( value==null||value.length()==0 ) {
            return null;
        }
        return new Long(value);
    }

    /**
     * Returns the value contained in this Component.
     *
     * @return an Integer representing the value of this component
     * @see #setValue
     */
    public Object getIntegerValue() {
        String value = getText();
        if( value==null||value.length()==0 ) {
            return null;
        }
        return new Integer(value);
    }

    /**
     * Returns the value contained in this Component.
     *
     * @return an Long representing the value of this component
     * @see #setValue
     */
    public Object getLongValue() {
        String value = getText();
        if( value==null||value.length()==0 ) {
            return null;
        }
        return new Long(value);
    }

    /**
     * Sets the value of this Component.
     *
     * @param an int value to be set
     * @see #getText
     */
    public void setValue(int value ) {
        setText( Integer.toString(value) );
    }

    /**
     * Sets the value of this Component.
     *
     * @param an long value to be set
     * @see #getText
     */
    public void setValue(long value ) {
        setText( Long.toString(value) );
    }

    /**
     * Sets the value of this Component.
     *
     * @param value to be set
     * @see #getText
     */
    public void setValue(Object value ) {
        if( value==null ) {
            setText( null );
        } else {
            setText( value.toString() );
        }
    }

    /**
     * Sets the value of this Component.
     *
     * @param a String representation of the int value to be set
     * @see #getText
     */
    public void setValue(String  value ) {
        setText( value );
    }

    /**
     * Creates the default implementation of the model
     * to be used at construction if one isn't explicitly 
     * given.  An instance of PlainDocument is returned.
     *
     * @return the default model implementation
     */
    protected Document createDefaultModel() {
        return new NumericDocument();
    }
    
    public void setEditable(boolean t) {
        super.setEditable(t);
        
        setFocusable(t);
        
    }

    /**
     * Class that will handle validation value in this number control.
     */
    class NumericDocument extends PlainDocument {
        /**
        * Inserts a string of content.  This will cause a DocumentEvent
        * of type DocumentEvent.EventType.INSERT to be sent to the
        * registered DocumentListers, unless an exception is thrown.
        * The DocumentEvent will be delivered by calling the
        * insertUpdate method on the DocumentListener.
        * The offset and length of the generated DocumentEvent
        * will indicate what change was actually made to the Document.
        * <p align=center><img src="doc-files/Document-insert.gif">
        * <p>
        * If the Document structure changed as result of the insertion,
        * the details of what Elements were inserted and removed in
        * response to the change will also be contained in the generated
        * DocumentEvent.  It is up to the implementation of a Document
        * to decide how the structure should change in response to an
        * insertion.
        * <p>
        * If the Document supports undo/redo, an UndoableEditEvent will
        * also be generated.  
        *
        * @param offset  the offset into the document to insert the content >= 0.
        *    All positions that track change at or after the given location 
        *    will move.  
        * @param str    the string to insert
        * @param a      the attributes to associate with the inserted
        *   content.  This may be null if there are no attributes.
        * @exception BadLocationException  the given insert position is not a valid 
        * position within the document
        * @see javax.swing.event.DocumentEvent
        * @see javax.swing.event.DocumentListener
        * @see javax.swing.event.UndoableEditEvent
        * @see javax.swing.event.UndoableEditListener
        */
        public void insertString(int offs, String str, AttributeSet a)
        throws BadLocationException {

            if( str == null ) {
                return;
            }

            try {
                long lValue = Long.parseLong( str );
                if( lValue < 0 ) {
                    return;
                }
            } catch( NumberFormatException ex ) {
                return;
            }

            char[] numeric = str.toCharArray();
            StringBuffer buffer = new StringBuffer();
            for( int i = 0; i < numeric.length; i++ ) {
                if( Character.isDigit(numeric[i]) ) {
                    buffer.append(numeric[i]);
                }
            }

            if( (buffer.length()>0) && ((getLength()+str.length()) <= NumberBox.this.m_maxLen) ) {
                super.insertString(offs, buffer.toString(), a);
            }
        }
    }

}
