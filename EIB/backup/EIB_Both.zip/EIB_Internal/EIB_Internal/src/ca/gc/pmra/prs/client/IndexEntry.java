/*
 * Created on Apr 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ca.gc.pmra.prs.client;

/**
 * The entry in the e-index; all entries is made of same number of fields (18
 * fields per entry).
 * 
 * <br>
 * The entry is implemented as a two dimensional array of strings. All entries
 * have the same number of "rows"; each "row" implements one field. <br>
 * The fields are implemented as arrays of 4 strings: name of the field, type of
 * the field, value of field, position in the index table (the summary table
 * displayed in the upper part of the application window); the position in the
 * table starts with 1 because the position 0 is taken by the entry number
 * column; if the position in the table is set to -1 this means we don't show
 * this field in the table.
 */
public class IndexEntry {

    // codes for all the fields of the e-index entries (records)
    public static final int DOCID = 0;

    public static final int RCR = 1;

    public static final int FEEAPPLIES = 2;

    public static final int CROSS_REF = 3;

    public static final int PMRA_DOC_NO = 4;

    public static final int APP_NO = 5;

    public static final int CONFIDENTIAL = 6;

    public static final int APPLICANT_DER = 7;

    public static final int REPORT_NUMBER = 8;

    public static final int TITLE = 9;

    public static final int AUTHOR = 10;

    public static final int REPORTDATE = 11;

    public static final int NOPAGES = 12;

    public static final int VOLNB = 13;

    public static final int EPAMRIDNO = 14;

    public static final int LABNAME = 15;

    public static final int CITY = 16;

    public static final int COUNTRY = 17;

    public static final int REPORTNB = 18;

    public static final int STATUS = 19; //SLP or GEP status

    public static final int PUBLISHED = 20;

    public static final int DOCUMENTGROUP = 21;

    public static final int COMMENTS = 22;

    public static final int FILELOCATION = 23;

    public static final int FILENAME = 24;
    
    public static final int CHECKSUM = 25;

    public static final int UKID = 26;
    
    public static final int DOX_DESCRIPTION = 27;
    
    public static final int DM_OWNER = 28;
    
    public static final int DM_SOURCE = 29;
    
    public static final int CBI_PMRA_IND = 30;
    
    public static final int EFFD = 31;
    
    public static final int EXPD = 32;
    
    public static final int HIST_IND = 33;
    
    public static final int DAFE = 34;
    
    public static final int DATU = 35;
    
    public static final int USRU = 36;

    public static final int DOX_MD1 = 37;
    
    public static final int DOX_MD2 = 38;
    
    public static final int DOX_MD3 = 39;
    
    public static final int DOX_MD4 = 40;
    
    public static final int DOX_MD6 = 41;

    public static final int DOX_MD7 = 42;
    
    public static final int DOX_MD8 = 43;
    
    public static final int DOX_MD10 = 44;
    
    public static final int DOX_MD11 = 45;
    
    public static final int DOX_MD12 = 46;
    
    public static final int DOX_MD13 = 47;
    
    public static final int DOX_MD15 = 48;
    
    public static final int DOX_MD16 = 49;
    
    public static final int DOX_MD27 = 50; // In use as context ID

    public static final int DOX_MD28 = 51; // In use as trigger for CBI Rows

    public static final int DOX_MD29 = 52; // In use as identifier for linked CBI rows

    public static final int DOX_MD30 = 53; // In use as review stream
    // no 31.
    
    public static final int DOX_MD32 = 54; // In use by Oracle as Transaction ID.

    public static final int DOX_MD33 = 55;

    public static final int DOX_MD34 = 56;

    public static final int DOX_MD35 = 57;

    public static final int DOX_MD36 = 58; //used as the MADCO owner
    
    public static final int DOX_MD36C = 59; //used as the checkbox for MADCO owner/ owned by a 3rd party?

    public static final int DOX_MD37 = 60;

    public static final int DOX_MD38 = 61;

    public static final int DOX_MD39 = 62;

    public static final int DOX_MD40 = 63;

    public static final int DOX_MD41 = 64;

    public static final int DOX_MD42 = 65;

    public static final int DOX_MD43 = 66;

    public static final int DOX_MD44 = 67; //used for the multiple owner checkbox

    public static final int DOX_MD45 = 68;

//***********************************************

    public static final int DOX_MD51 = 69;

    public static final int DOX_MD52 = 70;

    public static final int DOX_MD53 = 71;

    public static final int DOX_MD54 = 72;

    public static final int DOX_MD55 = 73;

    public static final int DOX_MD56 = 74;

    public static final int DOX_MD57 = 75;

    public static final int DOX_MD58 = 76;

    public static final int DOX_MD59 = 77;

    public static final int DOX_MD60 = 78;

    public static final int DOX_MD61 = 79;

    public static final int DOX_MD62 = 80;

    public static final int DOX_MD63 = 81;

    public static final int DOX_MD64 = 82;

    public static final int DOX_MD65 = 83;

    public static final int DOX_MD66 = 84;

    public static final int DOX_MD67 = 85;

    public static final int DOX_MD68 = 86;

    public static final int DOX_MD69 = 87;

    public static final int DOX_MD70 = 88;

    public static final int DOX_MD71 = 89;

    public static final int DOX_MD72 = 90;

    public static final int DOX_MD73 = 91;

    public static final int DOX_MD74 = 92;

    public static final int DOX_MD75 = 93;

    public static final int DOX_MD76 = 94;

    public static final int DOX_MD77 = 95;

    public static final int DOX_MD78 = 96;

    public static final int DOX_MD79 = 97;

    public static final int DOX_MD80 = 98;

    public static final int DOX_MD81 = 99;

    public static final int DOX_MD82 = 100;

    public static final int DOX_MD83 = 101;

    public static final int DOX_MD84 = 102;

    public static final int DOX_MD85 = 103;

    public static final int DOX_MD86 = 104;

    public static final int DOX_MD87 = 105;

    public static final int DOX_MD88 = 106;

    public static final int DOX_MD89 = 107;

    public static final int DOX_MD90 = 108;

    public static final int DOX_MD91 = 109;

    public static final int DOX_MD92 = 110;

    public static final int DOX_MD93 = 111;

    public static final int DOX_MD94 = 112;

    public static final int DOX_MD95 = 113;

    public static final int DOX_MD96 = 114;

    public static final int DOX_MD97 = 115;

    public static final int DOX_MD98 = 116;

    public static final int DOX_MD99 = 117;

    public static final int DOX_MD100 = 118;
//************************************************

    public static final int US_MD1 = 119;

    public static final int US_MD2 = 120;

    public static final int US_MD3 = 121;

    public static final int US_MD4 = 122;

    public static final int US_MD5 = 123;

    public static final int US_MD6 = 124;

    public static final int US_MD7 = 125;

    public static final int US_MD8 = 126;

    public static final int US_MD9 = 127;

    public static final int US_MD10 = 128;

    public static final int US_MD11 = 129;

    public static final int US_MD12 = 130;

    public static final int US_MD13 = 131;

    public static final int US_MD14 = 132;

    public static final int US_MD15 = 133;

    public static final int US_MD16 = 134;

    public static final int US_MD17 = 135;

    public static final int US_MD18 = 136;

    public static final int US_MD19 = 137;

    public static final int US_MD20 = 138;

    public static final int US_MD21 = 139;

    public static final int US_MD22 = 140;

    public static final int US_MD23 = 141;

    public static final int US_MD24 = 142;

    public static final int US_MD25 = 143;

//*************************************************    
    public static final String META_CREATE_DATE = "CREATE_DATE";
    
    public static final String META_CODING_SCHEME = "CODING_SCHEME";
    
    public static final String META_RECORD_COUNT = "RECORD_COUNT";
    
    public static final String META_COMPANY = "COMPANY";
    
    public static final String META_BUILD = "BUILD";
    
    public static final String META_LANGUAGE = "LANGUAGE";

    public static final String FIELD_ID_DOC_ID = "DACO_ID";

    public static final String FIELD_ID_CROSS_REF = "CROSS_REFRENCE";

    public static final String FIELD_ID_PMRA_DOC_NO = "PMRA_DOC_NO";

    public static final String FIELD_ID_APP_NO = "APP_NO";

    public static final String FIELD_ID_AUTHOR = "DM_AUTHOR";

    public static final String FIELD_ID_TITLE = "DM_TITLE";

    public static final String FIELD_ID_LAB_NAME = "DM_LAB_NAME";

    public static final String FIELD_ID_LAB_REPORT_NUMBER = "DM_LAB_REPORT_NUMBER";

    public static final String FIELD_ID_REPORT_DATE = "DM_REPORT_DATE";

    public static final String FIELD_ID_NUM_PAGES = "DM_NO_PAGES";

    public static final String FIELD_ID_CONFIDENTIAL = "CBI_APPL_IND";

    public static final String FIELD_ID_GLP_GEP_STATUS = "DM_GLP_GEP";

    public static final String FIELD_ID_VOLUME_NUMBER = "DM_VOL_NO";

    public static final String FIELD_ID_CITY = "DM_LAB_CITY";

    public static final String FIELD_ID_COUNTRY = "DM_LAB_COUNTRY";

    public static final String FIELD_ID_PUBLISHED = "DM_PUBLISHED";

    public static final String FIELD_ID_COMMENTS = "DM_COMMENTS";

    public static final String FIELD_ID_FILE_LOCATION = "DM_EFILE_LOCATION";

    public static final String FIELD_ID_FILENAME = "DM_EFILE_NAME";

    public static final String FIELD_ID_EPA_MRID_NUMBER = "DM_EPA_MRID_NO";

    public static final String FIELD_ID_CHECKSUM = "CHECKSUM";

    public static final String FIELD_ID_FEE_APPLIES = "FEE_APPLIES";

    public static final String FIELD_ID_RCR = "R_CR";

    public static final String FIELD_ID_REPORT_NUMBER = "DM_REPORT_NO";

    public static final String FIELD_ID_APPLICANT_DER = "APPLICANT_DER";

    public static final String FIELD_DOCUMENT_GROUP = "DOCUMENT_GROUP";

    public static final String FIELD_UKID = "UKID";

    public static final String FIELD_DOX_DESCRIPTION = "DOX_DESCRIPTION";

    public static final String FIELD_DM_OWNER = "DM_OWNER";

    public static final String FIELD_DM_SOURCE = "DM_SOURCE";

    public static final String FIELD_CBI_PMRA_IND = "CBI_PMRA_IND";

    public static final String FIELD_EFFD = "EFFD";

    public static final String FIELD_EXPD = "EXPD";

    public static final String FIELD_HIST_IND = "HIST_IND";

    public static final String FIELD_DAFE = "DAFE";

    public static final String FIELD_DATU = "DATU";

    public static final String FIELD_USRU = "USRU";

    public static final String FIELD_DOX_MD1 = "DOX_MD1";

    public static final String FIELD_DOX_MD2 = "DOX_MD2";

    public static final String FIELD_DOX_MD3 = "DOX_MD3";

    public static final String FIELD_DOX_MD4 = "DOX_MD4";

    public static final String FIELD_DOX_MD6 = "DOX_MD6";

    public static final String FIELD_DOX_MD7 = "DOX_MD7";

    public static final String FIELD_DOX_MD8 = "DOX_MD8";

    public static final String FIELD_DOX_MD10 = "DOX_MD10";

    public static final String FIELD_DOX_MD11= "DOX_MD11";

    public static final String FIELD_DOX_MD12 = "DOX_MD12";

    public static final String FIELD_DOX_MD13 = "DOX_MD13";

    public static final String FIELD_DOX_MD15 = "DOX_MD15";

    public static final String FIELD_DOX_MD16 = "DOX_MD16";

    public static final String FIELD_DOX_MD27 = "DOX_MD27";

    public static final String FIELD_DOX_MD28 = "DOX_MD28";

    public static final String FIELD_DOX_MD29 = "DOX_MD29";

    public static final String FIELD_DOX_MD30 = "DOX_MD30";

    public static final String FIELD_DOX_MD32 = "DOX_MD32";

    public static final String FIELD_DOX_MD33 = "DOX_MD33";

    public static final String FIELD_DOX_MD34 = "DOX_MD34";

    public static final String FIELD_DOX_MD35 = "DOX_MD35";

    public static final String FIELD_DOX_MD36 = "DOX_MD36";
    
    public static final String FIELD_DOX_MD36C = "DOX_MD36C";

    public static final String FIELD_DOX_MD37 = "DOX_MD37";

    public static final String FIELD_DOX_MD38 = "DOX_MD38";

    public static final String FIELD_DOX_MD39 = "DOX_MD39";

    public static final String FIELD_DOX_MD40 = "DOX_MD40";

    public static final String FIELD_DOX_MD41 = "DOX_MD41";

    public static final String FIELD_DOX_MD42 = "DOX_MD42";

    public static final String FIELD_DOX_MD43 = "DOX_MD43";

    public static final String FIELD_DOX_MD44 = "DOX_MD44";

    public static final String FIELD_DOX_MD45 = "DOX_MD45";



    public static final String FIELD_DOX_MD51 = "DOX_MD51";

    public static final String FIELD_DOX_MD52 = "DOX_MD52";

    public static final String FIELD_DOX_MD53 = "DOX_MD53";

    public static final String FIELD_DOX_MD54 = "DOX_MD54";

    public static final String FIELD_DOX_MD55 = "DOX_MD55";

    public static final String FIELD_DOX_MD56 = "DOX_MD56";

    public static final String FIELD_DOX_MD57 = "DOX_MD57";

    public static final String FIELD_DOX_MD58 = "DOX_MD58";

    public static final String FIELD_DOX_MD59 = "DOX_MD59";

    public static final String FIELD_DOX_MD60 = "DOX_MD60";

    public static final String FIELD_DOX_MD61 = "DOX_MD61";

    public static final String FIELD_DOX_MD62 = "DOX_MD62";

    public static final String FIELD_DOX_MD63 = "DOX_MD63";

    public static final String FIELD_DOX_MD64 = "DOX_MD64";

    public static final String FIELD_DOX_MD65 = "DOX_MD65";

    public static final String FIELD_DOX_MD66 = "DOX_MD66";

    public static final String FIELD_DOX_MD67 = "DOX_MD67";

    public static final String FIELD_DOX_MD68 = "DOX_MD68";

    public static final String FIELD_DOX_MD69 = "DOX_MD69";

    public static final String FIELD_DOX_MD70 = "DOX_MD70";

    public static final String FIELD_DOX_MD71 = "DOX_MD71";

    public static final String FIELD_DOX_MD72 = "DOX_MD72";

    public static final String FIELD_DOX_MD73 = "DOX_MD73";

    public static final String FIELD_DOX_MD74 = "DOX_MD74";

    public static final String FIELD_DOX_MD75 = "DOX_MD75";

    public static final String FIELD_DOX_MD76 = "DOX_MD76";

    public static final String FIELD_DOX_MD77 = "DOX_MD77";

    public static final String FIELD_DOX_MD78 = "DOX_MD78";

    public static final String FIELD_DOX_MD79 = "DOX_MD79";

    public static final String FIELD_DOX_MD80 = "DOX_MD80";

    public static final String FIELD_DOX_MD81 = "DOX_MD81";

    public static final String FIELD_DOX_MD82 = "DOX_MD82";

    public static final String FIELD_DOX_MD83 = "DOX_MD83";

    public static final String FIELD_DOX_MD84 = "DOX_MD84";

    public static final String FIELD_DOX_MD85 = "DOX_MD85";

    public static final String FIELD_DOX_MD86 = "DOX_MD86";

    public static final String FIELD_DOX_MD87 = "DOX_MD87";

    public static final String FIELD_DOX_MD88 = "DOX_MD88";

    public static final String FIELD_DOX_MD89 = "DOX_MD89";

    public static final String FIELD_DOX_MD90 = "DOX_MD90";

    public static final String FIELD_DOX_MD91 = "DOX_MD91";

    public static final String FIELD_DOX_MD92 = "DOX_MD92";

    public static final String FIELD_DOX_MD93 = "DOX_MD93";

    public static final String FIELD_DOX_MD94 = "DOX_MD94";

    public static final String FIELD_DOX_MD95 = "DOX_MD95";

    public static final String FIELD_DOX_MD96 = "DOX_MD96";

    public static final String FIELD_DOX_MD97 = "DOX_MD97";

    public static final String FIELD_DOX_MD98 = "DOX_MD98";

    public static final String FIELD_DOX_MD99 = "DOX_MD99";

    public static final String FIELD_DOX_MD100 = "DOX_MD100";


    public static final String FIELD_US_MD1 = "US_MD1";
    
    public static final String FIELD_US_MD2 = "US_MD2";

    public static final String FIELD_US_MD3 = "US_MD3";
    
    public static final String FIELD_US_MD4 = "US_MD4";

    public static final String FIELD_US_MD5 = "US_MD5";
    
    public static final String FIELD_US_MD6 = "US_MD6";

    public static final String FIELD_US_MD7 = "US_MD7";
    
    public static final String FIELD_US_MD8 = "US_MD8";

    public static final String FIELD_US_MD9 = "US_MD9";
    
    public static final String FIELD_US_MD10 = "US_MD10";

    public static final String FIELD_US_MD11 = "US_MD11";
    
    public static final String FIELD_US_MD12 = "US_MD12";

    public static final String FIELD_US_MD13 = "US_MD13";
    
    public static final String FIELD_US_MD14 = "US_MD14";

    public static final String FIELD_US_MD15 = "US_MD15";
    
    public static final String FIELD_US_MD16 = "US_MD16";

    public static final String FIELD_US_MD17 = "US_MD17";
    
    public static final String FIELD_US_MD18 = "US_MD18";

    public static final String FIELD_US_MD19 = "US_MD19";
    
    public static final String FIELD_US_MD20 = "US_MD20";

    public static final String FIELD_US_MD21 = "US_MD21";
    
    public static final String FIELD_US_MD22 = "US_MD22";

    public static final String FIELD_US_MD23 = "US_MD23";
    
    public static final String FIELD_US_MD24 = "US_MD24";

    public static final String FIELD_US_MD25 = "US_MD25";
    

    // Data structure of the entry
    // Each field is made of:
    // {fieldName, fieldType, fieldValue, columnNumber, columnHeaderName, columnWidth}
    // columnNumber represents the position in the index table
    // (the summary table displayed in the upper part of the
    // application window); if the position in the table is set
    // the position in the table starts with 1 because the position 0 is
    // taken
    // by the entry number column;
    // if the position in the table is set to -1 this means we don't show
    // this
    // field in the table.
    //ADR 0156 Made DER and CBI. Fixed bug to default multiple owners to '0' ie No
    private String[][] entry = { { IndexEntry.FIELD_ID_DOC_ID, "String", "", "1", "table.head.docid", "20" }, { IndexEntry.FIELD_ID_RCR, "String", "", "-1", "table.head.rcr", "3" },
            { IndexEntry.FIELD_ID_FEE_APPLIES, "Boolean", "", "-1", "table.head.fee", "6" }, { IndexEntry.FIELD_ID_CROSS_REF, "Boolean", "N", "9", "table.head.cross_ref", "6" },
            { IndexEntry.FIELD_ID_PMRA_DOC_NO, "String", "", "10", "table.head.pmra_doc_number", "10" }, { IndexEntry.FIELD_ID_APP_NO, "String", "", "11", "table.head.app_number", "10" },
            { IndexEntry.FIELD_ID_CONFIDENTIAL, "Boolean", "", "12", "table.head.confidential", "6" }, { IndexEntry.FIELD_ID_APPLICANT_DER, "Boolean", "N", "13", "table.head.applicant_der", "10" },

            { IndexEntry.FIELD_ID_REPORT_NUMBER, "String", "", "2", "table.head.report_number", "10" }, { IndexEntry.FIELD_ID_TITLE, "String", "", "3", "table.head.title", "20" },
            { IndexEntry.FIELD_ID_AUTHOR, "String", "", "4", "table.head.author", "20" }, { IndexEntry.FIELD_ID_REPORT_DATE, "Date", "", "5", "table.head.reportdate", "10" },
            { IndexEntry.FIELD_ID_NUM_PAGES, "String", "", "6", "table.head.nopages", "5" }, { IndexEntry.FIELD_ID_VOLUME_NUMBER, "String", "", "7", "table.head.volnb", "10" },
            { IndexEntry.FIELD_ID_EPA_MRID_NUMBER, "String", "", "8", "table.head.epamridno", "10" },

            { IndexEntry.FIELD_ID_LAB_NAME, "String", "", "14", "table.head.labname", "15" }, { IndexEntry.FIELD_ID_CITY, "String", "", "15", "table.head.city", "15" },
            { IndexEntry.FIELD_ID_COUNTRY, "String", "", "16", "table.head.country", "5" }, { IndexEntry.FIELD_ID_LAB_REPORT_NUMBER, "String", "", "17", "table.head.reportnb", "10" },
            { IndexEntry.FIELD_ID_GLP_GEP_STATUS, "String", "", "18", "table.head.status", "10" }, { IndexEntry.FIELD_ID_PUBLISHED, "Boolean", "", "19", "table.head.published", "6" },

            { IndexEntry.FIELD_DOCUMENT_GROUP, "String", "", "20", "table.head.document_group", "10" },

            { IndexEntry.FIELD_ID_COMMENTS, "String", "", "21", "table.head.comments", "20" }, { IndexEntry.FIELD_ID_FILE_LOCATION, "String", "", "23", "table.head.filelocation", "30" },
            { IndexEntry.FIELD_ID_FILENAME, "String", "", "22", "table.head.filename", "20" }, { IndexEntry.FIELD_ID_CHECKSUM, "String", "", "-1", "", "-1" },     
	   { IndexEntry.FIELD_UKID, "String", "", "-1", "", "-1" },{ IndexEntry.FIELD_DOX_DESCRIPTION, "String", "", "-1", "", "-1" },{ IndexEntry.FIELD_DM_OWNER, "String", "", "-1", "", "-1" },
	   { IndexEntry.FIELD_DM_SOURCE,"String", "", "-1", "", "-1" },{ IndexEntry.FIELD_CBI_PMRA_IND, "String", "", "-1", "", "-1" },{ IndexEntry.FIELD_EFFD,"String", "", "-1", "", "-1" },{ IndexEntry.FIELD_EXPD, "String", "", "-1", "", "-1" },{ IndexEntry.FIELD_HIST_IND, "String", "", "-1", "", "-1" },{ IndexEntry.FIELD_DAFE, "String", "", "-1", "", "-1" },{ IndexEntry.FIELD_DATU, "String", "", "-1", "", "-1" },{ IndexEntry.FIELD_USRU, "String", "", "-1", "", "-1" },

            { IndexEntry.FIELD_DOX_MD1, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD2, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD3, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD4, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD6, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD7, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD8, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD10, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD11, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD12, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD13, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD15, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD16, "String", "", "-1", "", "-1" },  { IndexEntry.FIELD_DOX_MD27, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD28, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD29,"String", "", "-1", "", "-1" },
	            
	    { IndexEntry.FIELD_DOX_MD30, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD32, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD33, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD34, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD35, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD36, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD36C, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD37, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD38, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD39, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD40, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD41, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD42, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD43, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD44, "String", "0", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD45, "String", "", "-1", "", "-1" },

            { IndexEntry.FIELD_DOX_MD51, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD52, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD53, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD54, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD55, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD56, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD57, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD58, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD59, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD60, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD61, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD62, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD63, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD64, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD65, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD66, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD67, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD68, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD69, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD70, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD71, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD72, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD73, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD74, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD75, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD76, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD77, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD78, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD79, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD80, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD81, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD82, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD83, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD84, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD85, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD86, "String", "", "-1", "", "-1" },     
	    { IndexEntry.FIELD_DOX_MD87, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD88, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD89, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD90, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD91, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD92, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD93, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD94, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD95, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD96, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD97, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD98, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_DOX_MD99, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_DOX_MD100, "String", "", "-1", "", "-1" },


            { IndexEntry.FIELD_US_MD1, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD2, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD3, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_US_MD4, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD5, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD6, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_US_MD7, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD8, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD9, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_US_MD10, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD11, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD12, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_US_MD13, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD14, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD15, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_US_MD16, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD17, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD18, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_US_MD19, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD20, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD21, "String", "", "-1", "", "-1" },
            { IndexEntry.FIELD_US_MD22, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD23, "String", "", "-1", "", "-1" }, { IndexEntry.FIELD_US_MD24, "String", "", "-1", "", "-1" }, 
	    { IndexEntry.FIELD_US_MD25, "String", "", "-1", "", "-1" }

    };

    public IndexEntry() {
    }

    /**
     * Get the entry as a two dimensional array of strings.
     * 
     * @return String [][] - the whole entry
     */
    public String[][] getEntry() {
        return entry;
    }

    /**
     * Get the size of the entry (its number of fields).
     * 
     * @return Entry size.
     */
    public int getSize() {
        return entry.length;
    }

    /**
     * Set the value of a field.
     * 
     * @param fieldNb
     *            field number
     * @param fieldValue
     *            value of field
     */
    public void setValue(int fieldNb, String fieldValue) {
        entry[fieldNb][2] = fieldValue;
    }

    /**
     * Get the column number of a field.
     * 
     * @param tableColumn
     *            column number of field
     * 
     * @return field number
     */
    public int getFieldNumberByName(String fieldName) {

        if (fieldName == null || fieldName.trim().length() == 0) {
            return -1;
        }

        for (int i = 0; i < entry.length; i++) {
            if (fieldName.equalsIgnoreCase(entry[i][0])) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Get the column number of a field.
     * 
     * @param fieldNb
     *            field number
     * 
     * @return String - column number of field
     */
    public int getTableColumnNumber(int fieldNb) {
        return Integer.parseInt(entry[fieldNb][3]);
    }

    /**
     * Get the column width of a field.
     * 
     * @param fieldNb
     *            field number
     * 
     * @return String - column width of field
     */
    public int getTableColumnWidth(int fieldNb) {
        return Integer.parseInt(entry[fieldNb][5]);
    }

    /**
     * Get the column header name.
     * 
     * @param fieldNb
     *            field number
     * 
     * @return String - column header name
     */
    public String getTableColumnHeaderName(int fieldNb) {
        return entry[fieldNb][4];
    }

    /**
     * Get the column number of a field.
     * 
     * @param tableColumn
     *            column number of field
     * 
     * @return field number
     */
    public int getFieldNumberByTableColumnNumber(int tableColumn) {
        for (int i = 0; i < entry.length; i++) {
            if (tableColumn == Integer.parseInt(entry[i][3])) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Get the name of a field.
     * 
     * @param fieldNb
     *            field number
     * 
     * @return String - name of field
     */
    public String getName(int fieldNb) {
        return entry[fieldNb][0];
    }

    /**
     * Get the type of a field.
     * 
     * @param fieldNb
     *            field number
     * 
     * @return String - type of field
     */
    public String getType(int fieldNb) {
        return entry[fieldNb][1];
    }

    /**
     * Get the value of a field.
     * 
     * @param fieldNb
     *            field number
     * 
     * @return String - value of field
     */
    public String getValue(int fieldNb) {
        return entry[fieldNb][2];
    }

    public Object clone() {
        IndexEntry newEntry = new IndexEntry();
        for (int i = 0; i < getSize(); i++) {
            newEntry.setValue(i, getValue(i));
        }

        return newEntry;
    }
}