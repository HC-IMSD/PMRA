package ca.gc.pmra.prs.client;

import java.awt.Color;

public class Constants
{
    // Possible report dialog types
    public static final int VALIDATION_ERROR_DIALOG = 0;
    public static final int VALIDATION_WARNING_DIALOG = 1;
    public static final int VALIDATION_OK_DIALOG = 2;
    public static final int FINALIZE_ERROR_DIALOG = 3;
    public static final int FINALIZE_WARNING_DIALOG = 4;
    public static final int EXCEPTION_DIALOG = 5;
    public static final int FINALIZE_EMPTY_DIALOG = 6;
    public static final int VALIDATION_EMPTY_DIALOG = 7;

    // possible user's answers following a validation warning while finalizing
    public static final int STOP_FINALIZE = 0;
    public static final int CONTINUE_FINALIZE = 1;

    // coding scheme
    public static final int CODING_DACO = 10;
    public static final int CODING_OECD = 11;
    public static final int CODING_EPA = 12;
    //For the expired code
    public static final int CODING_EXPIREDDACO = 13;
    public static final int CODING_NONE = -1;
    
    public static final String DACO= "DACO";
    public static final String OECD = "OECD";
    public static final String EPA = "EPA";

    //property file names
    public static final String COUNTRIES_FILE = "properties/countrieslist";
    public static final String GLP_GEP_FILE = "properties/glpgepstatuslist";
    //public static final String PROTECTION_CLAIMED_FILE = "properties/dataprotectionclaimedlist.properties";

    // drawing the table
    public static final int COLUMN_PADDING = 10;
    public static final int COLUMN_MIN_SIZE = 35;

    // component dimensions
    public static final int LABEL_HEIGHT = 25;
    public static final int WINDOW_HEIGHT = 200;
    public static final int WINDOW_WIDTH = 600;

    // details
    public static final int DETAIL_INTERVAL = 2;
    public static final int DETAIL_TEXT_SIZE = 5;
    public static final int DETAIL_COMMENTS_ROWS = 3;
    public static final int DETAIL_PRODID_ROWS = 16;
    public static final int DETAILS_MAX_CODE_STRING = 25;
    public static final int DETAILS_MONOSPACE_FONT_SIZE = 12;
    public static final int DETAILS_FEEAPPLIES_FONT_SIZE = 14;
    
    public static final String LOGO_ICON = "graphics/pmralogo.gif";
    public static final String E_INDEX_FILE_NAME = "eindex.xml";
    public static final String ZIP_FILE_EXT = ".prz";
    public static final String E_INDEX_FILE_EXT = ".xml";
    
    public static final Color TEXTFIELD_DIENABLE_COLOR = Color.LIGHT_GRAY;
    
}