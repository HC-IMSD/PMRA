/*
 * Created on Jan 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ca.gc.pmra.prs.client;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * @author edward-yang.xu
 * 
 * Store user Preference
 */
public class Preference {

    public static final String NO_MORE = "NO MORE";

    public static final String LATER = "LATER";

    public static final String EVERY_TIME = "EVERY TIME";

    public static final int UPDATE_MESSAGE_INTERVAL_DAY = 14;

    static private final String USER_FILE_NAME = "preference.xml";

    static private final String SYSTEM_FILE_NAME = "properties/SubmissionBuilder.xml";

    static public final String ENGLISH = "en";

    static public final String FRENCH = "fr";

    static private String language = "en";

    private static String serverURL = "";

    private static String updateMessage = EVERY_TIME;

    private static Date lastUpdateMessage;

    static {
        loadConfig();
        loadPreference();
    }

    /**
     * @return Returns the language.
     */
    public static String getLanguage() {
        return language;
    }

    public static void setEnglish() {
        language = ENGLISH;
    }

    public static void setFrench() {
        language = FRENCH;
    }

    public static boolean isFrench() {
        if (language.equals(ENGLISH)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @return Returns the serverURL.
     */
    public static String getServerURL() {
        return serverURL;
    }

    /**
     * @param serverURL
     *            The serverURL to set.
     */
    public static void setServerURL(String serverURL) {
        if (serverURL == null || serverURL.trim().length() == 0) {
            Preference.serverURL = "";
        }
        Preference.serverURL = serverURL;
    }

    static void loadConfig() {

        try {
            // load input stream

            ResourceAnchor anchor = new ResourceAnchor();
            ClassLoader cl = anchor.getClass().getClassLoader();
            InputStream is = cl.getResourceAsStream(SYSTEM_FILE_NAME);

            // Read the file in a DOM Document
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(is);

            readFromXML(doc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void loadPreference() {
        try {

            // Read the file in a DOM Document
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setValidating(false);
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File(USER_FILE_NAME));

            readFromXML(doc);

        } catch (java.io.FileNotFoundException e) {
            System.out.println("Warning: Cannot find Preference file at Preference.loadPreference");
        } catch (Exception e) {
            System.out.println("Warning: Exception at Preference.loadPreference when load Preference file");
        }
    }

    public static void savePreference() {
        saveAsXML(USER_FILE_NAME);

    }

    /**
     * Read the e-index data from an XML file.
     * 
     * @param fileName
     *            full path and name of the XML file
     */
    private static void readFromXML(Document doc) {

        try {

            // Get the Preference scheme from the XML file
            Element preference = (Element) doc.getElementsByTagName("preference").item(0);

            if (preference != null) {

                // Get the language scheme from the XML file
                Element langNode = (Element) preference.getElementsByTagName("language").item(0);
                if (getElementContent(langNode) != null && getElementContent(langNode).trim().equalsIgnoreCase(FRENCH)) {
                    language = FRENCH;
                }

                // Get the update message scheme from the XML file
                Element updateNode = (Element) preference.getElementsByTagName("updatemessage").item(0);
                if (getElementContent(updateNode) != null && getElementContent(updateNode).trim().equalsIgnoreCase(NO_MORE)) {
                    updateMessage = NO_MORE;
                } else if (getElementContent(updateNode) != null && getElementContent(updateNode).trim().equalsIgnoreCase(LATER)) {
                    updateMessage = LATER;
                } else {
                    updateMessage = EVERY_TIME;
                }

                // Get the update message scheme from the XML file
                Element lastUpdateNode = (Element) preference.getElementsByTagName("lastupdatemessage").item(0);
                if (getElementContent(lastUpdateNode) != null) {
                    String dateStr = getElementContent(lastUpdateNode).trim();
                    try {
                        lastUpdateMessage = (new SimpleDateFormat()).parse(dateStr);                                              
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                // Get the server scheme from the XML file
                Element serverNode = (Element) preference.getElementsByTagName("server").item(0);
                if (getElementContent(serverNode) != null && getElementContent(serverNode).trim().length() > 0) {
                    setServerURL(getElementContent(serverNode));
                }
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Save the prference as a XML file.
     * 
     * @param fileName
     *            full path and name of the XML file <br>
     *            If <code>null</code> no replacement takes place.
     */
    private static void saveAsXML(String fileName) {
        try {
            // Create an empty DOM Document
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.newDocument();

            // create preference
            Element preference = doc.createElement("preference");

            // Insert the e-index element
            Element lang = doc.createElement("language");
            lang.appendChild(doc.createTextNode(language));
            preference.appendChild(lang);

            // Insert the e-index element
            Element um = doc.createElement("updatemessage");
            um.appendChild(doc.createTextNode(updateMessage));
            preference.appendChild(um);

            // Insert the e-index element
            if (lastUpdateMessage != null) {
                Element lum = doc.createElement("lastupdatemessage");
                lum.appendChild(doc.createTextNode((new SimpleDateFormat()).format(lastUpdateMessage)));
                preference.appendChild(lum);
            }

            /*******************************************************************
             * // Insert the server url element Element server =
             * doc.createElement("server");
             * server.appendChild(doc.createTextNode(serverURL));
             * preference.appendChild(server);
             ******************************************************************/

            // insert preference
            doc.appendChild(preference);

            // Write the DOM Document to the file with fileName
            DOMSource source = new DOMSource(doc);
            
            /* NEVER USED*/
            //File file = new File(fileName);
            
            StreamResult result = new StreamResult(fileName);
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.setOutputProperty(OutputKeys.METHOD, "xml");
            xformer.setOutputProperty(OutputKeys.INDENT, "yes");
            xformer.transform(source, result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getElementContent(Element element) {
        try {
            return element.getFirstChild().getNodeValue();
        } catch (Exception e) {
            return null;
        }
    }

    public static void showPreference() {

        JPanel panel = new JPanel(new GridBagLayout());

        // set language
        JLabel langLabel = new JLabel(Resources.getString("tools.preference.language"), JLabel.TRAILING);
        panel.add(langLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHEAST, GridBagConstraints.NONE, new Insets(5, 20, 5, 10), 0, 0));

        JPanel langRadioPanel = new JPanel(new GridBagLayout());
        JRadioButton englishRB = new JRadioButton(Resources.getString("tools.preference.english"));
        JRadioButton frenchRB = new JRadioButton(Resources.getString("tools.preference.french"));
        ButtonGroup langGroup = new ButtonGroup();
        langGroup.add(englishRB);
        langGroup.add(frenchRB);
        langRadioPanel.add(englishRB, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));
        langRadioPanel.add(frenchRB, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));

        panel.add(langRadioPanel, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 10), 0, 0));

        if (isFrench()) {
            frenchRB.setSelected(true);
        } else {
            englishRB.setSelected(true);
        }
                        
        // set auto update check
        JLabel autoLabel = new JLabel(Resources.getString("tools.preference.autoupdate"), JLabel.TRAILING);
        panel.add(autoLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHEAST, GridBagConstraints.NONE, new Insets(5, 20, 5, 10), 0, 0));

        JPanel autoRadioPanel = new JPanel(new GridBagLayout());
        JRadioButton noRB = new JRadioButton(Resources.getString("tools.preference.show_nomore"));
        //JRadioButton laterRB = new JRadioButton(Resources.getString("tools.preference.show_later"));
        JRadioButton everyRB = new JRadioButton(Resources.getString("tools.preference.show_everytime"));


/*Code by Damithri for restart notification label*/

	 JLabel noticeLabel = new JLabel(Resources.getString("tools.preference.notice"), JLabel.TRAILING);
        panel.add(noticeLabel, new GridBagConstraints(0, 1, 0, 0, 1.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(65, 55, 5, 10), 0, 0));
	
/* end code by Damithri*/



        ButtonGroup autoGroup = new ButtonGroup();
        autoGroup.add(noRB);
        //autoGroup.add(laterRB);
        autoGroup.add(everyRB);
        autoRadioPanel.add(noRB, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));
        //autoRadioPanel.add(laterRB, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));
        autoRadioPanel.add(everyRB, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));

        panel.add(autoRadioPanel, new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 10), 0, 0));

        if (Preference.NO_MORE.equals(Preference.getUpdateMessage())) {
            noRB.setSelected(true);
        //} else if (Preference.LATER.equals(Preference.getUpdateMessage())) {
        //    laterRB.setSelected(true);
        } else {
            everyRB.setSelected(true);
        }
        
        JLabel errorMessage = new JLabel(" ");
        errorMessage.setForeground(Color.red);
        panel.add(errorMessage, new GridBagConstraints(0, 3, 1, 1, 1.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(5, 20, 5, 10), 0, 0));

        while (true) {
            Object[] options = { Resources.getString("string.ok"), Resources.getString("string.cancel") };
            int select = JOptionPane.showOptionDialog(SubmissionBuilder.getAppFrame(), panel, Resources.getString("tools.preference"), JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,
                    null, options, Resources.getString("string.no"));

            if (select == JOptionPane.OK_OPTION) {

                /***************************************************************
                 * if (serverField.getText() != null &&
                 * serverField.getText().trim().length() > 0) { try { URL url =
                 * new URL(serverField.getText()); } catch (Exception e) {
                 * errorMessage.setText(Resources.getString("message.wrong_url"));
                 * 
                 * continue; } } setServerURL(serverField.getText());
                 **************************************************************/

                if (englishRB.isSelected()) {
                    setEnglish();
                } else {
                    setFrench();
                }
                
                if (noRB.isSelected()) {
                    Preference.setUpdateMessage(Preference.NO_MORE);
                //} else if (laterRB.isSelected()) {
                //    Preference.setUpdateMessage(Preference.LATER);
                } else {
                    Preference.setUpdateMessage(Preference.EVERY_TIME);
                }

                setLastUpdateMessage((new GregorianCalendar()).getTime());

                savePreference();

                break;
            } else {
                break;
            }
        }
    }

    /**
     * @return Returns the showMessage.
     */
    public static String getUpdateMessage() {
        return updateMessage;
    }

    /**
     * @param showMessage
     *            The showMessage to set.
     */
    public static void setUpdateMessage(String updateMessage) {
        Preference.updateMessage = updateMessage;
    }
    /**
     * @return Returns the lastUpdateMessage.
     */
    public static Date getLastUpdateMessage() {
        return lastUpdateMessage;
    }
    /**
     * @param lastUpdateMessage The lastUpdateMessage to set.
     */
    public static void setLastUpdateMessage(Date lastUpdateMessage) {
        Preference.lastUpdateMessage = lastUpdateMessage;
    }
}