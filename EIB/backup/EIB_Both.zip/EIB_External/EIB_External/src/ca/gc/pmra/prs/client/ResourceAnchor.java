package ca.gc.pmra.prs.client;

/**
 * Empty class used to get hold of a class loader when loading
 * resources from the JAR file.
 *
 * @author Teddy Mihail, tmihail@newbook.com
 */
public class ResourceAnchor
{
    public ResourceAnchor()
    {
    }
}