package ca.gc.pmra.prs.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.swing.ImageIcon;

public class Resources {
    public static final int CODES = 1;

    public static final int DESCRIPTIONS = 2;

    private static ResourceBundle strings = null;

    private static ResourceBundle daco = null;

    private static ResourceBundle oecd = null;

    private static ResourceBundle epa = null;
    
    //For the expired DACO codes
    private static ResourceBundle daco_expired = null;

    private static Properties codingProperties = null;

    private static ResourceBundle listOfCountries = null;

    private static ResourceBundle listOfGlpGepStatus = null;

    /**
     * Retrieves a string from the Strings.properties file.
     * 
     * @param key
     *            key in Strings.properties
     * 
     * @return String - the string retrieved from Strings.properties
     */
    public static String getString(String key) {
        if (strings == null) {
            Locale l = new Locale(Preference.getLanguage(), "CA");

            strings = ResourceBundle.getBundle("properties/Strings", l);
        }
        
        return strings.getString(key);
    }

    private static String replaceAll(String source, String regex, String replacement) {

        String dest = source;
        
        while (dest.indexOf(regex) >= 0) {
            int i = dest.indexOf(regex);
            if (i != 0 && dest.length() > i + regex.length()) {
                dest = dest.substring(0, i) + replacement + dest.substring(i + regex.length());
            } else if (i == 0 && dest.length() == i + regex.length()) {
                dest = replacement;
            } else if (i == 0 && dest.length() > i + regex.length()) {
                dest = dest.substring(0, i) + replacement + dest.substring(i + regex.length());
            } else if (i != 0 && dest.length() == i + regex.length()) {
                dest = dest.substring(0, i) + replacement;
            }
        }

        return dest;
    }

    /**
     * Retrieves a string from the Strings.properties file. The string may
     * contain place holder(s) denoted by %1. The method replaces all the
     * instances of %1 with the string provided as second argument in the method
     * call.
     * 
     * @param key
     *            key in Strings.properties
     * @param arg
     *            substitution string for %1
     * 
     * @return String - the string retrieved from Strings.properties with all %1
     *         instances replaced by the string "arg"
     */
    public static String getString(String key, String arg) {

        //return getString(key).replaceAll("%1", arg);

        return replaceAll(getString(key), "%1", arg);
    }

    /**
     * Retrieves a string from the Strings.properties file. The string may
     * contain place holder(s) denoted by %1 and %2. The method replaces all the
     * instances of %1 with the string provided as second argument in the method
     * call, and all instances of %2 with the string provided as third argument.
     * 
     * @param key
     *            key in Strings.properties
     * @param arg1
     *            substitution string for %1
     * @param arg2
     *            substitution string for %2
     * 
     * @return String - the string retrieved from Strings.properties with all %1
     *         instances replaced by the string "arg1" and all %2 instances
     *         replaced by the string "arg2"
     */
    public static String getString(String key, String arg1, String arg2) {

        // return getString(key, arg1).replaceAll("%2", arg2);

        return replaceAll(getString(key, arg1), "%2", arg2);

    }

    /**
     * Retrieves the description of the code in the current coding schema.
     * 
     * @param code
     *            code key
     * 
     * @return String - description of the code
     */
    public static String getCodeDescription(int coding, String key) {// throws java.util.MissingResourceException {

        ResourceBundle r = getCodeResource(coding);
        String s = new String();
        
        if(key.indexOf(' ') != -1 && !key.startsWith("--"))
        	key = key.replace(' ', '$').trim();        
        
	        if (r != null) 
	        {
	        	//try
	        	//{
	        		s = r.getString(key);
	        	//}
	        	//catch(Exception e)
	        	//{
	        		//s = null;
	        	//}
	        } 
	        else 
	        {
	        	s =  null;
	        }

        return s;
    }

    /**
     * Retrieve a button icon based on the graphic file that the name is
     * provided as argument. The graphic files reside in the JAR under the
     * directory "graphics".
     * 
     * @param fileName
     *            graphic file name
     * 
     * @return ImageIcon - icon
     */
    public static ImageIcon getIcon(String fileName) {
        ResourceAnchor anchor = new ResourceAnchor();
        ClassLoader cl = anchor.getClass().getClassLoader();
        ImageIcon icon = new ImageIcon(cl.getResource(fileName));
        return icon;
    }

    private static ResourceBundle getCodeResource(int coding) {
        try {
        	
            if (daco == null || oecd == null || epa == null || daco_expired == null) {
                Locale l = new Locale(Preference.getLanguage(), "CA");

                daco = ResourceBundle.getBundle("properties/dacocodes", l);
                daco_expired = ResourceBundle.getBundle("properties/expireddacocodes", l);
                oecd = ResourceBundle.getBundle("properties/oecdcodes", l);
                epa = ResourceBundle.getBundle("properties/epacodes", l);
            }
            
            if (coding == Constants.CODING_DACO) {
                return daco;
            } else if (coding == Constants.CODING_EXPIREDDACO){
            	return daco_expired ;
            } else if (coding == Constants.CODING_OECD) {
                return oecd;
            } else if (coding == Constants.CODING_EPA) {
                return epa;
            }
            
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    private static ResourceBundle loadSelectionListStrings(String propertiesFileName) {
        try {

            Locale l = new Locale(Preference.getLanguage(), "CA");

            return ResourceBundle.getBundle(propertiesFileName, l);

        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    /**
     * Retrieve all the code keys or all code descriptions for the specified
     * coding scheme.
     * 
     * @param coding
     *            coding scheme
     * @param selector;
     *            may take one of the values CODES or DESCRIPTIONS
     * 
     * @return Vector - all code keys or descriptions
     */
    public static Vector getCodes(int coding, int selector) {
        ResourceBundle r = getCodeResource(coding);

        if (r == null) {
            return new Vector();
        }

        return getVectorFromProperties(r, selector);
    }

    /**
     * Reset the current coding schema.
     */
    public static void resetCoding() {
        codingProperties = null;
    }

    private static Vector getVectorFromProperties(ResourceBundle r, int selector) {

        ArrayList retArray = new ArrayList();
        Enumeration keyEnum = r.getKeys();

        while (keyEnum.hasMoreElements()) {
            String code = (String) keyEnum.nextElement();
            if (selector == CODES) {
                retArray.add(code);
            } else if (selector == DESCRIPTIONS) {
                String description = r.getString(code);
                retArray.add(description);
            }
        }
        Collections.sort(retArray);
      
        return new Vector(retArray);

    }

    private static Vector getCodeVectorFromProperties(ResourceBundle r) {

        ArrayList retArray = new ArrayList();

        Enumeration keyEnum = r.getKeys();
        while (keyEnum.hasMoreElements()) {
            
        	String key = (String) keyEnum.nextElement();
            String counrty = r.getString(key);
            // HANDLES COUNTRY NAME WRAPPED IN QUOTES.
            if(counrty.indexOf('"') != -1)
            	counrty = counrty.replaceAll(String.valueOf('"'), "");

            retArray.add(new Code(key, counrty));
        }

        Collections.sort(retArray);

        return new Vector(retArray);

    }

    /**
     * Retrieve current list of countries. It may retrieve the list of 2
     * characters symbols of countries or the full names.
     * 
     * @return Vector - List of countries as 2 characters symbols, if selector
     *         has the value "CODES" or as full country names if selectors has
     *         the value "DESCRIPTIONS"
     */
    public static Vector getCountries() {
        if (listOfCountries == null) {
            listOfCountries = loadSelectionListStrings(Constants.COUNTRIES_FILE);
        }
        if (listOfCountries == null) {
            return new Vector();
        }

        return getCodeVectorFromProperties(listOfCountries);
    }

    /**
     * Retrieves the description of the code in the current coding schema.
     * 
     * @param code
     *            code key
     * 
     * @return String - description of the code
     */
    public static Code getCountryCode(String key) {
        Vector v = getCountries();
        int index = v.indexOf(new CountryCode(key, null));

        if (index >= 0) {
            return (Code) v.get(index);
        }
        return null;
    }

    /**
     * Retrieve current list of GLP-GEP status values. It may retrieve the list
     * as symbols or as description of the status values.
     * 
     * @param selector
     *            May take one of the values: CODES or DESCRIPTIONS
     * 
     * @return Vector - List values as symbols, if selector has the value
     *         "CODES" or as descriptions if selector has the value
     *         "DESCRIPTIONS"
     */
    public static Vector getGlpGepStatus() {
        if (listOfGlpGepStatus == null) {
            listOfGlpGepStatus = loadSelectionListStrings(Constants.GLP_GEP_FILE);
        }
        if (listOfGlpGepStatus == null) {
            return new Vector();
        }

        return getCodeVectorFromProperties(listOfGlpGepStatus);
    }
    
    /**
     * Retrieves the description of the code in the current coding schema.
     * 
     * @param code
     *            code key
     * 
     * @return String - description of the code
     */
    public static Code getGlpGepStatusCode(String key) {
        Vector v = getGlpGepStatus();
        int index = v.indexOf(new GlpGepCode(key, null));

        if (index >= 0) {
            return (Code) v.get(index);
        }
        return null;
    }

    /**
     * Retrieve current list of protection claimed status values. It may
     * retrieve the list as symbols or as description.
     * 
     * @param selector
     *            May take one of the values: CODES or DESCRIPTIONS
     * 
     * @return Vector - List values as symbols, if selector has the value
     *         "CODES" or as descriptions if selector has the value
     *         "DESCRIPTIONS"
     */
    /*
     * OBSOLETE public static Vector getProtectionClaimed(int selector) { if
     * (listProtectionClaimed == null) { listProtectionClaimed =
     * loadSelectionListStrings(Constants.PROTECTION_CLAIMED_FILE); } if
     * (listProtectionClaimed == null) { return null; }
     * 
     * return getVectorFromProperties(listProtectionClaimed, selector); }
     */
}