/*
 * Created on Mar 21, 2005
 */
package ca.gc.pmra.prs.client;

/**
 * @author edward-yang.xu
 */
public class GlpGepCode extends Code{

    /**
     * @param key
     * @param desc
     */
    public GlpGepCode(String key, String desc) {
        super(key, desc);
    }


    public String toString() {
        return desc;
    }

}