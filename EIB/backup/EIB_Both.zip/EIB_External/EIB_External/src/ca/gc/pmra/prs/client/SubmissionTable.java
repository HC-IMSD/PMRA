package ca.gc.pmra.prs.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Collections;
import java.util.Comparator;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 * This is the index table, shown on the upper part of the application window.
 * Each row of the table is an entry in the e-index. Not all the fields of the
 * entries are shown in the table. <br>
 * At most one instance of {@link SubmissionTable}class may exist in the system
 * at any given time.
 * 
 * @author Teddy Mihail tmihail@newbook.com
 */
public class SubmissionTable extends JPanel 
{
    private SBTable table;

    private boolean isRefreshing;

    private class SelectionChange implements ListSelectionListener, SBTableSortListener 
    {
        public void valueChanged(ListSelectionEvent e) 
        {
            ListSelectionModel lsm = (ListSelectionModel) e.getSource();
            
            if (lsm.getValueIsAdjusting()) 
                return;

            if (SubmissionTable.this.table.getRowCount() == 0) 
                return;

            int sel = lsm.getMinSelectionIndex();
            
            if (SubmissionTable.this.table.getSelectedRow() == -1) 
            {
                SubmissionTable.this.table.setRowSelectionInterval(0, 0);
                sel = 0;
            }

            if (!SubmissionTable.this.isRefreshing()) 
            {
                SubmissionDetails details = SubmissionBuilder.getDetailsPane();
                
                try 
                {
	                if (details != null) 
	                    details.setNewValues(sel);
                } 
                catch (Exception ex){}
            }

            SubmissionMenuBar.checkMenuItem();
            SubmissionToolBar.checkButton();
        }

        /**
         * Called when an <code>SBTable</code> is sorted on its header.
         * 
         * @param evt
         *            the <code>TableModelEvent</code> created by the
         *            <code>SBTableModel</code>.
         */
        public void tableSorted(TableModelEvent evt) {
            SubmissionTable.this.table.setRowSelectionInterval(0, 0);

            // When moving the selection follow it with the Details pane
            // (if showing)
            SubmissionDetails details = SubmissionBuilder.getDetailsPane();
            if (details != null) {
                details.setNewValues(0);
            }

        }

    }

    /**
     * SubmissionTable constructor.
     * 
     */
    public SubmissionTable() {

        // Make a JPanel to hold the table...
        super(new GridBagLayout());

        // this is the table
        table = new MySBTable(new MySBTableModel(), true);
        initColumn(table);
        // table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Associate with it a Selection Listener
        ListSelectionModel rowSM = table.getSelectionModel();
        rowSM.addListSelectionListener(new SelectionChange());
        table.getTableModel().addTableSortListener(new SelectionChange());

        PopupListener listener = new PopupListener();
        table.addMouseListener(listener);

        // Put a scroll pane around the table
        JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.addMouseListener(listener);
        add(scrollPane, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));

    }

    /**
     * Add a row at the end of the table. The new row is selected.
     */
    public void addRow() {

        refreshTable();

        MySBTableModel model = (MySBTableModel) table.getModel();
        int rowNb = model.getRowCount();
        table.setRowSelectionInterval(rowNb - 1, rowNb - 1);
    }

    /**
     * Insert a row in the table, above the selected one. The new row is
     * selected.
     * 
     * @return int - position of the new row
     */
    public void insertRow(int pos) {
        refreshTable();

        table.setRowSelectionInterval(pos, pos);
    }

    /**
     * Insert a row in the table, above the selected one. The new row is
     * selected.
     * 
     * @param dest
     *            destination position
     * 
     * @return int - position of the new row
     */
    public void copyRow(int pos) {
        refreshTable();

        table.setRowSelectionInterval(pos, pos);
    }

    /**
     * Remove the selected row. The row above the deleted one is selected.
     * 
     * @return int - position of the new selected row
     */
    public void removeSelectedRow(int pos) {

        refreshTable();

        MySBTableModel model = (MySBTableModel) table.getModel();
        if (pos > -1) {

            int rowNb = model.getRowCount();
            if (rowNb > 0 && pos > rowNb - 1) {
                table.setRowSelectionInterval(rowNb - 1, rowNb - 1);
            } else if (rowNb > 0 && pos <= rowNb - 1) {
                table.setRowSelectionInterval(pos, pos);
            } else if (rowNb < 0) {
                table.clearSelection();
            }
        }
    }

    /**
     * Move the selected row one position up (smaller index) in the table. If
     * the selected row is the first one it does not move.
     * 
     * @return int - <b>original </b> position or -1 if the row did not move
     */
    public int moveUpSelectedRow() {
        int selectedRow = table.getSelectedRow();
        MySBTableModel model = (MySBTableModel) table.getModel();
        if (selectedRow > 0) {
            ((SBTableModel) model).moveRow(selectedRow, selectedRow, selectedRow - 1);
            table.setRowSelectionInterval(selectedRow - 1, selectedRow - 1);
            setRowNumbers();
            return selectedRow;
        } else {
            return -1;
        }
    }

    /**
     * Move the selected row one position down (largerer index) in the table. If
     * the selected row is the last one it does not move.
     * 
     * @return int - <b>original </b> position or -1 if the row did not move
     */
    public int moveDownSelectedRow() {
        int selectedRow = table.getSelectedRow();
        MySBTableModel model = (MySBTableModel) table.getModel();
        if (selectedRow > -1 && selectedRow < model.getRowCount() - 1) {
            ((SBTableModel) model).moveRow(selectedRow, selectedRow, selectedRow + 1);
            table.setRowSelectionInterval(selectedRow + 1, selectedRow + 1);
            setRowNumbers();
            return selectedRow;
        } else {
            return -1;
        }
    }

    /**
     * Get the string in the cell defined by the selected row and the given
     * column.
     * 
     * @param column
     *            column number in the selected row to get the value from
     * 
     * @return String - value found in the specified cell
     */
    public String getCellStringAt(int column) {
        int selectedRow = table.getSelectedRow();
        MySBTableModel model = (MySBTableModel) table.getModel();
        if (selectedRow > -1) {
            return (String) model.getValueAt(selectedRow, column);
        }
        return "";
    }

    /**
     * Get the curently selected row in the table.
     * 
     * @return int - index of the selected roe in the table
     */
    public int getSelectedRow() {
        return table.getSelectedRow();
    }
    
    
    /**Set the selected row at the specified number
     * @param selectedRow
     */
    public void setSelectedRow(int selectedRow)
    {
    	table.selectRow(selectedRow);
        
    }

    /**
     * Set a a value in the specified cell of the table.
     * 
     * @param value
     *            new value of the cell
     * @param row
     *            row index in the table (starting from 0)
     * @param column
     *            column index in the table (starting from 0)
     */
    public void setCellStringAt(String value, int row, int column)
    {
    	if(column==1 && value.indexOf(",") != -1)
    		value = value.replaceAll(",", ", ");
    	
        MySBTableModel model = (MySBTableModel) table.getModel();
        model.setValueAt(value, row, column);
    }

    /*
     * This method picks the column sizes, based on the size of the column
     * headers and an arbitrarilly chosen minimum size
     */
    private void initColumn(JTable table) {
        MySBTableModel model = (MySBTableModel) table.getModel();
        TableColumn column = null;
        Component comp = null;
        // String header = "";
        int headerWidth = 0;

        TableCellRenderer headerRenderer = new TableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

                JLabel comp = new JLabel(value.toString());
                // comp.setBorder(BorderFactory.createRaisedBevelBorder());
                comp.setBorder(BorderFactory.createEtchedBorder());

                if (column == ((MySBTable) table).convertColumnIndexToView(((MySBTable) table).getSortedColumnIndex())) {
                    ImageIcon icon;
                    if (((MySBTable) table).getSortedAscending()) {
                        icon = Resources.getIcon("graphics/up16.gif");
                    } else {
                        icon = Resources.getIcon("graphics/down16.gif");
                    }
                    comp.setIcon(icon);
                }

                return comp;
            }
        };

        table.getTableHeader().setDefaultRenderer(headerRenderer);

        IndexEntry entry = SubmissionBuilder.getIndexData().getEntryInstance();

        for (int i = 0; i < table.getColumnCount(); i++) {
            column = table.getColumnModel().getColumn(i);
            if (i == 0) {
                DefaultTableCellRenderer render = new DefaultTableCellRenderer();
                render.setBackground(Color.LIGHT_GRAY); // setting the colour
                                                        // for the row column
                column.setCellRenderer(render);
                column.setPreferredWidth(table.getFont().getSize() * 4);

            } else {
                DefaultTableCellRenderer render = new DefaultTableCellRenderer() {
                    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

                        Component comp = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                        if ( !table.isRowSelected(row) ) 
                        {
                            String dox_md28 = SubmissionBuilder.getIndexData().getEntry(row).getValue(IndexEntry.DOX_MD28);
                            String dox_md29 = SubmissionBuilder.getIndexData().getEntry(row).getValue(IndexEntry.DOX_MD29);                  
                            
                            if (dox_md28 != null && dox_md28.trim().length() > 0) 
                            {
                                comp.setBackground(new Color(0xffff99));
                            } 
                            else if (dox_md29 != null && dox_md29.trim().length() > 0) 
                            {
                                comp.setBackground(new Color(255,140,000));
                            } 
                            else 
                            {
                                comp.setBackground(Color.WHITE);
                            }
                        }

                        return comp;
                    }
                };

                column.setCellRenderer(render);

                // IndexEntry entry =
                // SubmissionBuilder.getIndexData().getEntryInstance();

                int width = entry.getTableColumnWidth(entry.getFieldNumberByTableColumnNumber(i));

                column.setPreferredWidth(table.getFont().getSize() * width);
            }

        }

    }

    private void setRowNumbers() {
        MySBTableModel model = (MySBTableModel) table.getModel();
        int rowCount = model.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            model.setValueAt("" + (i + 1), i, 0);
        }
    }

    public boolean isRefreshing() {
        return isRefreshing;
    }

    public void setRefreshing(boolean b) {
        isRefreshing = b;
    }


    public void refreshTable() {

        // reset table model
        MySBTableModel model = (MySBTableModel) table.getModel();
        // table.getSelectionModel().setValueIsAdjusting(true);
        setRefreshing(true);

        table.clearSelection();
        model.removeAll();
        SubmissionData data = SubmissionBuilder.getIndexData();

       for (int i = 0; i < data.getNumberOfEntries(); i++) {
            int colNb = model.getColumnCount();
            ((SBTableModel) model).addRow(new Object[colNb]);
        }

       for (int i = 0; i < data.getNumberOfEntries(); i++) {
            IndexEntry entry = data.getEntry(i);
            for (int j = 0; j < entry.getSize(); j++) {
                if (entry.getTableColumnNumber(j) > -1) {
                    setCellStringAt(entry.getValue(j), i, entry.getTableColumnNumber(j));

                }
            }
        }
        
        SubmissionTable.this.setRowNumbers();

        // table.getSelectionModel().setValueIsAdjusting(false);
        setRefreshing(false);

        // If there is no row in the table, delete
        // the Details Pane (if showing)
        if (SubmissionTable.this.table.getRowCount() == 0) {
            SubmissionBuilder.removeDetailsPane();
            return;
        }
    }

    private class PopupListener extends MouseAdapter {

        JMenuItem add;

        JMenuItem insert;

        JMenuItem remove;

        JMenuItem copy;

        PopupListener() {
            add = new JMenuItem(Resources.getString("edit.add"));
            add.setActionCommand(CommandNames.ADD_ENTRY);
            add.addActionListener(SubmissionActions.getSubmissionActionListener());

            insert = new JMenuItem(Resources.getString("edit.insert"));
            insert.setActionCommand(CommandNames.INSERT_ENTRY);
            insert.addActionListener(SubmissionActions.getSubmissionActionListener());

            copy = new JMenuItem(Resources.getString("edit.copy"));
            copy.setActionCommand(CommandNames.COPY_ENTRY);
            copy.addActionListener(SubmissionActions.getSubmissionActionListener());

            remove = new JMenuItem(Resources.getString("edit.remove"));
            remove.setActionCommand(CommandNames.REMOVE_ENTRY);
            remove.addActionListener(SubmissionActions.getSubmissionActionListener());

        }

        public void mouseReleased(MouseEvent e) {

            // if (e.isPopupTrigger())
            if (SwingUtilities.isRightMouseButton(e)) {

                JPopupMenu popup = new JPopupMenu();

                // This handles right clicks without a selected row
                int rownum = SubmissionTable.this.table.getSelectedRow();
                if (rownum == -1) {
                    int i = SubmissionTable.this.table.rowAtPoint(new Point(e.getX(), e.getY()));
                    if (i != -1) {
                        SubmissionTable.this.table.setRowSelectionInterval(i, i);
                    }
                }
                popup.add(add);

                rownum = SubmissionTable.this.table.getSelectedRow();
                if (rownum != -1) {
                    if (table.getModel().getRowCount() > 0) {
                        popup.add(insert);
                        popup.add(copy);
                        popup.add(remove);
                    }
                }

                popup.show(e.getComponent(), e.getX(), e.getY());
            }
        }
    }

    private class MySBTable extends SBTable {

        private int sortedColumnIndex = -1;

        private boolean ascending = true;

        /**
         * Base constructor.
         * 
         * @param model
         *            the table model.
         * @param sorted
         *            <code>true</code> if the table should support sorting,
         *            <code>false</code> otherwise.
         */
        public MySBTable(SBTableModel model, boolean sorted) {
            super(model, sorted);

            setPreferredScrollableViewportSize(new Dimension(5000, 70));
            setAutoResizeMode(AUTO_RESIZE_OFF);

        }

        /**
         * Sort table data according the column
         * 
         * @param column
         *            column number
         * @param ascending
         *            true - ascending false - otherwise
         */
        public void sortByColumn(int column, boolean ascending) {

            sortedColumnIndex = column;
            this.ascending = ascending;

            // don't allow sorting column 0. It is index.
            if (column == 0) {
                sortedColumnIndex = -1;
                return;
            }

            // Get the parents and set cursor to busy
            // For unknow reason, the setCursor() does not work after a while.
            Cursor cursor = getCursor();
            Component c = this;
            while (c != null) {
                c.setCursor(new Cursor(Cursor.WAIT_CURSOR));
                c = c.getParent();
            }

            // Sets the sort criteria
            ColumnComparator comp = new ColumnComparator();
            comp.setColumnIndex(column);
            comp.setAscending(ascending);

            // Execute the sort
            Collections.sort(SubmissionBuilder.getIndexData().getSubmissionData(), comp);

            // reset table model
            SubmissionTable.this.refreshTable();

            // clear selection. Otherewise select wrong rows.
            setRowSelectionInterval(0, 0);

            // set vertical scroll bar to top.
            JScrollPane scroll = MySBTable.this.getScrollPane();
            if (scroll != null) {
                JScrollBar verBar = scroll.getVerticalScrollBar();
                verBar.setValue(verBar.getMinimum());

                scroll.validate();
                scroll.repaint();
            }

            // fire event
            getTableModel().fireTableSorted();

            // restore cursor
            c = this;
            while (c != null) {
                c.setCursor(cursor);
                c = c.getParent();
            }

        }

        /**
         * Class use to compare the different row/column values.
         */
        private class ColumnComparator implements Comparator {
            private int fieldIndex;

            private boolean ascending;

            /**
             * Sets the column index where the sort should take effect.
             * 
             * @param columnIndex
             *            the column index.
             */
            public void setColumnIndex(int columnIndex) {
                IndexEntry entry = SubmissionBuilder.getIndexData().getEntry(0);

                this.fieldIndex = entry.getFieldNumberByTableColumnNumber(columnIndex);
            }

            /**
             * Sets the sorting order.
             * 
             * @param ascending
             *            <code>true</code> will do ascending sort and
             *            <code>false</code> will do descending.
             */
            public void setAscending(boolean ascending) {
                this.ascending = ascending;
            }

            /**
             * Compares its two arguments for order. Returns a negative integer,
             * zero, or a positive integer as the first argument is less than,
             * equal to, or greater than the second.
             * <p>
             * 
             * The implementor must ensure that <tt>sgn(compare(x, y)) ==
             * -sgn(compare(y, x))</tt>
             * for all <tt>x</tt> and <tt>y</tt>. (This implies that
             * <tt>compare(x, y)</tt> must throw an exception if and only if
             * <tt>compare(y, x)</tt> throws an exception.)
             * <p>
             * 
             * The implementor must also ensure that the relation is transitive:
             * <tt>((compare(x, y)&gt;0) &amp;&amp; (compare(y, z)&gt;0))</tt>
             * implies <tt>compare(x, z)&gt;0</tt>.
             * <p>
             * 
             * Finally, the implementer must ensure that
             * <tt>compare(x, y)==0</tt> implies that
             * <tt>sgn(compare(x, z))==sgn(compare(y, z))</tt> for all
             * <tt>z</tt>.
             * <p>
             * 
             * It is generally the case, but <i>not </i> strictly required that
             * <tt>(compare(x, y)==0) == (x.equals(y))</tt>. Generally
             * speaking, any comparator that violates this condition should
             * clearly indicate this fact. The recommended language is "Note:
             * this comparator imposes orderings that are inconsistent with
             * equals."
             * 
             * @param o1
             *            the first object to be compared.
             * @param o2
             *            the second object to be compared.
             * @return a negative integer, zero, or a positive integer as the
             *         first argument is less than, equal to, or greater than
             *         the second.
             * @throws ClassCastException
             *             if the arguments' types prevent them from being
             *             compared by this Comparator.
             */
            public int compare(Object row1, Object row2) {
                String value1 = ((IndexEntry) row1).getValue(fieldIndex);
                String value2 = ((IndexEntry) row2).getValue(fieldIndex);
                
                if (value1 == null) {
                    value1 = "";
                }
                
                if (value2 == null) {
                    value2 = "";
                }
                
                if (fieldIndex == IndexEntry.NOPAGES) {
                    value1 = (new String("             ")).substring(value1.length()) + value1;
                    value2 = (new String("             ")).substring(value2.length()) + value2;
                }

                int i = value1.compareToIgnoreCase(value2);

                if (!ascending) {
                    i = i * (-1);
                }
                return i;
            }

        }

        public int getSortedColumnIndex() {
            return sortedColumnIndex;
        }

        public boolean getSortedAscending() {
            return ascending;
        }

    }

    /**
     * Customized DefaultTableModel
     */
    class MySBTableModel extends SBTableModel {

        public MySBTableModel() {

            super();

            IndexEntry entry = (new SubmissionData()).getEntryInstance();

            addColumn(Resources.getString("table.head.rowno"), String.class, 1);

            for (int i = 0; i < entry.getSize(); i++) {

                int fieldNumber = entry.getFieldNumberByTableColumnNumber(i + 1);

                // exclude SubmissionData.RCR and SubmissionData.FEEAPPLIES
                if (fieldNumber == IndexEntry.RCR || fieldNumber == IndexEntry.FEEAPPLIES) {
                    continue;
                }

                if (fieldNumber >= 0) {
                    addColumn(Resources.getString(entry.getTableColumnHeaderName(fieldNumber)), String.class, 1);
                }
            }
        }

        // Make the summary table to be read only
        public boolean isCellEditable(int row, int column) {
            return false;
        }

    }
}