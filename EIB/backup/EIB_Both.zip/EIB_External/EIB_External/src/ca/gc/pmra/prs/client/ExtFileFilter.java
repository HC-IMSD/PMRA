package ca.gc.pmra.prs.client;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/*
 * Created on Feb 15, 2005
 *
 * Show all files and directories but shortcut.
 */

/**
 * @author edward-yang.xu
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class ExtFileFilter extends javax.swing.filechooser.FileFilter {

    private List extensions = new ArrayList();

    public ExtFileFilter() {
        super();
    }

    public void addExtention(String ext) {
        extensions.add(ext);
    }

    public boolean accept(File file) {
        String filename = file.getName();
        if (filename.endsWith("lnk")) {
            return false;
        }

        if (file.isDirectory()) {
            return true;
        } else {
            if (file.isFile()) {
                for (int i=0; i<extensions.size(); i++) {
                    if (filename.endsWith((String)extensions.get(i))) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public String getDescription() {
        String desc = "";
        
        for (int i = 0; i < extensions.size(); i++) {
            desc = desc + "*" + (String)extensions.get(i) + "  ";
        }
        return desc;
    }
}