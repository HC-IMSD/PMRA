package ca.gc.pmra.prs.client;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.event.MouseInputListener;
import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;


/**
 * Class that represent a grid GUI component.
 * <P>
 * This <code>JTable</code> component support sorting on column headers.
 */
public class SBTable extends JTable {
    private SBTableModel model;
    private ColumnComparator defaultComp;

    private int lastSortedColumn = -1;
    private boolean lastAscending = false;
    private ArrayList comparatorList = new ArrayList();
    private ArrayList comparatorIndex = new ArrayList();

    private ArrayList actionList = new ArrayList();
    private String actionCommand;

    private boolean isSorted = false;

    private Rectangle rec;

    /**
     * Base constructor.
     */
    public SBTable() {
        this( true );
    }

    /**
     * Base constructor.
     *
     * @param sorted    <code>true</code> if the table should support sorting,
     * <code>false</code> otherwise.
     */
    public SBTable( boolean sorted ) {
        this( null, sorted );
    }

    /**
     * Base constructor.
     *
     * @param model     the table model.
     * @param sorted    <code>true</code> if the table should support sorting,
     * <code>false</code> otherwise.
     */
    public SBTable( SBTableModel model, boolean sorted ) {
        isSorted = sorted;

        // set hearder listener
        initColumnHeaders();

        if( model != null ) {
            setTableModel( model );
        }

        // when "Enter" is typed, call action listener
        addKeyListener(new KeyAdapter() {
                           public void keyPressed(KeyEvent e) {
                               if( e.getKeyCode() == KeyEvent.VK_ENTER ) {
                                   e.consume();

                                   for( int i=0; i<actionList.size(); i++ ) {
                                       ((ActionListener) actionList.get(i)).actionPerformed(new ActionEvent(SBTable.this, 0, SBTable.this.actionCommand));
                                   }
                               }
                           }
                       });

        // When table is visible, move the horizontal scroll bar to left. PR 117
        addAncestorListener(new AncestorListener() {

            public void ancestorAdded(AncestorEvent event) {
                JScrollPane scroll = SBTable.this.getScrollPane();
                if ( scroll != null ) {
                    JScrollBar horBar = scroll.getHorizontalScrollBar();
                    horBar.setValue(horBar.getMinimum());

                    JScrollBar verBar = scroll.getVerticalScrollBar();
                    if ( SBTable.this.getSelectedRow() >= 0 ) {
                        if( SBTable.this.getRowCount() > 0 ) {
                            int value = SBTable.this.getSelectedRow()*(verBar.getMaximum()-verBar.getMinimum())/SBTable.this.getRowCount() + verBar.getMinimum();
                            verBar.setValue(value);
                        }
                        
                    } else {
                        verBar.setValue(verBar.getMinimum());
                    }

                    scroll.validate();
                    scroll.repaint();
                }
            }
            public void ancestorRemoved(AncestorEvent event) {
            }
            public void ancestorMoved(AncestorEvent event) {
            }

        } );

    }

    /*
     * Get the scroll pane that this table exist in.
     * @return the scroll pane that this table exist in. null, if there is no scroll pane
     */
    public JScrollPane getScrollPane() {
        Component comp = this.getParent();
        while ( comp != null ) {
            if ( comp instanceof JScrollPane ) {
                return (JScrollPane) comp;
            }
            comp = comp.getParent();
        }

        return null;
    }

    /**
     * Resize the column according to the predefined column
     * size in the table model.
     */
    public void resizeColumns() {
        SBTableModel model = getTableModel();
        if( model != null ) {
            // Set sizes for columns to appropriate default sizes
            for( int i=0; i < model.getColumnCount(); i++ ) {
                int width = model.getColumnWidth(i);

                if( width >= 0 ) {
                    TableColumn col = getColumnModel().getColumn(i);
                    col.setPreferredWidth( getFont().getSize()*width );
                } else {
                    sizeColumnsToFit(i);
                }
            }
        }
    }

    /**
     * Check the table is sortable
     * @return true - the table is sortable. Otherwise, not.
     */
    public boolean isSorted() {
        return isSorted;
    }

    /**
     * Set the table sortable or not
     * @param sorted true - the table is sortable. Otherwise, not.
     */
    public void setSorted( boolean sorted ) {
        isSorted = sorted;
    }

    /**
     * adds an ActionListener to the button
     */
    public void addActionListener(ActionListener l) {
        if( l == null ) {
            return;
        } else {
            for( int i=0; i<actionList.size(); i++ ) {
                if( actionList.get(i) == l )
                    return;
            }
        }

        actionList.add(l);
    }

    /**
     * removes an ActionListener from the button
     */
    public void removeActionListener(ActionListener l) {
        for( int i=0; i<actionList.size(); i++ ) {
            if( actionList.get(i) == l )
                actionList.remove(i);
        }
    }

    /**
     * Sets the action command for this button
     */
    public void setActionCommand(String command) {
        actionCommand = command; 
    }

    /**
     * Initialize the column headers by adding a mouse listener.
     */
    private void initColumnHeaders() {
        defaultComp = new ColumnComparator();
        JTableHeader th = getTableHeader();
        th.addMouseListener( new HeaderMouseListener() );
    }

    /**
     * Override this method so that TAB and SHIFT+TAB 
     * will move the focus to the next or previous component.
     */
    public boolean isManagingFocus() {
        return false;
    }

    /**
     * set user-defined comparator
     * @param column the column index
     * @param comp the Comparator
     */
    public void setComparator(int column, Comparator comp) {
        if( comparatorList.size() <= column ) {
            int j= column - comparatorList.size() + 2;
            for( int i=0; i<j; i++ )
                comparatorList.add(null);
        }
        comparatorList.set(column, comp);
    }

    /**
     * link column1 sorting to column2 sorting. The column1 sorting is according to column2
     * @param column1 the original column.
     * @param column2 the destination column.
     */
    public void setComparatorIndex(int column1, int column2) {
        int capacity;
        if( column1 >= column2 )
            capacity = column1;
        else
            capacity = column2;

        if( comparatorIndex.size() <= capacity ) {
            int j= capacity - comparatorIndex.size() + 2;
            for( int i=0; i<j; i++ )
                comparatorIndex.add(null);
        }
        comparatorIndex.set(column1, new Integer(column2));
    }

    /**
     * remove user-defined comparator
     * @param column the column index
     */
    public void removeComparator(int column) {
        if( comparatorList.size() > column )
            comparatorList.set(column, null);
    }

    /**
     * remove all user-defined comparator
     */
    public void removeAllComparator() {
        comparatorList.clear();
    }

    /**
     * remove all sorting link
     */
    public void removeAllComparatorIndex() {
        comparatorIndex.clear();
    }

    /**
     * Returns the <B>SBTableModel</B> that provides the data displayed by
     * the receiver.
     *
     * @return  the object that provides the data displayed by the receiver
     * @see     #setTableModel
     */
    public SBTableModel getTableModel() {
        return model;
    }

    /**
     * Sets the data model for this table and registers
     * with for listner notifications from the new data model.
     *
     * @param   newModel        the new data source for this table
     * @see     #getTableModel
     * @beaninfo
     * description: The model that is the source of the data for this view.
     */
    public void setTableModel( SBTableModel model ) {
        super.setModel( model );
        this.model = model;
    }

    /**
     * Sort table data according the column
     *
     * @param   column        column number
     * @param   ascending     true - ascending  false - otherwise 
     */
    public void sortByColumn( int column, boolean ascending ) {

        // Get the parents and set cursor to busy
        // For unknow reason, the setCursor() does not work after a while.
        Cursor cursor = getCursor();
        Component c = this;
        while( c != null ) {
            c.setCursor( new Cursor( Cursor.WAIT_CURSOR ) );
            c = c.getParent();
        }

        // Sets the sort criteria
        defaultComp.setColumnIndex( column );
        defaultComp.setAscending( ascending );

        // Execute the sort
        Collections.sort( model.getDataList(), defaultComp );

        // clear selection. Otherewise select wrong rows.
        getSelectionModel().clearSelection();

        // set vertical scroll bar to top.
        JScrollPane scroll = SBTable.this.getScrollPane();
        if ( scroll != null ) {
            JScrollBar verBar = scroll.getVerticalScrollBar();
            verBar.setValue(verBar.getMinimum());

            scroll.validate();
            scroll.repaint();
        }

        // fire event
        model.fireTableSorted();

        // restore cursor
        c = this;
        while( c != null ) {
            c.setCursor( cursor );
            c = c.getParent();
        }
    }

    private class HeaderMouseListener extends MouseAdapter {
        /**
         * Invoked when the mouse has been clicked on a component.
         */
        public void mouseClicked( MouseEvent evt ) {

            if( ! isSorted() ) {
                return;
            }

            TableColumnModel columnModel = getColumnModel();
            int viewColumn = columnModel.getColumnIndexAtX( evt.getX() );

            int column = convertColumnIndexToModel( viewColumn );
            if( evt.getClickCount() == 1 && column != -1 ) {
                if( column == lastSortedColumn ) {
                    lastAscending = !lastAscending;
                } else {
                    lastAscending = true;
                }
                lastSortedColumn = column;

                sortByColumn( column, lastAscending );
            }
        }
    }

    /**
     * Class use to compare the different row/column values.
     */
    private class ColumnComparator implements Comparator {
        private int columnIndex;
        private boolean ascending;
        private Class type;

        /**
         * Sets the column index where the sort should take effect.
         *
         * @param columnIndex   the column index.
         */
        public void setColumnIndex( int columnIndex ) {
            this.columnIndex = columnIndex;
            type = model.getColumnClass( columnIndex );
        }

        /**
         * Sets the sorting order.
         *
         * @param ascending <code>true</code> will do ascending sort and 
         * <code>false</code> will do descending.
         */
        public void setAscending( boolean ascending ) {
            this.ascending = ascending;
        }

        /**
         * Compares its two arguments for order.  Returns a negative integer,
         * zero, or a positive integer as the first argument is less than, equal
         * to, or greater than the second.<p>
         *
         * The implementor must ensure that <tt>sgn(compare(x, y)) ==
         * -sgn(compare(y, x))</tt> for all <tt>x</tt> and <tt>y</tt>.  (This
         * implies that <tt>compare(x, y)</tt> must throw an exception if and only
         * if <tt>compare(y, x)</tt> throws an exception.)<p>
         *
         * The implementor must also ensure that the relation is transitive:
         * <tt>((compare(x, y)&gt;0) &amp;&amp; (compare(y, z)&gt;0))</tt> implies
         * <tt>compare(x, z)&gt;0</tt>.<p>
         *
         * Finally, the implementer must ensure that <tt>compare(x, y)==0</tt>
         * implies that <tt>sgn(compare(x, z))==sgn(compare(y, z))</tt> for all
         * <tt>z</tt>.<p>
         *
         * It is generally the case, but <i>not</i> strictly required that
         * <tt>(compare(x, y)==0) == (x.equals(y))</tt>.  Generally speaking,
         * any comparator that violates this condition should clearly indicate
         * this fact.  The recommended language is "Note: this comparator
         * imposes orderings that are inconsistent with equals."
         *
         * @param o1 the first object to be compared.
         * @param o2 the second object to be compared.
         * @return a negative integer, zero, or a positive integer as the
         * 	       first argument is less than, equal to, or greater than the
         *	       second.
         * @throws ClassCastException if the arguments' types prevent them from
         * 	       being compared by this Comparator.
         */
        public int compare( Object row1, Object row2 ) {
            Object o1 = ((Object[])row1)[columnIndex];
            Object o2 = ((Object[])row2)[columnIndex];

            // call the user-defined comparator if there is
            if( columnIndex < comparatorList.size() ) {
                Comparator comp = (Comparator) comparatorList.get(columnIndex);
                if( comp != null ) {
                    int result = comp.compare(o1, o2);
                    return ascending ? result : result*(-1);
                }
            }

            // call the user-defined comparator if there is
            if( columnIndex < comparatorIndex.size() ) {
                Integer virtualIndex = (Integer) comparatorIndex.get(columnIndex);
                if( virtualIndex != null ) {
                    o1 = ((Object[])row1)[virtualIndex.intValue()];
                    o2 = ((Object[])row2)[virtualIndex.intValue()];
                }
            }

            if( o1 == null && o2 == null ) {
                return 0;
            } else if( o1 == null ) {
                return ascending ? -1 : 1;
            } else if( o2 == null ) {
                return ascending ? 1 : -1;
            }

            // Numeric value
            if( type.getSuperclass() == java.lang.Number.class ) {
                Number n1 = (Number)o1;
                double d1 = n1.doubleValue();
                Number n2 = (Number)o2;
                double d2 = n2.doubleValue();
                if( d1 < d2 ) {
                    return ascending ? -1 : 1;
                } else if( d1 > d2 ) {
                    return ascending ? 1 : -1;
                } else {
                    return 0;
                }
                // Date values
            } else if( type == java.util.Date.class ) {
                Date d1 = (Date)o1;
                long n1 = d1.getTime();
                Date d2 = (Date)o2;
                long n2 = d2.getTime();
                if( n1 < n2 ) {
                    return ascending ? -1 : 1;
                } else if( n1 > n2 ) {
                    return ascending ? 1 : -1;
                } else {
                    return 0;
                }
                // Sting values
            } else if( type == String.class ) {
                String s1 = ((String)o1).toUpperCase();
                String s2 = ((String)o2).toUpperCase();
                int result = s1.compareTo( s2 );
                if( result < 0 ) {
                    return ascending ? -1 : 1;
                } else if( result > 0 ) {
                    return ascending ? 1 : -1;
                } else {
                    return 0;
                }
                // Boolean values
            } else if( type == Boolean.class ) {
                Boolean bool1 = (Boolean)o1;
                boolean b1 = bool1.booleanValue();
                Boolean bool2 = (Boolean)o2;
                boolean b2 = bool2.booleanValue();
                if( b1 == b2 ) {
                    return 0;
                } else if( b1 ) {
                    return ascending ? 1 : -1;
                } else {
                    return ascending ? -1 : 1;
                }
                // Any others
            } else {
                String s1 = o1.toString();
                String s2 = o2.toString();
                int result = s1.compareTo( s2 );
                if( result < 0 ) {
                    return ascending ? -1 : 1;
                } else if( result > 0 ) {
                    return ascending ? 1 : -1;
                } else {
                    return 0;
                }
            }
        }
    }

    /**
     * Convenience method that highlights a single row and scrolls 
     * the selected row into view.
     *
     * @param row The row to be highlighted and scrolled into view.
     */
    public void selectRow(int row) {
        //Get the coordinates of the row so that
        //we know where to scroll to.
        rec = getCellRect(row, 0, false);

        //Make sure that we have no other rows highlighted.
        clearSelection();

        //Highlight the wanted row.
        setRowSelectionInterval(row, row);

        //We have to call the scrolling within
        //the invoke later to ensure that the processing
        //on the table is completed. Otherwise, when reloading
        //the table then getting the rectangle, the positioning
        //may be off and scroll to the wrong place.
        SwingUtilities.invokeLater(new Runnable() {
                                       /**
                                        * When an object implementing interface <code>Runnable</code> is used
                                        * to create a thread, starting the thread causes the object's
                                        * <code>run</code> method to be called in that separately executing
                                        * thread.
                                        * <p>
                                        * The general contract of the method <code>run</code> is that it may
                                        * take any action whatsoever.
                                        *
                                        * @see     java.lang.Thread#run()
                                        */
                                       public void run() {
                                           //Scroll the wanted row into view.
                                           scrollRectToVisible(rec);
                                       }
                                   });
    }

    /**
     * Sets the table to a state where multiple rows can be selected without
     * using the CTRL or SHIFT keys. Just simply click or drag the mouse over 
     * the desired selected rows.
     */
    public void setMultiSelectOnClick(){
        setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        setUI(new MultiSelectTableUI());
    }

    /**
     * Sets the table to a state where multiple rows can be selected without
     * using the CTRL or SHIFT keys. Just simply click or drag the mouse over 
     * the desired selected rows.
     */
    public void setMultiSelectOnClick(boolean enableDrag){
        setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        setUI(new MultiSelectTableUI(enableDrag));
    }

    /**
     * Custom <code>BasicTableUI</code> class that allows us to select
     * multiple rows without using the CTRL or SHIFT keys to do so.
     */
    private class MultiSelectTableUI extends BasicTableUI{
        SBTable m_table = SBTable.this;
        private boolean dragEnabled = true;
        
        public MultiSelectTableUI(){
        }

        public MultiSelectTableUI(boolean enableDrag){
            dragEnabled = enableDrag;
        }
        
        protected MouseInputListener createMouseInputListener(){
            return new MouseInputListener(){
                    public void mouseClicked(MouseEvent e) {
                        processSelect(getRowFromY(e.getY()));
                    }
                    public void mousePressed(MouseEvent e) {
                    }
                    public void mouseReleased(MouseEvent e) {
                    }
                    public void mouseEntered(MouseEvent e) {
                    }
                    public void mouseExited(MouseEvent e) {
                    }
    
                    int currRow = 0;
                    public void mouseDragged(MouseEvent e) {
                        //Only allow a multi select my dragging if the option is on.
                        //PR# 100 (Internal)
                        if(!dragEnabled) return;

                        //Get the current row.
                        int row = getRowFromY(e.getY());
                        
                        //Only process to row select if the row changes.
                        //Otherwise, we don't want to turn on and off
                        //the highlighting for the same row.
                        if(currRow != row)
                            processSelect(row);
    
                        //Hold the value of the row so that
                        //we know when the Y position causes the
                        //row number to change.
                        currRow = row;
                    }
                    public void mouseMoved(MouseEvent e) {
                    }
            };
        }
        
        /**
         * Highlights or unhighlights a row based on the value passed in.
         * If the row is already highlighted, will unhighlight it, otherwise
         * will highlight the row.
         *
         * @param row The row number of the row we wish to highlight or unhighlight.
         */
        private void processSelect(int row){
            //No valid row selected.
            if(row == -1) return;

            //If the row is already selected, unhighlight it.
            //Otherwise, highlight it.
            if(m_table.isRowSelected(row)){
                m_table.removeRowSelectionInterval(row, row);
            }else{
                m_table.addRowSelectionInterval(row, row);
            }
        }
    
        /**
         * Returns the row number based on a Y coordinate.
         *
         * @param yCoord The Y coordinate that we wish to calculate the row number from.
         * @return The row number that the Y coordinate represents, or -1 if no row 
         *         exists for that coordinate.
         */
        private int getRowFromY(int yCoord){
            int rowHeight = m_table.getRowHeight();
            int row = yCoord / rowHeight;

            //-1 is returned if the user clicked on a void 
            //section of the table.
            return row + 1 > m_table.getRowCount() ? -1 : row;
        }
    }

    /**
     * cancel editing
     */
    public void cancelCellEditing() {
        
        TableCellEditor editor;

        for ( int i=0; i<getTableModel().getColumnCount(); i++ ) {
            try {
                editor = getColumnModel().getColumn(i).getCellEditor();
                editor.cancelCellEditing();
            } catch (Exception e) {
                //editor might be null
            }
        }
    }

    /**
     * stop editing
     */
    public void stopCellEditing() {
        
        TableCellEditor editor;

        for ( int i=0; i<getTableModel().getColumnCount(); i++ ) {
            try {
                editor = getColumnModel().getColumn(i).getCellEditor();
                editor.stopCellEditing();
            } catch (Exception e) {
                //editor might be null
            }
        }
    }

    /**
     * Enables or disables the column moving.
     *
     * @param enable True to allow column moving, false to disable column moving.
     */
    public void enableColumnMoving(boolean enable){
        JTableHeader th = getTableHeader();
        th.setReorderingAllowed(enable);
    }

}
