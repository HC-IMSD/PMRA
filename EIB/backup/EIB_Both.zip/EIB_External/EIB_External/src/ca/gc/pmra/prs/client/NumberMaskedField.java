package ca.gc.pmra.prs.client;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.BadLocationException;

/**
 * Class that represent a masked text box GUI component.
 */
public class NumberMaskedField extends NumberBox implements CaretListener, FocusListener {
    private String mask;

    protected MaskDocument maskDocObj;

    //Predetermined mask array positions.
    public static final int POSTAL_CODE = 0;

    public static final int TELEPHONE = 1;

    public static final int DATE = 2;

    //Predetermined masks.
    private static final String[][] predeterminedMasks = { { "A#A #A#", "       " }, { "(###)###-####", "(   )   -    " }, { "##/##/####", "  /  /    " } };

    //Holds the last position of the caret so that
    //we know whether the caret is going forward
    //or backwards.
    private int last_caret = 0;

    /**
     * Base constructor.
     * 
     * @param predeterminedMask
     *            the predetermined mask to use.
     * @param showAll
     *            flag that indicate if you want to see the mask characters.
     */
    public NumberMaskedField(int predeterminedMask, boolean showAll) {
        this(predeterminedMasks[predeterminedMask][0], predeterminedMasks[predeterminedMask][1], showAll);
    }

    /**
     * Base constructor.
     * 
     * @param maskVlu
     *            the mask value.
     * @param delimiters
     *            the delemiters.
     * @param showAll
     *            flag that indicate if you want to see the mask characters.
     */
    public NumberMaskedField(String maskVlu, String delimiters, boolean showAll) {
        maskDocObj = new MaskDocument(maskVlu, delimiters, showAll);
        setupMaskDocument(maskDocObj);

        addFocusListener(this);
    }
    
    /**
     * set whether or not allow input space
     * 
     * @param allow
     *            true - allow input space, otherwise not.
     */
    public void setAllowSpace(boolean allow) {
        maskDocObj.setAllowSpace(allow);
    }

    /**
     * check whether or not allow input space
     * 
     * @return true - allow input space, otherwise not.
     */
    public boolean isAllowSpace() {
        return maskDocObj.isAllowSpace();
    }

    /**
     * Initializes the masked field.
     */
    private void setupMaskDocument(MaskDocument md) {
        setDocument(md);
        mask = maskDocObj.getMask();

        //Set the length of the field so that
        //all characters will be displayed.
        setColumns(mask.length());

        addCaretListener(this);
    }

    /**
     * Invoked when a caret position has been changed.
     */
    public void caretUpdate(CaretEvent e) {
        int caret = getCaretPosition();
        boolean forward = true;

        //If the caret is after the mask,
        //there is nothing to do.
        if (getText() != null && caret != getText().length()) {
            if (caret == 0 && maskDocObj.isDelimiter(0)) {
                //Place the caret on the first available
                //non-delimiter character.
                setCaretPosition(maskDocObj.getNextCarotPosition(caret, true));
            } else if (maskDocObj.isDelimiter(caret)) {
                //Don't allow the cursor to stop on a delimiter.
                if (caret < last_caret)
                    forward = false;
                setCaretPosition(maskDocObj.getNextCarotPosition(caret, forward));
            }
        }
        last_caret = getCaretPosition();
    }

    /**
     * Sets the value of this Component.
     * 
     * @param value
     *            the new value to be set
     * @see #getText
     */
    public void setText(String t) {
        try {
            maskDocObj.insertString(0, t, null);
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the non delimited value of the field. To get the value of the field with the delimiters use the <code>getText()</code> method.
     * 
     * @return the value of the field with the delimiters.
     */
    public String getText() {

        //If the value of the field and the mask
        //are equal, it means that the user did not
        //set any value to the field. Therefore,
        //treat it as a null value.
        if (maskDocObj.getMask().equals(super.getText())) {
            return "";
        }

        String vlu = (String) super.getText();
        //return maskDocObj.stripDelims(vlu);
        return vlu;
    }

    public void focusGained(FocusEvent focusEvent) {
        int start = 0;
        String value = (String) getText();
        if (value != null && value.trim().length() > 0) {
            value = value.trim();          
            for (int i = value.length()-1; i >= 0; i--) {                
                if ( value.charAt(i) != ' ' && !maskDocObj.isDelimiter(i)) {                     
                    start = i;
                    break;
                }
            }

            setCaretPosition(start);
        }

        if (start == 0) {
            setCaretPosition(0);
        } else {
            setCaretPosition(start + 1);
        }
    }

    public void focusLost(FocusEvent focusEvent) {

    }
    
    public void setEditable(boolean t) {
        super.setEditable(t);
        
        setFocusable(t);
        
    }

}