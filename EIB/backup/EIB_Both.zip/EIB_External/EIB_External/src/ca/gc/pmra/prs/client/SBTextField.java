/*
 * Created on Feb 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ca.gc.pmra.prs.client;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

/**
 * @author edward-yang.xu
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SBTextField extends JTextField{
    
    /**
     * The display characters are any case.
     */
    public static final int ANY_CASE = 0;
    /**
     * The display characters are lower case.
     */
    public static final int LOWER_CASE = 1;
    /**
     * The display characters are upper case.
     */
    public static final int UPPER_CASE = 2;
    
    /**
     * max length of value
     */
    protected int m_maxLen = 10000;
    
    /**
     * input range
     */
    protected char[] range;
    
    /**
     * input exclude range
     */
    protected char[] excludeRange;
    
    /**
     * input case
     */
    protected int caseMode = ANY_CASE;
    
    /**
     * Constructs a new <code>TextField</code>.  A default model is created,
     * the initial string is <code>null</code>,
     * and the number of columns is set to 0.
     */
    public SBTextField() {
        this(null, null, 0);
    }

    /**
     * Constructs a new <code>TextField</code> initialized with the
     * specified text. A default model is created and the number of
     * columns is 0.
     *
     * @param text the text to be displayed, or <code>null</code>
     */
    public SBTextField(String text) {
        this(null, text, 0);
    }

    /**
     * Constructs a new empty <code>TextField</code> with the specified
     * number of columns.
     * A default model is created and the initial string is set to
     * <code>null</code>.
     *
     * @param columns  the number of columns to use to calculate 
     *   the preferred width; if columns is set to zero, the
     *   preferred width will be whatever naturally results from
     *   the component implementation
     */ 
    public SBTextField(int columns) {
        this(null, null, columns);
    }

    /**
     * Constructs a new <code>TextField</code> initialized with the
     * specified text and columns.  A default model is created.
     *
     * @param text the text to be displayed, or <code>null</code>
     * @param columns  the number of columns to use to calculate 
     *   the preferred width; if columns is set to zero, the
     *   preferred width will be whatever naturally results from
     *   the component implementation
     */
    public SBTextField(String text, int columns) {
        this(null, text, columns);
    }

    /**
     * Constructs a new <code>JTextField</code> that uses the given text
     * storage model and the given number of columns.
     * This is the constructor through which the other constructors feed.
     * If the document is <code>null</code>, a default model is created.
     *
     * @param doc  the text storage to use; if this is <code>null</code>,
     *		a default will be provided by calling the
     *		<code>createDefaultModel</code> method
     * @param text  the initial string to display, or <code>null</code>
     * @param columns  the number of columns to use to calculate 
     *   the preferred width >= 0; if <code>columns</code>
     *   is set to zero, the preferred width will be whatever
     *   naturally results from the component implementation
     * @exception IllegalArgumentException if <code>columns</code> < 0
     */
    public SBTextField(Document doc, String text, int columns) {
        super(doc, text, columns);
        
        // moev cursor to the begining when get focus
        addFocusListener(new MoveCursor());
           
    }
    
    /**
     * Constructs a new empty <code>ECTextBox</code> with the specified number of columns.
     * A default model is created and the initial string is set to null.
     *
     * @param columns  the number of columns to use to calculate 
     *   the preferred width.  If columns is set to zero, the
     *   preferred width will be whatever naturally results from
     *   the component implementation.
     * @param maxLen  the maximum number of columns  
     */
    public SBTextField( int columns, int maxLen ) {
        super( columns );

        m_maxLen = maxLen;
    }    
       
    /**
     * set max length 
     *
     * @param maxLen  the maximum number of columns  
     */
    public void setMaxLen(int maxLen ) {
        m_maxLen = maxLen;
    }
    
    /**
     * Set the characters case mode
     *
     * @param mode ANY - any case, LOWER_CASE - lower case, UPPER_CASE = upper case.
     * @see #isEditable
     */
    public void setCaseMode( int mode ) {
        switch( mode ) {
            case ANY_CASE:
            case LOWER_CASE:
            case UPPER_CASE:
                caseMode = mode;
        }
    }

    /**
     * Set the characters range
     *
     * @param charRange input chars range
     */
    public void setRange( char[] charRange ) {
        range = charRange;
    }

    /**
     * Set the exclude characters range
     *
     * @param charRange exclude input chars range
     */
    public void setExcludeRange( char[] charRange ) {
        excludeRange = charRange;
    }    
        
    /**
     * Sets the specified boolean to indicate whether or not this
     * <code>TextComponent</code> should be editable.
     * A PropertyChange event ("editable") is fired when the
     * state is changed.
     *
     * @param b the boolean to be set
     */
    public void setEditable(boolean t) {
        super.setEditable(t);
        
        setFocusable(t);
        
    }
    
    /**
     * Creates the default implementation of the model
     * to be used at construction if one isn't explicitly 
     * given.  An instance of TextDocument is returned.
     *
     * @return the default model implementation
     */
    protected Document createDefaultModel() {
        return new TextDocument();
    }

    /**
     * Get the default implementation of the model
     * to be used at construction if one isn't explicitly 
     * given.  An instance of TextDocument is returned.
     *
     * @return the default model implementation
     */
    public Document getDefaultModel() {
        return createDefaultModel();
    }
    
    // moev cursor to the begining when get focus
    private class MoveCursor implements FocusListener {        
        public void focusGained(FocusEvent focusevent) {         
            SBTextField.this.select(0, 0);
        }

        public void focusLost(FocusEvent focusevent) {
            
        }        
    }
    
    /**
     * Class that will handle maximun length
     */
    private class TextDocument extends PlainDocument {
    	
    	//String used as regular expression pattern
    	String regex = Resources.getString("string.regex");
    	
        /**
        * Inserts a string of content.  This will cause a DocumentEvent
        * of type DocumentEvent.EventType.INSERT to be sent to the
        * registered DocumentListers, unless an exception is thrown.
        * The DocumentEvent will be delivered by calling the
        * insertUpdate method on the DocumentListener.
        * The offset and length of the generated DocumentEvent
        * will indicate what change was actually made to the Document.
        * <p align=center><img src="doc-files/Document-insert.gif">
        * <p>
        * If the Document structure changed as result of the insertion,
        * the details of what Elements were inserted and removed in
        * response to the change will also be contained in the generated
        * DocumentEvent.  It is up to the implementation of a Document
        * to decide how the structure should change in response to an
        * insertion.
        * <p>
        * If the Document supports undo/redo, an UndoableEditEvent will
        * also be generated.  
        *
        * @param offset  the offset into the document to insert the content >= 0.
        *    All positions that track change at or after the given location 
        *    will move.  
        * @param str    the string to insert
        * @param a      the attributes to associate with the inserted
        *   content.  This may be null if there are no attributes.
        * @exception BadLocationException  the given insert position is not a valid 
        * position within the document
        * @see javax.swing.event.DocumentEvent
        * @see javax.swing.event.DocumentListener
        * @see javax.swing.event.UndoableEditEvent
        * @see javax.swing.event.UndoableEditListener
        */
        public void insertString(int offs, String str, AttributeSet a)
        throws BadLocationException {

            if( str == null ) {
                return;
            }

            if( (getLength()+str.length()) <= SBTextField.this.m_maxLen ) {
                // case check
                switch( SBTextField.this.caseMode ) {
                    case LOWER_CASE:
                        str = str.toLowerCase();
                        break;
                    case UPPER_CASE:
                        str = str.toUpperCase();
                        break;
                }

                // exclude range check
                if( excludeRange != null ) {
                    StringBuffer _str = new StringBuffer("");
                    for( int i=0; i<str.length(); i++ ) {
                        char c = str.charAt(i);
                        boolean found = false;

                        for( int j=0; j<excludeRange.length; j++ ) {
                            if( c == excludeRange[j] ) {
                                found = true;
                                break;
                            }
                        } 
                        if( !found ) {
                            _str.append(c);
                        }
                    }
                    str = _str.toString();
                }

                // range check
                if( range != null ) {
                    StringBuffer _str = new StringBuffer("");
                    for( int i=0; i<str.length(); i++ ) {
                        char c = str.charAt(i);
                        for( int j=0; j<range.length; j++ ) {
                            if( c == range[j] ) {
                                _str.append(c);
                                break;
                            }
                        } 
                    }
                    str = _str.toString();
                }
            	char[] specialCharacters = {'\'', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',  '�', 
            			'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�' ,'�'};
                        
            	// check for special characacters 
            	/*char[] specialCharacters = {'\'','�','�','�','�','�','�','�','�','�','�','�','�'
                    	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
                    	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
                    	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'
                    	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'};       	
               */
            	
                if( specialCharacters != null ) {
                	  	    StringBuffer tmpStr = new StringBuffer("");
                        for( int i=0; i<str.length(); i++ ) {
                            char c = str.charAt(i);
                            boolean found = false;

                            for( int j=0; j<specialCharacters.length; j++ ) {
                                if( c == specialCharacters[j] ) {
                                    found = true;
                                    break;
                                }
                            } 
                            if( !found ) {
                            	tmpStr.append(c);
                            }
                        }
                        str = tmpStr.toString();
                }

                if( str.length() > 0 )
                {
                    super.insertString(offs, str, a);
                }
            }
        }
    }
            
}
