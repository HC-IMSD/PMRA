package ca.gc.pmra.prs.client;

import java.util.EventListener;

import javax.swing.event.TableModelEvent;

/**
 * This interface defines methods required for classes wishing to listen to sort
 * events occuring in an SBTable and on an SBTableModel.
 */
public interface SBTableSortListener extends EventListener {
    /**
     * Called when an <code>SBTable</code> is sorted on its header.
     * @param evt  the <code>TableModelEvent</code> created by the <code>SBTableModel</code>.
     */    
    public void tableSorted( TableModelEvent evt );
}

