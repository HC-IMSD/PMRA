package ca.gc.pmra.prs.client;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;

/**
 * This class provides default implementations for most of the methods in the <code>TableModel</code> interface. It takes care of the management of listeners and provides some conveniences for
 * generating <code>TableModelEvents</code> and dispatching them to the listeners.
 */
public abstract class SBTableModel extends AbstractTableModel {
    /**
     * The list a row in the table.
     */
    private List dataRows = new ArrayList();

    private List columnNames = new ArrayList();

    private List columnClasses = new ArrayList();

    private List columnWidths = new ArrayList();

    public SBTableModel() {
    }

    /**
     * Adds a sort listener to this model.
     * 
     * @param l
     *            The listener to be added.
     */
    public void addTableSortListener(SBTableSortListener l) {
        listenerList.add(SBTableSortListener.class, l);
    }

    /**
     * Removes the given sort listener from the list.
     * 
     * @param l
     *            The listener to be removed.
     */
    public void removeTableSortListener(SBTableSortListener l) {
        listenerList.remove(SBTableSortListener.class, l);
    }

    /**
     * Fires a <code>tableSorted</code> notification for any listeners.
     */
    public void fireTableSorted() {
        // Guaranteed to return a non-null array
        Object[] listeners = listenerList.getListenerList();
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == SBTableSortListener.class) {
                ((SBTableSortListener) listeners[i + 1]).tableSorted(new TableModelEvent(this));
            }
        }
    }

    /**
     * Set data in this model
     * 
     * @param data
     *            ArrayList contains data
     */
    public void setDataList(List data) {
        dataRows = data;
        fireTableDataChanged();
    }

    /**
     * Get data in this model
     * 
     * @return the list of rows.
     */
    public List getDataList() {
        return dataRows;
    }

    /**
     * Returns the number of columns in the model. A <code>JTable</code> uses this method to determine how many columns it should create and display by default.
     * 
     * @return the number of columns in the model
     * @see #getRowCount
     */
    public int getColumnCount() {
        return columnNames.size();
    }

    /**
     * Returns the number of rows in the model. A <code>JTable</code> uses this method to determine how many rows it should display. This method should be quick, as it is called frequently during
     * rendering.
     * 
     * @return the number of rows in the model
     * @see #getColumnCount
     */
    public int getRowCount() {
        return dataRows.size();
    }

    /**
     * Returns the value for the cell at <code>columnIndex</code> and <code>rowIndex</code>.
     * 
     * @param row
     *            the row whose value is to be queried
     * @param col
     *            the column whose value is to be queried
     * @return the value Object at the specified cell
     */
    public Object getValueAt(int row, int col) {
        if (row >= dataRows.size()) {
            System.out.println("Warning: Number of row in the table size is lower than the row index (row=" + row + ",dataRows.size()=" + dataRows.size());
            return null;
        }

        Object[] aRow = (Object[]) dataRows.get(row);

        if (aRow == null || col >= aRow.length) {
            System.out.println("Warning: The row is null or the table size is lower than the col index (col=" + col + ", aRow.length=" + aRow.length);
            return null;
        }

        return aRow[col];
    }

    /**
     * Returns the value for the row at <code>rowIndex</code>.
     * 
     * @param row
     *            the row whose value is to be queried
     * @return the value Object[] at the specified cell
     */
    public Object[] getValueAt(int row) {
        if (row >= dataRows.size()) {
            return null;
        }
        return (Object[]) dataRows.get(row);
    }

    /**
     * Add a row to the table.
     * 
     * @param row
     *            the object that represent a row in the table.
     */
    public void addRow(Object[] row) {
        int rowNo = dataRows.size();
        dataRows.add(row);
        fireTableRowsInserted(rowNo, rowNo);
    }

    /**
     * Change a row to the table.
     * 
     * @param value
     *            the object that represent a row in the table.
     * @param row
     *            the row number which is going to be changed.
     */
    public void setValueAt(Object[] value, int row) {
        dataRows.set(row, value);
        fireTableRowsUpdated(row, row);
    }

    /**
     * Change a cell to the table.
     * 
     * @param value
     *            the object that represent a cell in the table.
     * @param row
     *            the row number which is going to be changed.
     * @param column
     *            the column number which is goig to be changed.
     */
    public void setValueAt(Object value, int row, int column) {
        if (row >= dataRows.size()) {
            return;
        }

        Object[] rowValue = (Object[]) dataRows.get(row);

        if (column >= rowValue.length) {
            return;
        }

        rowValue[column] = value;
        dataRows.set(row, rowValue);
        fireTableCellUpdated(row, column);
    }

    /**
     * Add a column to the table.
     * 
     * @param label
     *            the column label.
     */
    public void addColumn(String colLabel, Class colClass, int colWidth) {
        String columnName = null;
        try {
            columnClasses.add(colClass);
            columnWidths.add(new Integer(colWidth));
            columnName = colLabel;
            columnNames.add(columnName);
        } catch (Exception ex) {
            ex.printStackTrace();
            columnNames.add(colLabel);
        }
    }

    /**
     * Moves one or more rows from the inlcusive range <code>start</code> to <code>end</code> to the <code>to</code> position in the model. After the move, the row that was at index
     * <code>start</code> will be at index <code>to</code>. This method will send a <code>tableChanged</code> notification message to all the listeners.
     * <p>
     * 
     * <pre>
     * 
     *  
     *   
     *     Examples of moves:
     *     
     *   
     *  
     * <p>
     * 
     *  
     *   
     *     1. moveRow(1,3,5);
     *             a|B|C|D|e|f|g|h|i|j|k   - before
     *             a|e|f|g|h|B|C|D|i|j|k   - after
     *     
     *   
     *  
     * <p>
     * 
     *  
     *   
     *     2. moveRow(6,7,1);
     *             a|b|c|d|e|f|G|H|i|j|k   - before
     *             a|G|H|b|c|d|e|f|i|j|k   - after
     *     
     *   
     *  
     * <p> 
     *  </pre>
     * 
     * @param start
     *            the starting row index to be moved
     * @param end
     *            the ending row index to be moved
     * @param to
     *            the destination of the rows to be moved
     * @exception ArrayIndexOutOfBoundsException
     *                if any of the elements
     */
    public void moveRow(int start, int end, int to) {
        int shift = to - start;
        int first, last;
        if (shift < 0) {
            first = to;
            last = end;
        } else {
            first = start;
            last = to + end - start;
        }
        rotate(dataRows, first, last + 1, shift);

        fireTableRowsUpdated(first, last);
    }

    private static void rotate(List v, int a, int b, int shift) {
        int size = b - a;
        int r = size - shift;
        int g = gcd(size, r);
        for (int i = 0; i < g; i++) {
            int to = i;
            Object tmp = v.get(a + to);
            for (int from = (to + r) % size; from != i; from = (to + r) % size) {
                v.set(a + to, v.get(a + from));
                to = from;
            }
            v.set(a + to, tmp);
        }
    }

    private static int gcd(int i, int j) {
        return (j == 0) ? i : gcd(j, i % j);
    }

    /**
     * Add a row to the table at a specified index.
     * 
     * @param ndx
     *            the position of the new row in the table.
     * @param row
     *            the object array that represent a row in the table.
     */
    public void addRowAt(int ndx, Object[] row) {
        dataRows.add(ndx, row);
        fireTableRowsInserted(ndx, ndx);
    }

    /**
     * Remove a row to the table.
     * 
     * @param rowIndex
     *            the row index.
     */
    public void removeRow(int rowIndex) {
        dataRows.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
    }
    
    /**
     * Remove a row to the table.
     * 
     * @param rowIndex
     *            the row index.
     */
    public void removeAll() {         
        dataRows.clear();
        //fireTableRowsDeleted(0, 0);
    }

    /**
     * Returns the column name for the given column index.
     * 
     * @param index
     *            the column index.
     * @return the column name.
     */
    public String getColumnName(int index) {
        return (String) columnNames.get(index);
    }

    /**
     * Returns the list of column names.
     * <p>
     * All element in the list will be of type <code>String</code>.
     * 
     * @return the list of column names.
     */
    public List getColumnNames() {
        return columnNames;
    }

    /**
     * Returns the column object type for the given column index.
     * 
     * @param index
     *            the column index.
     * @return the column object type.
     */
    public Class getColumnClass(int index) {
        return (Class) columnClasses.get(index);
    }

    /**
     * Returns the column width for the given column index.
     * 
     * @param index
     *            the column index.
     * @return the column width.
     */
    public int getColumnWidth(int index) {
        Number width = (Number) columnWidths.get(index);
        if (width != null) {
            return width.intValue();
        } else {
            return 0;
        }
    }
}