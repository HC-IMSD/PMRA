package ca.gc.pmra.prs.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Utilities class.
 *
 * <br> Provides functionality for the other components of the application.
 * All its methods are static.
 *
 * @author Teddy Mihail tmihail@newbook.com
 */
public class Utils
{

    public static class FileChooserAutoExtention extends JFileChooser
    {
        private ExtFileFilter ff;
        private String ext;

        public FileChooserAutoExtention(File dir, String extString) {
            super(dir);
            ff = new ExtFileFilter();
            ff.addExtention(extString);
            ext = extString;
            setFileFilter(ff);
            
            // Set the text
            setApproveButtonText("New Approve Text");
            
            // Set the mnemonic
            setApproveButtonMnemonic('a');
            
            
            
            //addActionListener(new FileChooserListener());
        }

        public String getSelectedFileAutoExtension() {
            String fn = getSelectedFile().getName();
            if (fn.lastIndexOf(".") == -1 ||
                !fn.endsWith(ext) ) {
                fn += ext;
            }

            return fn;
        }

    }

    /**
     * Shows a dialog box where the user is asked wether to overwrite or not
     * an existing file when saving a file.
     *
     * @return one of the following values:
     * <br>          JOptionPane.YES_OPTION
     * <br>          JOptionPane.NO_OPTION
     * <br>          JOptionPane.CANCEL_OPTION
     * <br>          JOptionPane.CLOSED_OPTION
     */
    public static int showAskFileExists(String fileName)
    {
        Object[] options = { Resources.getString("string.yes"),
                             Resources.getString("string.no")};

        int ret = JOptionPane.showOptionDialog(
            SubmissionBuilder.getAppFrame(),
            Resources.getString("overwrite.existing.file", fileName),
            Resources.getString("app.name"),
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            Resources.getString("string.no"));

        return ret;
    }

    /**
     * Shows a dialog box where the user is asked wether to save or not
     * an open e-index file.
     *
     * @return one of the following values:
     * <br>          JOptionPane.YES_OPTION
     * <br>          JOptionPane.NO_OPTION
     * <br>          JOptionPane.CANCEL_OPTION
     * <br>          JOptionPane.CLOSED_OPTION
     */
    public static int showAskSave()
    {
        Object[] options = { Resources.getString("string.yes"),
                             Resources.getString("string.no"),
                             Resources.getString("string.cancel") };

        String openFile = SubmissionBuilder.getOpenFileName();
        String msg = "";
        if (openFile == null) {
            msg = Resources.getString("ask.save.new");
        }
        else {
            msg = Resources.getString("ask.save.existing", (new File(openFile)).getName());
        }

        int ret = JOptionPane.showOptionDialog(
            SubmissionBuilder.getAppFrame(),
            msg,
            Resources.getString("app.name"),
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            Resources.getString("string.yes"));

        return ret;
    }
    
    /**
     * Shows a dialog box where the user is asked wether to save or not
     * an open e-index file.
     *
     * @return one of the following values:
     * <br>          JOptionPane.YES_OPTION
     * <br>          JOptionPane.NO_OPTION
     * <br>          JOptionPane.CLOSED_OPTION
     */
    public static int showAskDelete()
    {
        Object[] options = { Resources.getString("string.yes"),
                             Resources.getString("string.no") };

        String msg = Resources.getString("ask.delete.confirm");

        int ret = JOptionPane.showOptionDialog(
            SubmissionBuilder.getAppFrame(),
            msg,
            Resources.getString("string.warning"),
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            Resources.getString("string.no"));

        return ret;
    }


   /**
     * Shows a dialog box when the user right clicks on a datacode and selects delete
     * --added by Damithri--
     *
     * @return one of the following values:
     * <br>          JOptionPane.YES_OPTION
     * <br>          JOptionPane.NO_OPTION
     * <br>          JOptionPane.CLOSED_OPTION
     */


    public static int showAskDeleteDataCode()
    {
        Object[] options = { Resources.getString("string.yes"),
                             Resources.getString("string.no") };

        String msg = Resources.getString("ask.delete.confirm_datacode");

        int ret = JOptionPane.showOptionDialog(
            SubmissionBuilder.getAppFrame(),
            msg,
            Resources.getString("string.warning"),
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            Resources.getString("string.no"));

        return ret;
    }



    /**
     * Shows a dialog box where the user is asked to select an
     * encoding schema.
     *
     * @return one of the following values:
     * <br>          {@link Constants}.CODING_DACO
     * <br>          {@link Constants}.CODING_OECD
     * <br>          {@link Constants}.CODING_EPA
     * <br>          JOptionPane.CANCEL_OPTION
     * <br>          JOptionPane.CLOSED_OPTION
     */
    public static int showSelectEncoding() {
        Object[] options = { Resources.getString("string.pmra"),
                             Resources.getString("string.oecd"),
                             Resources.getString("string.epa"),
                             Resources.getString("string.cancel") };

        int ret = JOptionPane.showOptionDialog(
            SubmissionBuilder.getAppFrame(),
            Resources.getString("msg.select.encoding"),
            Resources.getString("app.name"),
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            Resources.getString("string.pmra"));

        switch (ret) {
            case 0:
                return Constants.CODING_DACO;
            case 1:
                return Constants.CODING_OECD;
            case 2:
                return Constants.CODING_EPA;
            case 3:
                return JOptionPane.CANCEL_OPTION;
            default:
                return ret;
        }
    }

    /**
     * Copy file.
     *
     * @param sourceFileName full path and name of the source file
     * @param destinationFileName full path and name of destination file
     */
    public static void copyFile(String sourceFileName, String destinationFileName)
    throws FileNotFoundException, IOException {
        // Create a buffer for reading the files
        byte[] buf = new byte[1024];

        FileInputStream in = new FileInputStream(sourceFileName);
        FileOutputStream out = new FileOutputStream(destinationFileName);

        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }

        in.close();
        out.close();
    }

    /**
     * Create a ZIP archive containing all the files found in a
     * specified directory.
     *
     * @param directoryName full path and name of the directory
     * @param zipfileName full path and name of destination ZIP archive
     */
    public static void zipFiles(String directoryName, String zipfileName)
    throws FileNotFoundException, IOException {

        File dir = new File(directoryName);
        // collect all the file names found in the directory
        String[] fileNames = dir.list();

        // Create a buffer for reading the files
        byte[] buf = new byte[1024];
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipfileName));
        // Compress the files
        for (int i=0; i<fileNames.length; i++) {
            FileInputStream in = new FileInputStream(directoryName + File.separator + fileNames[i]);

            // Add ZIP entry to output stream.
            out.putNextEntry(new ZipEntry(fileNames[i]));

            // Transfer bytes from the file to the ZIP file
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }

            // Complete the entry
            out.closeEntry();
            in.close();
        }

        // Complete the ZIP file
        out.close();
    }

    /**
     * Delete all the files found in the specified directory.
     *
     * @param directoryName full path and name of the directory
     */
    public static void cleanDirectory(String directoryName)
    {
        File dir = new File(directoryName);
        // collect all the file names found in the directory
        String[] fileNames = dir.list();

        File f;
        for (int i=0; i<fileNames.length; i++) {
            f = new File(directoryName + File.separator + fileNames[i]);
            f.delete();
        }
        dir.delete();
    }

    /**
     * Create and show a dialog box displaying validation errors or warnings
     * generated when executing Validation or Finalize.
     * <br> The type of dialog to be displayed is given in the parameters.
     *
     * @param type type of the dialog; may be one of the values:
     * <b>  {@link Constants}.VALIDATION_ERROR_DIALOG
     * <b>  {@link Constants}.VALIDATION_WARNING_DIALOG
     * <b>  {@link Constants}.VALIDATION_OK_DIALOG
     * <b>  {@link Constants}.FINALIZE_ERROR_DIALOG
     * <b>  {@link Constants}.FINALIZE_WARNING_DIALOG
     * <b>  {@link Constants}.EXCEPTION_DIALOG
     * <b>
     * @param withPane a boolean specifying wether the dialog will display a
     *                 scrolling text pane
     * @param msg this is the string to be displayed in the dialog
     */
    public static int showReportDialog(int type, boolean withPane, String msg) {
    	
        Object displayObject;
        int ret = -1;

        String boxTitle;
        int msgType;
        if (type == Constants.VALIDATION_ERROR_DIALOG) {
            boxTitle = Resources.getString("validation.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.ERROR_MESSAGE;
        }
        else if (type == Constants.VALIDATION_WARNING_DIALOG) {
            boxTitle = Resources.getString("validation.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.WARNING_MESSAGE;
        }
        else if (type == Constants.VALIDATION_EMPTY_DIALOG) {
            boxTitle = Resources.getString("validation.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.ERROR_MESSAGE;
        }        
        else if (type == Constants.VALIDATION_OK_DIALOG) {
            boxTitle = Resources.getString("validation.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.INFORMATION_MESSAGE;
        }
        else if (type == Constants.FINALIZE_ERROR_DIALOG) {
            boxTitle = Resources.getString("finalize.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.ERROR_MESSAGE;
        }
        else if (type == Constants.FINALIZE_WARNING_DIALOG) {
            boxTitle = Resources.getString("finalize.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.WARNING_MESSAGE;
        }
        else if (type == Constants.FINALIZE_EMPTY_DIALOG) {
            boxTitle = Resources.getString("finalize.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.ERROR_MESSAGE;
        }        
        else if (type == Constants.EXCEPTION_DIALOG) {
            boxTitle = Resources.getString("exception.box.title", Resources.getString("app.name"));
            msgType = JOptionPane.ERROR_MESSAGE;
        }
        else {
            boxTitle = Resources.getString("app.name");
            msgType = JOptionPane.PLAIN_MESSAGE;
        }

        if (withPane) {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
            String labelStr;

            if (type == Constants.VALIDATION_ERROR_DIALOG) {
                labelStr = Resources.getString("validation.error.msg");
            }
            else if (type == Constants.VALIDATION_WARNING_DIALOG) {
                labelStr = Resources.getString("validation.warning.msg");
            }
            else if (type == Constants.VALIDATION_EMPTY_DIALOG) {
                labelStr = Resources.getString("finalize.empty.msg");
            }
            else if (type == Constants.FINALIZE_ERROR_DIALOG) {
                labelStr = Resources.getString("finalize.error.msg");
            }
            else if (type == Constants.FINALIZE_WARNING_DIALOG) {
                labelStr = Resources.getString("finalize.warning.msg");
            }
            else if (type == Constants.FINALIZE_EMPTY_DIALOG) {
                labelStr = Resources.getString("finalize.empty.msg");
            }
            else if (type == Constants.EXCEPTION_DIALOG) {
                labelStr = Resources.getString("exception.error.msg");
            }
            else {
                labelStr = "";
            }
            JLabel l = new JLabel(labelStr);
            panel.add(l);

            JTextArea ta = new JTextArea(msg, 5, 20);
            ta.setEditable(false);
            JScrollPane sp = new JScrollPane(ta);
            panel.add(sp);

            displayObject = panel;
        }

        else {
            displayObject = msg;
        }

        if (type == Constants.FINALIZE_WARNING_DIALOG) {
            Object[] options = { Resources.getString("stop.finalize"),
                                 Resources.getString("continue.finalize") };

            ret = JOptionPane.showOptionDialog(
                    SubmissionBuilder.getAppFrame(),
                    displayObject,
                    boxTitle,
                    JOptionPane.YES_NO_OPTION,
                    msgType,
                    null,
                    options,
                    Resources.getString("continue.finalize"));
        }
        else {
            JOptionPane.showMessageDialog(
                SubmissionBuilder.getAppFrame(),
                displayObject,
                boxTitle,
                msgType);
        }

        return ret;
    }

    public static int showExceptionDialog(Exception ex) {

        String msg = ex.toString();
        StackTraceElement[] traceEls = ex.getStackTrace();
        for (int i = 0; i < traceEls.length; i++) {
            msg += traceEls[i].toString();
        }

        return showReportDialog(Constants.EXCEPTION_DIALOG, true, msg);
    }

    public static String paddStringToRight(String str, int size) {

        String retStr = str;
        for (int i = 0; i < size - str.length(); i++) {
            retStr += " ";
        }
        return retStr;
    }

     // Used by the hash generating method
    private static final int BUFFSIZE = 100000;

    /**
     * Reads a file and generates its MD5 hash key in a hex format.
     * The code is based on the code from
     * http://www.midrangeserver.com/mgo/mgo030703-story01.html
     * by David Morris
     *
     * @param fileName name of file to be hash-ed
     * @param algorithm name of algorithm to be used (e.g. MD5)
     */
    public static String getHashText(String fileName, String algorithm)
        throws NoSuchAlgorithmException, FileNotFoundException, IOException {

        MessageDigest mdAlgorithm = MessageDigest.getInstance(algorithm);

        DigestInputStream inStream = new DigestInputStream(new FileInputStream(fileName), mdAlgorithm);

        byte[] b = new byte[BUFFSIZE];
        int ret = 0; inStream.read(b, 0, BUFFSIZE);
        while(ret != -1) {
            ret = inStream.read(b, 0, BUFFSIZE);
        }

        byte[] digest = inStream.getMessageDigest().digest();

        StringBuffer hexString = new StringBuffer();
        String plainText;
        for (int i = 0; i < digest.length; i++) {
            plainText = Integer.toHexString(0xFF & digest[i]);

            if (plainText.length() < 2) {
                plainText = "0" + plainText;
            }

            hexString.append(plainText);
        }
        String str = hexString.toString();
        return str;
    }

    /**
     * 
     * @param aCode -the daco code to examine
     * @return true if the first part of the daco code is between 2-12 ie 2.x-12.x
     */
    public static boolean isDacoCodeBetween0And1(String aCode){
    	int leadCode=0;
    	
    	if(aCode==null || aCode.length()==0){
    		System.out.println("bad");
    		return false;
    	}
    	String dacoParts[]=aCode.split("\\.");
		if(dacoParts.length>0){
			
	    	try{
	    		leadCode= Integer.parseInt(dacoParts[0]);
	    		if(leadCode==0 || leadCode==1){
	    			return true;
	    		}
	    	}catch(NumberFormatException e){}//eat the exception, musn't meet criteria}
		}
    	return false;
    }
    
}//end class

