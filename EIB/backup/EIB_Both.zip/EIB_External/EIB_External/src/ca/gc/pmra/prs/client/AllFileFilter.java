package ca.gc.pmra.prs.client;

import java.io.File;

/*
 * Created on Feb 15, 2005
 *
 * Show all files and directories but shortcut.
 */

/**
 * @author edward-yang.xu
 */
public class AllFileFilter extends javax.swing.filechooser.FileFilter 
{
    public AllFileFilter() 
    {
        super();
    }

    public boolean accept(File file) 
    {
        String filename = file.getName();        
        
        if ( filename.endsWith("lnk") ) 
            return false;

        if (file.isDirectory())
            return true;
        else if (file.isFile()) 
            return true;
        else 
            return false;
    }

    public String getDescription() 
    {
        return "All Files";
    }
}