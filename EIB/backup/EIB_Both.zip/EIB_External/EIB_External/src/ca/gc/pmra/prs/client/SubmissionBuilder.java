package ca.gc.pmra.prs.client;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

/**
 * The main class of the application. Creates and shows the application frame. <br>
 * It also provides access to the objects making for different parts of the application.
 * 
 * @author Teddy Mihail tmihail@newbook.com
 */

public class SubmissionBuilder {
    private static class MyWindowAdapter extends WindowAdapter {

        public void windowClosing(WindowEvent e) {

            SubmissionActions sa = SubmissionActions.getSubmissionActionListener();
            sa.doExit();
        }

    }

    /** Application frame. */
    private static JFrame appFrame = null;

    /** Pane holding all the application parts. */
    private static JSplitPane contentPane = null;

    /** Menu bar. */
    private static JMenuBar appMenuBar = null;

    /** The tool bar. */
    private static JToolBar appToolBar = null;

    /**
     * The index table. <br>
     * At most one instance of {@link SubmissionTable}class may exist in the system at any given time.
     */
    private static SubmissionTable eIndexTable = null;
    /**
     * The index data structure. This is the internal representation of the e-index data. <br>
     * At most one instance of {@link SubmissionData}class may exist in the system at any given time.
     */
    private static SubmissionData eIndexData = null;

    /**
     * The details pane. <br>
     * At most one instance of {@link SubmissionDetails}class may exist in the system at any given time.
     */
    private static SubmissionDetails detailsPane = null;

    /**
     * This is the coding standard used in the current e-index. <br>
     * One and only one coding standard is associated with an e-index. <br>
     * The values for the coding standards are defined in {@link Constants}
     */
    private static int codingStandard = Constants.CODING_DACO;

    /** Full path and name of the currently opened file. */
    private static String openFileName = null;
    
    /** Full path and name of the currently opened prz file. */
    private static String openPRZFileName = null;

    /** PMRA logo icon for title bar. */
    private static ImageIcon pmraLogoTitleBar = null;
    
    /** Track the last action performed in SubmissionsAction */
    private static String lastAction = null;
    
    public static int saved;

    /**
     * Create the GUI and show it. <br>
     * For thread safety, this method should be invoked from the event-dispatching thread.
     */
    private static void createAndShowGUI() {

        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        appFrame = new JFrame(Resources.getString("app.name"));
                
        pmraLogoTitleBar = Resources.getIcon(Constants.LOGO_ICON);
        appFrame.setIconImage(pmraLogoTitleBar.getImage());

        appFrame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        appFrame.setResizable(true);

        // This is a layer needed only to hold the tool bar
        JPanel topContentPane = new JPanel(new GridBagLayout());

        // We make a content pane; this is the real one
        contentPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        contentPane.setResizeWeight(0);
        //contentPane.setOneTouchExpandable(true);
        //contentPane.setFont(new Font("Monospaced", Font.PLAIN, Constants.DETAILS_MONOSPACE_FONT_SIZE));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        topPanel.setOpaque(true); //content panes must be opaque
        topPanel.setPreferredSize(new Dimension(Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT));
        contentPane.add(topPanel);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.setOpaque(true); //content panes must be opaque
        bottomPanel.setPreferredSize(new Dimension(Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT));
        contentPane.add(bottomPanel);
        
        ((JPanel) contentPane.getBottomComponent()).setVisible(false); 

        // Make the tool bar; it uses the same action listener as the menu bar
        appToolBar = SubmissionToolBar.createToolBar("", SubmissionActions.getSubmissionActionListener());

        // Put the tool bar on the top panel
        topContentPane.add(appToolBar, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));

        // Put the real content pane on the top panel
        topContentPane.add(contentPane, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        appFrame.setContentPane(topContentPane);

        //Set the menu bar and associate it with an ActionListener
        //(same one as for the tool bar)
        appMenuBar = SubmissionMenuBar.createMenuBar(SubmissionActions.getSubmissionActionListener());
        appFrame.setJMenuBar(appMenuBar);

        //add the window listener
        appFrame.addWindowListener(new MyWindowAdapter());

        //Display the window.
        // Un-comment the following line if want to
        // show it in the center of the screen
        //appFrame.setLocationRelativeTo(null);
        appFrame.pack();
        
        //Toolkit theKit = appFrame.getToolkit(); 
        //Dimension wndSize = theKit.getScreenSize(); 
        //appFrame.setBounds(0, 0, wndSize.width, wndSize.height - 50); // Size
        appFrame.setVisible(true);

        // Make frame maximize
        appFrame.setExtendedState(JFrame.MAXIMIZED_BOTH); 

        // check upgrade.
        Runnable checkUpgrade = new Runnable() {
            public void run() {
                CheckUpgrade.autoCheck();
            }
        };
        (new Thread(checkUpgrade)).start();
        
        // check menu itms and tool
        SubmissionMenuBar.checkMenuItem();
        SubmissionToolBar.checkButton();
    }

    /**
     * Get the main frame of the application.
     * 
     * @return JFrame - the application frame
     */
    public static JFrame getAppFrame() {
        if (appFrame == null) {
            createAndShowGUI();
        }
        return appFrame;
    }

    /**
     * Get the application's content pane. The one where all the GUI objects, not the top one.
     * 
     * @return JPanel - the application content pane
     */
    public static JSplitPane getContentPane() {
        if (contentPane == null) {
            createAndShowGUI();
        }
        return contentPane;
    }

    /**
     * Get the menu bar.
     * 
     * @return JMenuBar - the menu bar
     */
    public static JMenuBar getAppMenuBar() {
        if (appMenuBar == null) {
            createAndShowGUI();
        }
        return appMenuBar;
    }

    /**
     * Set the application window title.
     * 
     * @param newTitle
     *            the new title
     */
    public static void setFrameTitle(String newTitle) {
        appFrame.setTitle(newTitle);
    }

    public static String getFrameTitle() {
        //appFrame.setTitle(newTitle);
        return(appFrame.getTitle());
        
    }    
    
    
    /**
     * Creates a new index table and attaches it to the content pane. <br>
     * At most one instance of the {@link SubmissionTable}class may exist in the system at any given time. <br>
     * If the content pane is missing, it creates one.
     */
    private static void addIndexTable() {

        if (eIndexTable != null) {
            return;
        }
        if (contentPane == null) {
            createAndShowGUI();
        }

        eIndexTable = new SubmissionTable();
        eIndexTable.setOpaque(true); //content panes must be opaque
        ((JPanel) contentPane.getTopComponent()).add(eIndexTable, BorderLayout.CENTER);
        
        packAppFrame();
       
    }

    /**
     * Remove the index table from the content pane. If a details pane is showing it gets also removed.
     */
    private static void removeIndexTable() {
        if (eIndexTable != null) {
            ((JPanel) contentPane.getTopComponent()).remove(eIndexTable);
            eIndexTable = null;
            if (detailsPane != null) {
                ((JPanel) contentPane.getBottomComponent()).remove(detailsPane);
                detailsPane = null;
            }
            
            packAppFrame();
        }
    }

    /**
     * Get the index table.
     * 
     * @return SubmissionTable - the current index table.
     */
    public static SubmissionTable getIndexTable() {
        return eIndexTable;
    }

    /**
     * Create a new index data structure. <br>
     * At most one instance of the {@link SubmissionData}class may exist in the system at any given time.
     */
    private static void addIndexData() {
        if (eIndexData != null) {
            return;
        }
        eIndexData = new SubmissionData();
    }

    /**
     * Remove the index data structure.
     */
    private static void removeIndexData() {
        eIndexData = null;
    }

    /**
     * Pack the application window preserving its extended state.
     */
    private static void packAppFrame() {

        //appFrame.pack();

        appFrame.validate();
        appFrame.repaint();
    }

    /**
     * Get the index data structure.
     * 
     * @return SubmissionData - the current index data structure.
     */
    public static SubmissionData getIndexData() {
        return eIndexData;
    }

    /**
     * Create and add both the index table and the index data structure.
     */
    public static void newIndex() {
        addIndexData();
        addIndexTable();
    }

    /**
     * Remove both the index table and the index data structure.
     */
    public static void removeIndex() {
        removeIndexData();
        removeIndexTable();
    }

    /**
     * Create a new details pane and attach it to the content pane. <br>
     * At most one instance of the {@link SubmissionDetails}class may exist in the system at any given time. <br>
     * <b>Prerequisites: </b> An index table with a row selected.
     */
    public static void addDetailsPane() {
         SubmissionTable table = SubmissionBuilder.getIndexTable();

        if (table == null) {
            return;
        }

        if (detailsPane != null) {
            return;
        }
        if (contentPane == null || eIndexTable == null) {
            return;
        }

        if (contentPane != null && eIndexTable != null) {
            int selectedRow = eIndexTable.getSelectedRow();
            
            //Chek for the last action and if its a File->Open, select the first row
            String strLastAction = getLastAction();
            if (strLastAction != null)
            {
	            if(strLastAction.equalsIgnoreCase(Resources.getString("file.open.name")))
	            {
	            	selectedRow = 0;
	            	eIndexTable.setSelectedRow(selectedRow);
	            	
	            }
            }
       
            if (selectedRow < 0) {
            	return;
            }
            
            detailsPane = new SubmissionDetails(selectedRow);
            ((JPanel) contentPane.getBottomComponent()).add(detailsPane, BorderLayout.CENTER);            
            ((JPanel) contentPane.getBottomComponent()).setVisible(true);              

            contentPane.setPreferredSize(new Dimension(200, 200));
            packAppFrame();
            
            if(SubmissionBuilder.saved > 0)
            	contentPane.setDividerLocation(SubmissionBuilder.saved);
            else
            	contentPane.setDividerLocation(0.15);

        } else {
            return;
        }
    }

    /**
     * Remove the details pane.
     */
    public static void removeDetailsPane() {
        
        if (detailsPane != null) {

        	SubmissionBuilder.saved = contentPane.getDividerLocation();
        	
            ((JPanel) contentPane.getBottomComponent()).remove(detailsPane);
            detailsPane = null;
            
            ((JPanel) contentPane.getBottomComponent()).setVisible(false);
            
            packAppFrame();
        }
    }

    /**
     * Get the details pane.
     * 
     * @return SubmissionDetails - the current details pane.
     */
    public static SubmissionDetails getDetailsPane() {
        return detailsPane;
    }

    /**
     * Get the coding standard for the current e-index. <br>
     * The coding standard is returned as an integer constant defined in {@link Constants}class.
     * 
     * @return int - the coding standard.
     */
    public static int getCodingStandardInt() {
        return codingStandard;
    }

    /**
     * Get the coding standard for the current e-index. <br>
     * The coding standard is returned as a string, defined in <code>Strings.properties</code>.
     * 
     * @return String - the coding standard, or empty string.
     */
    public static String getCodingStandardStr() {
        switch (codingStandard) {
        case Constants.CODING_DACO:
            return Constants.DACO;
        case Constants.CODING_OECD:
            return Constants.OECD;
        case Constants.CODING_EPA:
            return Constants.EPA;
        default:
            return "";
        }
    }

    /**
     * Set the coding standard for the current e-index. <br>
     * The coding standard is provided as an integer constant defined in {@link Constants}class.
     * 
     * @param code -
     *            the coding standard
     */
    public static void setCodingStandard(int code) {
        codingStandard = code;
    }

    /**
     * Set the coding standard for the current e-index. <br>
     * The coding standard is provided as a string, defined in <code>Strings.properties</code>. If the actual argument is different of any of the defined strings, the coding standard is set to
     * {@link Constants}.CODING_NONE.
     * 
     * @param str -
     *            the coding standard, as a string.
     */
    public static void setCodingStandard(String str) {
        
        if (Constants.DACO.equalsIgnoreCase(str)) {
            setCodingStandard(Constants.CODING_DACO);
        } else if (Constants.OECD.equalsIgnoreCase(str)) {
            setCodingStandard(Constants.CODING_OECD);
        } else if (Constants.EPA.equalsIgnoreCase(str)) {
            setCodingStandard(Constants.CODING_EPA);
        } else {
            setCodingStandard(Constants.CODING_NONE);
        }
    }

    /**
     * Get the open file name pane.
     * 
     * @return String - the name of the open file.
     */
    public static String getOpenFileName() {
        return openFileName;
    }

    /**
     * Get the open prz file name pane.
     * 
     * @return String - the name of the open file.
     */
    public static String getOpenPRZFileName() {
        return openPRZFileName;
    }

    
    /**
     * Set the open file name pane.
     * 
     * @param fileName -
     *            the name of the open file.
     */
    public static void setOpenFileName(String fileName) {
        openFileName = fileName;
    }

    
    /**
     * Set the open prz file name pane.
     * 
     * @param fileName -
     *            the name of the open file.
     */
    public static void setPRZOpenFileName(String fileName) {
    	openPRZFileName = fileName;
    }
    

    /**Set the last action performed in SubmissionsActions
     * @param strLastAction
     */
    public static void setLastAction(String strLastAction) {
    	lastAction = strLastAction;
    }
    
 
    /** Get the last action performed in SubmissionsActions
     * @return the string representing the last action
     */
    public static String getLastAction() {
        return lastAction;
    }
    
    
    /**
     * This is the entry point in the application. <br>
     * For debugging purposes it may accept one command line option, <code>-v</code> or <code>--version</code>; in this case it prints the message normally shown in the <code>About</code> box.
     */
    public static void main(String[] args) throws Exception {

        /***********************************************************************************************************************************************************************************************
         * for ( int i = 0; i < args.length; i++ ) { if ("-server".equalsIgnoreCase(args[i]) ) { if ( i+1 < args.length ) { Preference.setServerURL(args[i+1]); } } }
         **********************************************************************************************************************************************************************************************/
    	
        //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());    	
    	//get a system property
    	String vendor = System.getProperty( "os.name" );
    	// to FIX a problem with Vista and FileChooser
    	
    	if( !vendor.contains("Windows Vista") ){
    		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    	}
    	
    	
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });

    }
}