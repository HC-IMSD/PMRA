package ca.gc.pmra.prs.client;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FocusTraversalPolicy;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.KeyboardFocusManager;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

import java.lang.Integer;

/** 
 * @author kokou.ahadjitse
 *
 */
public class SubmissionDetails extends JPanel implements AncestorListener {

	 private String _NO="N"; //this needs a better implementation
	private class SubmissionDetailsFocusTraversalPolicy extends FocusTraversalPolicy {

        private ArrayList order = new ArrayList();

        private FocusTraversalPolicy framePolicy;
        
      

        public void init() {
        	try{
            framePolicy = SubmissionBuilder.getAppFrame().getFocusTraversalPolicy();
            SubmissionBuilder.getAppFrame().setFocusTraversalPolicy(this);
        	} catch (java.lang.IllegalArgumentException iex){
        		
        	}
        }

        public void clean() {
            SubmissionBuilder.getAppFrame().setFocusTraversalPolicy(framePolicy);
            framePolicy = null;
        }

		public void addComponent(Component aComponent) {
            order.add(aComponent);
        }

        public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {

            int i;
            for (i = 0; i < order.size(); i++) {
                if ((Component) order.get(i) == aComponent) {
                    break;
                }
            }

            if (i >= order.size() - 1) {
                i = 0;
            } else {
                i++;
            }

            Component com = (Component) order.get(i);

            if (com.isFocusable() && com.isEnabled()) {
                return com;
            } else {
                return getComponentAfter(focusCycleRoot, com);
            }

            // return framePolicy.getComponentAfter(focusCycleRoot, aComponent);
        }

        public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {

            int i;
            for (i = 0; i < order.size(); i++) {
                if (aComponent.equals((Component) order.get(i))) {
                    break;
                }
            }

            if (i <= 0) {
                i = order.size() - 1;
            } else {
                i--;
            }

            Component com = (Component) order.get(i);
            if (com.isFocusable() && com.isEnabled()) {
                return com;
            } else {
                return getComponentBefore(focusCycleRoot, com);
            }

            // return framePolicy.getComponentBefore(focusCycleRoot,
            // aComponent);
        }

        public Component getFirstComponent(Container focusCycleRoot) {
            return (Component) order.get(0);
        }

        public Component getLastComponent(Container focusCycleRoot) {
            return (Component) order.get(order.size() - 1);
        }

        public Component getDefaultComponent(Container focusCycleRoot) {
            return framePolicy.getDefaultComponent(focusCycleRoot);
        }

        public Component getInitialComponent(Window window) {

            Component def = getDefaultComponent(window);
            if (def == null && window.isFocusableWindow()) {
                def = window;
            }
            return def;
        }
    }

	/*private String check_Characters(String str)
	{
        if( str != null)
        {  
        	// check for special characacters 
        	//char[] specialCharacters = {'\'', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�',  '�', 
        			//'�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�' ,'�'};
        	
        	char[] specialCharacters = {'\'','�','�','�','�','�','�','�','�','�','�','�','�'
                	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
                	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
                	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'
                	,'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�'};       	
            
            if( specialCharacters != null ) 
            {
            	StringBuffer tmpStr = new StringBuffer("");
                for( int i=0; i<str.length(); i++ ) 
                {
                	char c = str.charAt(i);
                    boolean found = false;

                    for( int j=0; j<specialCharacters.length; j++ ) 
                    {
                    	if( c == specialCharacters[j] ) 
                    	{
                    		found = true;
                    		String warningString = "\t" + Resources.getString("saveas.special.char.err", String.valueOf(c)) + "\n";
							JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.ERROR_MESSAGE);
                            //break;
                    		return null;
                        }
                    } 
                    
                    if( !found ) 
                        tmpStr.append(c); 
                }
                    
                str = tmpStr.toString();
            }
        }	
        return str;
	}    */
    
    
  

    
    private class TextFieldListener implements ActionListener, FocusListener {
        private JTextField theField;

        private int field;

        private void saveText() {
            String text = theField.getText();

            
            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, field, text);
            if (entry.getTableColumnNumber(field) > -1) {
                table.setCellStringAt(text, rowNb, entry.getTableColumnNumber(field));
            }
        }

        public TextFieldListener(JTextField tf, int fieldNb) {
            theField = tf;
            field = fieldNb;
        }

        public void actionPerformed(ActionEvent e) {
            saveText();
        }

        public void focusLost(FocusEvent e) {
            saveText();

            theField.moveCaretPosition(0);
        }

        public void focusGained(FocusEvent e) {
        }
    }

    private class SelectDocIdListener implements ItemListener, PopupMenuListener {

        public void itemStateChanged(ItemEvent e) {

            int index = docIdComboBox.getSelectedIndex();
            
            if (index == 0) {
                ((SBComboBoxEditor) docIdComboBox.getEditor()).selectAll();
                return;
            }

            if (docIdComboBox.isPopupVisible()) {
                return;
            }

            setItem();

            docIdComboBox.setSelectedIndex(0);
        }

        private void setItem() {
            int index = docIdComboBox.getSelectedIndex();

            String code = (String) Resources.getCodes(SubmissionBuilder.getCodingStandardInt(), Resources.CODES).get(index);
            
            StringTokenizer st = new StringTokenizer(docIdStr, ",");
            while (st.hasMoreElements()) {
                String s = st.nextToken();
                if (s.equals(code)) {
                    return;
                }
            }

            if (docIdStr.length() != 0) {
                docIdStr += ",";
            }
            docIdStr += code;
            DefaultListModel lm = (DefaultListModel) docId.getModel();
            lm.addElement(makeDocIdLine(code));
            docId.setSelectedIndex(lm.getSize() - 1);

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, IndexEntry.DOCID, docIdStr);

            if (entry.getTableColumnNumber(IndexEntry.DOCID) > -1) {
                table.setCellStringAt(docIdStr, rowNb, entry.getTableColumnNumber(IndexEntry.DOCID));
            }
        }

        /**
         * This method is called before the popup menu becomes visible
         */
        public void popupMenuWillBecomeVisible(PopupMenuEvent e) {

        }

        /**
         * This method is called before the popup menu becomes invisible Note
         * that a JPopupMenu can become invisible any time
         */
        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
            int index = docIdComboBox.getSelectedIndex();
            if (index == 0) {
                return;
            }

            setItem();

            docIdComboBox.setSelectedIndex(0);
        }

        /**
         * This method is called when the popup menu is canceled
         */
        public void popupMenuCanceled(PopupMenuEvent e) {

        }
    }

    private class DocIdListListener extends KeyAdapter implements MouseListener, ActionListener, FocusListener {

        JPopupMenu popup = new JPopupMenu();
        boolean popup_Enabled = false;

        DocIdListListener() {
            menuItem1 = new JMenuItem(Resources.getString("edit.remove"));
            menuItem1.setActionCommand("Delete");
            menuItem1.addActionListener(DocIdListListener.this);

            popup.add(menuItem1);
        }
        
        public void actionPerformed(ActionEvent e) {
            deleteRow();
        }

        private void deleteRow() {
        	
            int index = docId.getSelectedIndex();
      
            if (index == -1) {
                return;
            }

            int confirm = Utils.showAskDeleteDataCode();
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            DefaultListModel lm = (DefaultListModel) docId.getModel();
            lm.remove(index);
            String[] codes = docIdStr.split(",");
            docIdStr = "";
            for (int i = 0; i < codes.length; i++) {
                if (i != index) {
                    docIdStr += codes[i] + ",";
                }
            }
            // remove last ","
            if (docIdStr.length() > 0) {
                docIdStr = docIdStr.substring(0, docIdStr.length() - 1);
            }

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, IndexEntry.DOCID, docIdStr);

            if (entry.getTableColumnNumber(IndexEntry.DOCID) > -1) {
            	
                //table.setCellStringAt(docIdStr.replaceAll(",", ", "), rowNb, entry.getTableColumnNumber(IndexEntry.DOCID));            	
                table.setCellStringAt(docIdStr, rowNb, entry.getTableColumnNumber(IndexEntry.DOCID));
            }
        }

        public void keyTyped(KeyEvent e) {
            if (e.getKeyChar() == KeyEvent.VK_DELETE) {
                deleteRow();
            }
        }
        
        public void keyPressed(KeyEvent e) {
        	if (e.getKeyChar() != KeyEvent.VK_DELETE) {
                FocusEvent fl = new FocusEvent((Component)docId, FocusEvent.FOCUS_LOST);
                this.focusLost(fl);        		
        	}
        }
        

        public void mouseReleased(MouseEvent e) {
            // if (e.isPopupTrigger())
            if (SwingUtilities.isRightMouseButton(e)) {
                // This handles right clicks without a selected row
                int rownum = docId.getSelectedIndex();
                if (rownum == -1) {
                    int i = docId.locationToIndex(new Point(e.getX(), e.getY()));
                    if (i == -1) {
                        // Shouldn't happen, but we should check anyways
                        return;
                    } else {
                        docId.setSelectedIndex(i);
                    }
                }
                popup_Enabled = true;
                popup.show(e.getComponent(), e.getX(), e.getY());
            }
        }

        public void mousePressed(MouseEvent e) {
        }

        public void mouseEntered(MouseEvent e) {
        }

        public void mouseExited(MouseEvent e) {
        }

        public void mouseClicked(MouseEvent e) {
        }

		public void focusGained(FocusEvent e) {
		}
		
		public void focusLost(FocusEvent e) {
			if(!popup_Enabled)
				docId.clearSelection();
			
			popup_Enabled = false;
		}
    }

    private class SelectCountryListener implements PopupMenuListener, FocusListener, ChangeListener {

		private boolean canceled = false;

        private void saveField() {
            String countryValue = "";
            if (country.getSelectedIndex() > 0) {
                Code code = (Code) country.getSelectedItem();
                countryValue = code.getKey();
            }

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, IndexEntry.COUNTRY, countryValue);

            if (entry.getTableColumnNumber(IndexEntry.COUNTRY) > -1) {
                table.setCellStringAt(countryValue, rowNb, entry.getTableColumnNumber(IndexEntry.COUNTRY));
            }
        }

        public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
            canceled = false;
        }

        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
            saveField();
        }

        public void popupMenuCanceled(PopupMenuEvent e) {
            canceled = true;
        }

        // Allows Tab key to be used for selection method
        public void focusLost(FocusEvent e) {
            saveField();
        }

        public void focusGained(FocusEvent e) {
        }

        public void stateChanged(ChangeEvent e) {
            saveField();
        }
    }

    private class SelectFieldListener implements PopupMenuListener, FocusListener, ChangeListener {
        private JComboBox theBox;

        private int field;

        private void saveField() {
            String text = "";
            if (theBox.getSelectedIndex() > 0) {
                Code code = (Code) theBox.getSelectedItem();
                text = code.getKey();
            }
            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, field, text);

            if (entry.getTableColumnNumber(field) > -1) {
                table.setCellStringAt(text, rowNb, entry.getTableColumnNumber(field));
            }
        }

        public SelectFieldListener(JComboBox box, int fieldNb) {
            theBox = box;
            field = fieldNb;
        }

        public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
        }

        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
            saveField();
        }

        public void popupMenuCanceled(PopupMenuEvent e) {
        }

        // Allows Tab key to be used for selection method
        public void focusLost(FocusEvent e) {
            saveField();
        }

        public void focusGained(FocusEvent e) {
        }

        public void stateChanged(ChangeEvent e) {
            saveField();
        }

    }

    private class TextAreaListener implements FocusListener {
        private JTextArea theArea;

        private int field;

        public TextAreaListener(JTextArea a, int fieldNb) {
            theArea = a;
            field = fieldNb;
        }

        public void focusLost(FocusEvent e) {
            String text = theArea.getText();
            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, field, text);

            if (entry.getTableColumnNumber(field) > -1) {
                table.setCellStringAt(text, rowNb, entry.getTableColumnNumber(field));
            }
        }

        public void focusGained(FocusEvent e) {
        }

    }

    private class DateListener implements ActionListener 
    {
        private JTextField theLabel;

        private int field;

        public DateListener(JTextField l, int fieldNb) 
        {
            theLabel = l;
            field = fieldNb;
        }

        public void actionPerformed(ActionEvent e) 
        {
            Date selectedDate = DATE_CHOOSER.select();
            
            if (selectedDate == null) 
                return;
            
            /*if(selectedDate.after(new Date()))
            {
        		String warningString = "\t" + Resources.getString("date.selection.err.msg") + "\n";
        		JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.ERROR_MESSAGE);		            		            	
            	return;
            }*/
            
            
            String dateStr = DATE_FORMAT.format(selectedDate);
            theLabel.setText(dateStr);
            theLabel.setBackground(Color.WHITE);

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, field, dateStr);

            if (entry.getTableColumnNumber(field) > -1) {
                table.setCellStringAt(dateStr, rowNb, entry.getTableColumnNumber(field));
            }
        }
    }

    // ************************************CLEAR BUTTON CLASS - added by
    // Damithri Oct 25, 2005**********************

    private class ClearButtonListener implements ActionListener {

        private int fileLocationField;

        private int fileNameField;

        public ClearButtonListener(int locationFieldNb, int nameFieldNb) {
            fileLocationField = locationFieldNb;
            fileNameField = nameFieldNb;
        }

        public void actionPerformed(ActionEvent e) {

            fileLocation.setText("");
            fileName.setText("");
            
            fileLocation.setBackground(Color.LIGHT_GRAY);
            fileName.setBackground(Color.WHITE);

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);

            sd.modifyValue(rowNb, fileLocationField, "");
            sd.modifyValue(rowNb, fileNameField, "");

            if (entry.getTableColumnNumber(fileLocationField) > -1) {
                table.setCellStringAt("", rowNb, entry.getTableColumnNumber(fileLocationField));
            }
            if (entry.getTableColumnNumber(fileNameField) > -1) {
                table.setCellStringAt("", rowNb, entry.getTableColumnNumber(fileNameField));
            }
        }
    }

    // **********************************END CLEAR BUTTON
    // CLASS*********************

    // ************************************CLEAR DATE BUTTON CLASS - added by
    // Damithri Oct 25, 2005**********************

    private class ClearDateButtonListener implements ActionListener {

        private int fileDateField;

        public ClearDateButtonListener(int locationDateNb) {
            fileDateField = locationDateNb;
        }

        public void actionPerformed(ActionEvent e) {

            reportDate.setText(null);
            reportDate.setBackground(Color.LIGHT_GRAY);
            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);

            sd.modifyValue(rowNb, fileDateField, "");

            if (entry.getTableColumnNumber(fileDateField) > -1) {
                table.setCellStringAt("", rowNb, entry.getTableColumnNumber(fileDateField));
            }

        }

    }

    // **********************************END CLEAR DATE BUTTON
    // CLASS*********************

    private class RadioButtonListener implements ActionListener {

		private JRadioButton theButton;

        private int field;

        public RadioButtonListener(JRadioButton rb, int fieldNb) {
            theButton = rb;
            field = fieldNb;
        }

        public void actionPerformed(ActionEvent e) {

            String actionCommand = e.getActionCommand();
            String fieldValue = "";
            if (actionCommand != null && actionCommand.indexOf("hidden") < 0) {
                fieldValue = actionCommand;
            }

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, field, fieldValue);

            if (entry.getTableColumnNumber(field) > -1) {
                table.setCellStringAt(fieldValue, rowNb, entry.getTableColumnNumber(field));
            }
        }
    }

    private class CheckBoxListener implements ActionListener {
        private JCheckBox theBox;

        private int field;

        public CheckBoxListener(JCheckBox cb, int fieldNb) {
            theBox = cb;
            field = fieldNb;
        }

        public void actionPerformed(ActionEvent e) {

            String fieldValue = "";
            if (theBox.isSelected()) {
                fieldValue = "Y";
            } else {
                fieldValue = "N";
            }

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, field, fieldValue);

            if (entry.getTableColumnNumber(field) > -1) {
                table.setCellStringAt(fieldValue, rowNb, entry.getTableColumnNumber(field));
            }
        }
    }
    
    //required as the multiple owners xml value is a number field
    private class CheckBoxNumberListener implements ActionListener,FocusListener {
        private JCheckBox theBox;

        private int field;

        public CheckBoxNumberListener(JCheckBox cb, int fieldNb) {
            theBox = cb;
            field = fieldNb;
        }

        private void saveText() {
            String text = "0";
            if(theBox.isSelected()){
            	text = "1";
            }
            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);
            sd.modifyValue(rowNb, field, text);
            if (entry.getTableColumnNumber(field) > -1) {
                table.setCellStringAt(text, rowNb, entry.getTableColumnNumber(field));
            }
        }	
        
        public void actionPerformed(ActionEvent e) {

            saveText();
            
        }
        
        public void focusLost(FocusEvent e) {
            //saveText();

        }

        public void focusGained(FocusEvent e) {
        }
    }
    

    private class BrowseFileListener implements ActionListener, FocusListener 
    {
        private int fileLocationField;

        private int fileNameField;
        private boolean duplicate = false;

        private void saveValues() 
        {
            String fileLocationValue = fileLocation.getText();
            String fileNameValue = fileName.getText();

            SubmissionData sd = SubmissionBuilder.getIndexData();
            IndexEntry entry = sd.getEntry(rowNb);

            sd.modifyValue(rowNb, fileLocationField, fileLocationValue);
            sd.modifyValue(rowNb, fileNameField, fileNameValue);

            if (entry.getTableColumnNumber(fileLocationField) > -1) 
                table.setCellStringAt(fileLocationValue, rowNb, entry.getTableColumnNumber(fileLocationField));
            
            if (entry.getTableColumnNumber(fileNameField) > -1) 
                table.setCellStringAt(fileNameValue, rowNb, entry.getTableColumnNumber(fileNameField));
            
            for (int entryCount = 0; entryCount < sd.getSubmissionData().size(); entryCount++) 
            {           
            	if(entryCount != rowNb)
            	{
	            	entry = sd.getEntry(entryCount);
	            	String check_file_name = entry.getValue(IndexEntry.FILENAME);
	            	
	            	if(check_file_name.equalsIgnoreCase(fileNameValue) && fileNameValue.length()!=0)
	            	{
	            		duplicate = true;
	            		String warningString = "\t" + Resources.getString("validation.file.name.duplicate", fileNameValue, String.valueOf(entryCount + 1)) + "\n";
                		JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.WARNING_MESSAGE);		            		
                        fileLocation.setText("");
                        fileName.setText("");
 
	                  
	                    sd.modifyValue(rowNb, fileNameField, "");

	                    if (entry.getTableColumnNumber(fileLocationField) > -1) 
	                        table.setCellStringAt("", rowNb, entry.getTableColumnNumber(fileLocationField));
	                    
	                    if (entry.getTableColumnNumber(fileNameField) > -1) 
	                        table.setCellStringAt("", rowNb, entry.getTableColumnNumber(fileNameField));

                        
                        
	            	}
	            	else{
	            		
	            		
	            	}
            	}
            }
        }

        public BrowseFileListener(int locationFieldNb, int nameFieldNb)
        {
            fileLocationField = locationFieldNb;
            fileNameField = nameFieldNb;
        }

        public void actionPerformed(ActionEvent e) 
        {
        	/*
        	int replace_file = 1;
        	if (fileName != null && fileName.getText().length() != 0){

        		String warningString = "\t" + "WARNING: Do you really want to replace this file?" + "\n";
        		JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), 
        				warningString, 
        				Resources.getString("validation.box.title", 
        				Resources.getString("app.name")), 
        				JOptionPane.YES_NO_CANCEL_OPTION );		            		
        		
        		replace_file = JOptionPane.showConfirmDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.YES_NO_OPTION  );
        	}
        	*/
        	if(!duplicate)
        	{
	            String fileNameStr = null;
	            String fullFileNameStr = null;
	            JFileChooser fc = new JFileChooser(lastDirBrowsed);
	
	            fc.removeChoosableFileFilter(fc.getFileFilter());
	            fc.addChoosableFileFilter(new AllFileFilter());
	
	            int returnVal = fc.showOpenDialog(SubmissionBuilder.getAppFrame());
	            
	            if (returnVal != JFileChooser.APPROVE_OPTION) 
	                return;
	            
	            fileNameStr = fc.getSelectedFile().getName();
	            //fileNameStr = check_Characters(fc.getSelectedFile().getName());			
				//if(fileNameStr==null)
					//return;	   
				
	            lastDirBrowsed = fc.getCurrentDirectory();
	            fullFileNameStr = lastDirBrowsed + File.separator + fileNameStr;
	            
	            //fullFileNameStr = check_Characters(lastDirBrowsed + File.separator + fileNameStr);			
				//if(fullFileNameStr==null)
					//return;	            	 	            
	
	        	if (fileName != null && fileName.getText().length() != 0){
			        Object[] options = { Resources.getString("string.yes"),
               			 				 Resources.getString("string.no") };
	        		
	        		int replace_file = JOptionPane.showOptionDialog(SubmissionBuilder.getAppFrame(),
	        				 Resources.getString("validation.replace.efile", fileName.getText(), fileNameStr),
	        				 Resources.getString("string.warning"),
	        				 JOptionPane.YES_NO_OPTION,
	        				 JOptionPane.WARNING_MESSAGE,
	        				 null,
	        				 options,
	        				 Resources.getString("string.no"));       		
	        		
	        		
	        		if (replace_file!=0)
	        			return;
	        	}    	            
	            
	            fileLocation.setText(fullFileNameStr);
	            fileLocation.setCaretPosition(0);
	            fileLocation.setBackground(Color.WHITE);
	            
	            
	            fileName.setText(fileNameStr);
	            fileName.setBackground(Color.WHITE);
	
	            // if select file, set crossRef to NO
	            if (fileNameStr != null && fileNameStr.trim().length() > 0) 
	            {
	                Enumeration buttons = crossRef.getElements();
	                JRadioButton b1 = (JRadioButton) buttons.nextElement();
	                JRadioButton b2 = (JRadioButton) buttons.nextElement();
	                JRadioButton rbHidden = (JRadioButton) buttons.nextElement();
	
	                if (b1.isSelected()) 
	                    b2.doClick();
	            }
	
	            saveValues();
        	}
        	duplicate = false;
        }

        public void focusLost(FocusEvent e) 
        {
            saveValues();
            fileName.setCaretPosition(0);
        }

        public void focusGained(FocusEvent e) {}
    }

    private class DisableTextField extends SBTextField {
        DisableTextField(int size) {
            super(new TextDisableDocument(), null, size);
        }

        DisableTextField(String text) {
            super(new TextDisableDocument(), text, 0);
        }

        public void setText(String s) {
            TextDisableDocument doc = (TextDisableDocument) getDocument();

            doc.setEditable(true);

            super.setText(s);

            doc.setEditable(false);

        }

    }

    private class TextDisableDocument extends PlainDocument {
        boolean editable = false;

        public void setEditable(boolean b) {
            editable = b;
        }

        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (editable) {
                super.insertString(offs, str, a);
            }
        }

        public void remove(int offs, int len) throws BadLocationException {
            if (editable) {
                super.remove(offs, len);
            }
        }
    };

    private SubmissionTable table;

    private SubmissionDetailsFocusTraversalPolicy focusPolicy = new SubmissionDetailsFocusTraversalPolicy();

    private int rowNb;

    private DateFormat DATE_FORMAT;

    private DateChooser DATE_CHOOSER;

    private final String emptyString = "          ";

    private File lastDirBrowsed = null;

    private Font selectDocIdFont = new Font("Monospaced", Font.PLAIN, Constants.DETAILS_MONOSPACE_FONT_SIZE);

    private Font emptyLabelFont = new Font("Monospaced", Font.PLAIN, Constants.DETAILS_FEEAPPLIES_FONT_SIZE);

    public int getRow() {
        return rowNb;
    }

    private JMenuItem menuItem1 = null;
    
    private JButton transferButton = null;
    
    // these are all the fields in the details pane
    private ButtonGroup feeApplied = null;

    private JList docId = null;
    
    private JList itemSelectionList = null;
    
    private Vector oldDacoDodeVector = null;
    
    private SBComboBox docIdComboBox = null;

    private String docIdStr = "";

    private SBTextField author = null;

    private SBTextField title = null;

    private SBTextField labName = null;
    
   //dkilty added Feb 2013
    private SBTextField ownerID = null;

    //bdempsey added Jan 2017
    private JCheckBox ownedByThirdParty = null;
    
  //bdempsey added Jan 2017
    private JTextArea madcocode = null;
    
    private  JCheckBox multOwners=null;

    private SBTextField reportNb = null; // lab report number

    private SBTextField report_number = null;

    private SBTextField nopages = null;

    private SBComboBox glpGepStatus = null;

    private SBTextField volNb = null;

    private SBTextField city = null;

    private SBComboBox country = null;

    private SBTextField fileLocation = null;

    private SBTextField fileName = null;

    private JButton selectFileButton = null;

    private JTextArea comments = null;

    private SBTextField reportDate = null;

    private JButton dateButton = null;

    private JButton clearButton = null; // added by Damithri - Oct 25th, 2005

    private JButton clearDateButton = null;

    // restrictedToOwner replaced with Confidential Business Information
    // (CBI_APPL_IND)
    // private JCheckBox restrictedToOwner = null;
    private ButtonGroup confidential = null;

    private ButtonGroup applicant = null;

    private ButtonGroup published = null;

    private SBTextField epaMridNo = null;

    private SBTextField reqOrCond = null;

    private ButtonGroup crossRef = null;

    private SBTextField documentGroup = null;

    private SBTextField pmraDocNo = null;

    private NumberMaskedField appNo = null;

    public SubmissionDetails(int row) {
    	
        super(new GridBagLayout());

        int line;
        JPanel emptyLine;

        // get data from SubmissionBuilder
        table = SubmissionBuilder.getIndexTable();
        rowNb = row;
        
        DATE_FORMAT = new SimpleDateFormat(Resources.getString("date.format"));
        DATE_CHOOSER = new DateChooser((JFrame) SubmissionBuilder.getAppFrame(), Resources.getString("date.selection.title"));

        // This is the top level details pane
        JPanel details = new JPanel(new GridBagLayout());

        // add Document ID Label
        JLabel docIdLabel = new JLabel(Resources.getString("field.docid_html"));
        
        details.add(docIdLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 1.0, GridBagConstraints.NORTHEAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        // Create and populate the Document Id selector panel
        Vector standardCodesVector = Resources.getCodes(SubmissionBuilder.getCodingStandardInt(), Resources.CODES);
        JPanel detailsDocId = null;
        
         detailsDocId = docIdPanel(IndexEntry.DOCID, standardCodesVector);
         details.add(detailsDocId, new GridBagConstraints(1, 2, 1, 9, 1.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0)); 

        /***********************************************************************
         * Th following field is hidden temperaly
         **********************************************************************/
        /***********************************************************************
         * //add Required or Conditionaly Required Label JLabel reqCondLabel =
         * new JLabel(Resources.getString("field.reqorcond"));
         * details.add(reqCondLabel, new GridBagConstraints(2, 0, 1, 1, 0.0,
         * 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new
         * Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10),
         * 0, 0)); // add Required or Conditionaly Required Text Box reqOrCond =
         * new SBTextField(2);
         * reqOrCond.setText(entry.getValue(SubmissionData.RCR));
         * reqOrCond.setEditable(false); reqCondLabel.setLabelFor(reqOrCond);
         * details.add(reqOrCond, new GridBagConstraints(3, 0, 1, 1, 1.0, 0.0,
         * GridBagConstraints.WEST, GridBagConstraints.NONE, new
         * Insets(Constants.DETAIL_INTERVAL, 0, Constants.DETAIL_INTERVAL, 10),
         * 0, 0));
         **********************************************************************/

        // create Required or Conditionaly Required Text Box
        // But DON't display
        reqOrCond = new SBTextField(2);
        reqOrCond.setEditable(false);

        /***********************************************************************
         * Th following field is hidden temperaly
         **********************************************************************/
        /***********************************************************************
         * // add Fee feeApplied = newRadioLine(details,
         * Resources.getString("field.fee"), rowNb, SubmissionData.FEEAPPLIES,
         * 2, new String[] { Resources.getString("string.yes"),
         * Resources.getString("string.no") }, 2, 1);
         **********************************************************************/
        // create Fee
        // But DON't display
        feeApplied = newButtonGroup(Resources.getString("field.fee"), IndexEntry.FEEAPPLIES, 2, new String[] { Resources.getString("string.yes"), Resources.getString("string.no") });

        // add crosss
        JPanel crossRefPanel = new JPanel();
        crossRefPanel.setBorder(BorderFactory.createEtchedBorder());
        crossRefPanel.setOpaque(false);
        details.add(crossRefPanel, new GridBagConstraints(2, 2, 2, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 0, 2), 70, 70));

        addCrossRef(details, 2, 2);

        // add Confidential
        confidential = addConfidential(details,  2, 3);

        // add DER
        applicant = newRadioLine(details, Resources.getString("field.applicant_der_html"), IndexEntry.APPLICANT_DER, 2,
                new String[] { Resources.getString("string.yes"), Resources.getString("string.no") }, 2, 4);
        

        
       
      //add dkilty name Feb 2013
        
        JPanel ownerPanel = new JPanel();
        ownerPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        ownerPanel.setBorder(BorderFactory.createEtchedBorder());
        
       int tempLine=20;
        ownerPanel.setOpaque(false);
     
       details.add(ownerPanel, new GridBagConstraints(2, 6, 2, 8, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 
    		   new Insets(0, 2,0, 2), 60, 90));
     
       addDocOwner(details, 2, 6);
     
        /**
         * create Report Panel
         */
        line = 21;

        JPanel reportPanel = new JPanel();
        // reportPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        reportPanel.setBorder(BorderFactory.createEtchedBorder());
        // reportPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        reportPanel.setOpaque(false);
        details.add(reportPanel, new GridBagConstraints(0, line, 2, 10, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 100, 100));

        // add empty line
        emptyLine = new JPanel();
        emptyLine.setMaximumSize(new Dimension(Constants.DETAIL_TEXT_SIZE, Constants.DETAIL_TEXT_SIZE));
        details.add(emptyLine, new GridBagConstraints(0, line, 2, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        line++;

        // add Company report number
        report_number = newTextLine(details, Resources.getString("field.report_number"), IndexEntry.REPORT_NUMBER, Constants.DETAIL_TEXT_SIZE, 0, line);
        report_number.setMaxLen(256);
        line++;

        // add title
        title = newTextLine(details, Resources.getString("field.title"), IndexEntry.TITLE, Constants.DETAIL_TEXT_SIZE, 0, line);
        title.setMaxLen(2000);
        line++;

        // add author
        author = newTextLine(details, Resources.getString("field.author"), IndexEntry.AUTHOR, Constants.DETAIL_TEXT_SIZE, 0, line);
        author.setMaxLen(2000);
        line++;

        // add date
        JLabel dateLabel = new JLabel(Resources.getString("field.reportdate"));
        details.add(dateLabel, new GridBagConstraints(0, line, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        // reportDate = new SBTextField(DATE_FORMAT.format(new Date()));
        // reportDate.setEditable(false);

        // create file name
        reportDate = new DisableTextField(DATE_FORMAT.format(new Date()));
        // get mon-editable color and set it
        SBTextField tmpTextField = new SBTextField();
        tmpTextField.setEditable(false);
        //Color reportDateColor = tmpTextField.getBackground();
        // The same color doesn't work. Don't know why
        //reportDateColor = new Color(reportDateColor.getRed() + 1, reportDateColor.getGreen() + 1, reportDateColor.getBlue() + 1);
        //reportDate.setBackground(reportDateColor);
        
        reportDate.setBackground(Color.LIGHT_GRAY);

        dateButton = new JButton(Resources.getString("field.select"));
        dateButton.addActionListener(new DateListener(reportDate, IndexEntry.REPORTDATE));
        clearDateButton = new JButton(Resources.getString("field.clear"));
        clearDateButton.addActionListener(new ClearDateButtonListener(IndexEntry.REPORTDATE));

        JPanel datePanel = new JPanel(new GridBagLayout());
        datePanel.add(reportDate, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        datePanel.add(dateButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
        datePanel.add(clearDateButton, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

        details.add(datePanel, new GridBagConstraints(1, line, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 10), 0, 0));

        line++;

        // add number of pages
        nopages = newNumberLine(details, Resources.getString("field.nopages"), IndexEntry.NOPAGES, Constants.DETAIL_TEXT_SIZE, 0, line);
        nopages.setMaxLen(10);
        line++;

        // add volume
        volNb = newTextLine(details, Resources.getString("field.volnb"), IndexEntry.VOLNB, Constants.DETAIL_TEXT_SIZE, 0, line);
        volNb.setMaxLen(256);
        line++;

        // add EPA
        epaMridNo = newTextLine(details, Resources.getString("field.epamridno"), IndexEntry.EPAMRIDNO, Constants.DETAIL_TEXT_SIZE, 0, line);
        epaMridNo.setMaxLen(256);
        line++;

        emptyLine = new JPanel();
        emptyLine.setMaximumSize(new Dimension(Constants.DETAIL_TEXT_SIZE, Constants.DETAIL_TEXT_SIZE));
        details.add(emptyLine, new GridBagConstraints(0, line, 2, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        line++;
        /**
         * create Lab Panel
         */
        line = 21;

        JPanel labPanel = new JPanel();
        labPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        labPanel.setBorder(BorderFactory.createEtchedBorder());
        // labPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        labPanel.setOpaque(false);
        details.add(labPanel, new GridBagConstraints(2, line, 2, 7, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));

        // add empty line
        emptyLine = new JPanel();
        emptyLine.setMaximumSize(new Dimension(Constants.DETAIL_TEXT_SIZE, Constants.DETAIL_TEXT_SIZE));
        details.add(emptyLine, new GridBagConstraints(2, line, 2, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        line++;

        // add Lab name
        labName = newTextLine(details, Resources.getString("field.labname"), IndexEntry.LABNAME, Constants.DETAIL_TEXT_SIZE, 2, line);
        labName.setMaxLen(256);
        line++;
        
  
        
        //add Lab City
        city = newTextLine(details, Resources.getString("field.labcity"), IndexEntry.CITY, 2, 2, line);
        city.setMaxLen(256);
        line++;

        // add Lab Country
        // country combo box
        JLabel countryLabel = new JLabel(Resources.getString("field.labcountry"), JLabel.TRAILING);
        details.add(countryLabel, new GridBagConstraints(2, line, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        // country codes
        if (Resources.getCountries() != null) {
            country = new SBComboBox(Resources.getCountries());
            country.setEditable(true);
            country.setEditor(new SBComboBoxEditor(country, 5));
        } else {
            country = new SBComboBox();
            country.setEditable(true);
            country.setEditor(new SBComboBoxEditor(country, 5));
        }
        
        country.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.LIGHT_GRAY, Color.DARK_GRAY) );
        country.setPreferredSize(new Dimension(20, 20));

        country.addPopupMenuListener(new SelectCountryListener());
        country.addFocusListener(new SelectCountryListener());
        country.addChangeListener(new SelectCountryListener());

        details.add(country, new GridBagConstraints(3, line, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        line++;
        // done with country

        // add Lab Report number
        reportNb = newTextLine(details, Resources.getString("field.reportnb"), IndexEntry.REPORTNB, Constants.DETAIL_TEXT_SIZE, 2, line);
        reportNb.setMaxLen(256);
        line++;

        // add Study Carried
        glpGepStatus = newSelectionLine(details, Resources.getString("field.status"), IndexEntry.STATUS, false, Resources.getGlpGepStatus(), 2, line);
        glpGepStatus.setPreferredSize(new Dimension(20, 20));
        line++;

        // add publish
        published = newRadioLine(details, Resources.getString("field.published"), IndexEntry.PUBLISHED, 2, new String[] { Resources.getString("string.yes"), Resources.getString("string.no") }, 2,
                line);
        line++;

        // add Lab name
        documentGroup = newTextLine(details, Resources.getString("field.document_group"), IndexEntry.DOCUMENTGROUP, Constants.DETAIL_TEXT_SIZE, 2, line);
        documentGroup.setMaxLen(40);
        line++;

        // add Comments
        JLabel commentLabel = new JLabel(Resources.getString("field.comments"));
        details.add(commentLabel, new GridBagConstraints(0, 32, 1, 1, 0.0, 1.0, GridBagConstraints.NORTHEAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        comments = new SBTextArea(Constants.DETAIL_COMMENTS_ROWS, Constants.DETAIL_TEXT_SIZE, 2000);
        comments.setLineWrap(true);
        comments.setFont((new JLabel()).getFont());

        // control tab for comments
        Set keySet = new HashSet();
        keySet.add(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_TAB, 0));
        comments.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, keySet);
        comments.addFocusListener(new TextAreaListener(comments, IndexEntry.COMMENTS));

        keySet = new HashSet();
        keySet.add(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_TAB, java.awt.event.InputEvent.SHIFT_MASK));
        comments.setFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS, keySet);

        JScrollPane commentsPanel = new JScrollPane(comments, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        //commentsPanel.setFocusable(false);
        //commentsPanel.getVerticalScrollBar().setFocusable(false);

        details.add(commentsPanel, new GridBagConstraints(1, 32, 3, 1, 1.0, 1.0, GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));
        // done with comments

        // File name and location panel
        addDetailsFilePanel(details, 0, 33);

        // add scroll pane
        JScrollPane scrollPane = new JScrollPane(details, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.getVerticalScrollBar().setUnitIncrement(10);
        scrollPane.getHorizontalScrollBar().setUnitIncrement(10);
        //scrollPane.setFocusable(false);

        this.add(scrollPane, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(Constants.DETAIL_INTERVAL, 5, Constants.DETAIL_INTERVAL, 5), 0,
                0));

        // set focus
        setFocusTraversalPolicy();

        // add AncestorListener
        this.addAncestorListener(this);
        // initial value
        setNewValues(rowNb);
    }

    private void setFocusTraversalPolicy() {

        //focusPolicy.addComponent(docIdComboBox.getEditor().getEditorComponent());
        focusPolicy.addComponent(docId);
        focusPolicy.addComponent(transferButton);
        focusPolicy.addComponent(itemSelectionList);

        focusPolicy.addComponent(report_number);
        
        focusPolicy.addComponent(title);

        focusPolicy.addComponent(author);

        focusPolicy.addComponent(dateButton);

        focusPolicy.addComponent(clearDateButton); // added by Damithri - Oct
        // 25th,2005

        focusPolicy.addComponent(nopages);

        focusPolicy.addComponent(volNb);

        focusPolicy.addComponent(epaMridNo);

        /***********************************************************************
         * Th following field is hidden temperaly
         **********************************************************************/
        /***********************************************************************
         * focusPolicy.addComponent(reqOrCond);
         * 
         * Enumeration feeAppliedButtons = feeApplied.getElements(); while
         * (feeAppliedButtons.hasMoreElements()) {
         * focusPolicy.addComponent((Component)
         * feeAppliedButtons.nextElement()); }
         **********************************************************************/

        Enumeration crossRefButtons = crossRef.getElements();
        while (crossRefButtons.hasMoreElements()) {
            focusPolicy.addComponent((Component) crossRefButtons.nextElement());
        }

        focusPolicy.addComponent(pmraDocNo);

        focusPolicy.addComponent(appNo);

        Enumeration confidentialButtons = confidential.getElements();
        while (confidentialButtons.hasMoreElements()) {
            focusPolicy.addComponent((Component) confidentialButtons.nextElement());
        }

        Enumeration applicantButtons = applicant.getElements();
        while (applicantButtons.hasMoreElements()) {
            focusPolicy.addComponent((Component) applicantButtons.nextElement());
        }

        focusPolicy.addComponent(ownerID);
        focusPolicy.addComponent(multOwners);
       
        focusPolicy.addComponent(labName);
      
        focusPolicy.addComponent(city);

        focusPolicy.addComponent(country.getEditor().getEditorComponent());

        focusPolicy.addComponent(reportNb);

        focusPolicy.addComponent(glpGepStatus.getEditor().getEditorComponent());

        Enumeration publishButtons = published.getElements();
        while (publishButtons.hasMoreElements()) {
            focusPolicy.addComponent((Component) publishButtons.nextElement());
        }

        focusPolicy.addComponent(documentGroup);

        focusPolicy.addComponent(comments);
        focusPolicy.addComponent(fileName);
        focusPolicy.addComponent(selectFileButton);

        focusPolicy.addComponent(clearButton); // added by Damithri - Oct
        // 25th,2005

        focusPolicy.addComponent(fileLocation);

    }

    public void ancestorAdded(AncestorEvent event) {
        focusPolicy.init();
    }

    public void ancestorRemoved(AncestorEvent event) {
        focusPolicy.clean();
    }

    public void ancestorMoved(AncestorEvent event) {

    }

    public void setNewValues(int row) 
    {
        SubmissionData data = SubmissionBuilder.getIndexData();
        int entriesNb = data.getNumberOfEntries();

        if (row < 0 || row >= entriesNb) {
            return;
        }
        
        //int counter = 0;
        rowNb = row;
        IndexEntry entry = data.getEntry(row);
        docIdStr = entry.getValue(IndexEntry.DOCID);
        docIdComboBox.setSelectedIndex(0);
        DefaultListModel lm = (DefaultListModel) docId.getModel();
        lm.removeAllElements();
        // selection is a string made of comma separated codes
        String[] entryCodes = docIdStr.split(",");
        
        if (entryCodes.length > 0) 
        {
            String ret = makeDocIdLine(entryCodes[0]);
            if (ret.length() > 0) 
                lm.addElement(ret);
            
            try 
            {
		            for (int i = 1; i < entryCodes.length; i++) 
		            {
		                ret = makeDocIdLine(entryCodes[i]);
		                lm.addElement(ret);
		            }
            } 
            catch(Exception e)
            {           	
            	//Something happened on an expired character.
            	 int counter = 6;
            	 e.printStackTrace();
            }
        }
        author.setText(entry.getValue(IndexEntry.AUTHOR));
        author.moveCaretPosition(0);
        ownerID.setText(entry.getValue(IndexEntry.DOX_MD36));
        ownerID.moveCaretPosition(0);
 
        //set as one
        if(entry.getValue(IndexEntry.DOX_MD36C).compareTo("1") == 0){
        	ownedByThirdParty.setSelected(true);
        	madcocode.setVisible(true);
        }else{
        	ownedByThirdParty.setSelected(false);
        	madcocode.setVisible(false);
        }
        
        //set as one
        if(entry.getValue(IndexEntry.DOX_MD44).compareTo("1") == 0){
        	multOwners.setSelected(true);
        }else{
        	multOwners.setSelected(false);	
        }
        title.setText(entry.getValue(IndexEntry.TITLE));
        title.moveCaretPosition(0);
		
        labName.setText(entry.getValue(IndexEntry.LABNAME));
		labName.moveCaretPosition(0);
        
		reportNb.setText(entry.getValue(IndexEntry.REPORTNB));
        report_number.setText(entry.getValue(IndexEntry.REPORT_NUMBER));
        
        nopages.setText(entry.getValue(IndexEntry.NOPAGES));
        volNb.setText(entry.getValue(IndexEntry.VOLNB));
        
        city.setText(entry.getValue(IndexEntry.CITY));

        String glpgepValue = entry.getValue(IndexEntry.STATUS);
        
        if (glpgepValue == null || glpgepValue.length() == 0) 
        {
            glpGepStatus.setSelectedIndex(0);
        } 
        else 
        {
            int index = -1;
            if (glpgepValue != null) 
            {
                Code glpGepCode = Resources.getGlpGepStatusCode(glpgepValue);
                index = Resources.getGlpGepStatus().indexOf(glpGepCode);
            }

            index = index == -1 ? 0 : index;
            glpGepStatus.setSelectedIndex(index);
        }

        String countryValue = entry.getValue(IndexEntry.COUNTRY);
        
        if (countryValue == null || countryValue.length() == 0) 
        {
            country.setSelectedIndex(0);
        } 
        else 
        {

            int index = -1;
            if (countryValue != null)
            {
                Code countryCode = Resources.getCountryCode(countryValue);
                index = Resources.getCountries().indexOf(countryCode);
            }

            index = index == -1 ? 0 : index;
            country.setSelectedIndex(index);
        }

        // set document group
        documentGroup.setText(entry.getValue(IndexEntry.DOCUMENTGROUP));

        fileLocation.setText(entry.getValue(IndexEntry.FILELOCATION));
        fileLocation.moveCaretPosition(0);
        
        if(entry.getValue(IndexEntry.FILELOCATION).length() > 0)
        	fileLocation.setBackground(Color.WHITE);
        else
        	fileLocation.setBackground(Color.LIGHT_GRAY);
        
        
        
        
        fileName.setText(entry.getValue(IndexEntry.FILENAME));
        fileName.moveCaretPosition(0);
        if(entry.getValue(IndexEntry.FILENAME).length() > 0)
        	fileName.setBackground(Color.WHITE);
        else
        	fileName.setBackground(Color.LIGHT_GRAY);
        
        comments.setText(entry.getValue(IndexEntry.COMMENTS));
        comments.moveCaretPosition(0);
        
        epaMridNo.setText(entry.getValue(IndexEntry.EPAMRIDNO));

        pmraDocNo.setText(entry.getValue(IndexEntry.PMRA_DOC_NO));
        appNo.setText(entry.getValue(IndexEntry.APP_NO));

        String dateStr = entry.getValue(IndexEntry.REPORTDATE);
        reportDate.setText(dateStr);
        if(dateStr.length() > 0)
        	reportDate.setBackground(Color.WHITE);
        

        setButtonGroupSelection(feeApplied, entry.getValue(IndexEntry.FEEAPPLIES), null);
        setButtonGroupSelection(published, entry.getValue(IndexEntry.PUBLISHED), null);

        // keep orig value because set crossRef cause CONFIDENTIAL and
        // APPLICANT_DER changed
        String conf = entry.getValue(IndexEntry.CONFIDENTIAL);
        String der = entry.getValue(IndexEntry.APPLICANT_DER);

        setButtonGroupSelection(crossRef, entry.getValue(IndexEntry.CROSS_REF), null);
        setButtonGroupSelection(confidential, conf, null);
        setButtonGroupSelection(applicant, der, null);

        //INITIALIZATION
        if (entry.getValue(IndexEntry.CROSS_REF) != null && entry.getValue(IndexEntry.CROSS_REF).equalsIgnoreCase("Y")) 
        {
        	setEnableButtonGroup(confidential, false);
            setEnableButtonGroup(applicant, false);
            
            pmraDocNo.setEditable(true);
            appNo.setEditable(true);
            
            appNo.setBackground(Color.WHITE);
            pmraDocNo.setBackground(Color.WHITE); 

        } 
        else if (entry.getValue(IndexEntry.CROSS_REF) != null && entry.getValue(IndexEntry.CROSS_REF).equalsIgnoreCase("N")) 
        {
        	setEnableButtonGroup(confidential, true);
            setEnableButtonGroup(applicant, true);
            
            pmraDocNo.setEditable(false);
            appNo.setEditable(false);
            
            appNo.setBackground(Color.LIGHT_GRAY);
            pmraDocNo.setBackground(Color.LIGHT_GRAY);
            
            //fileLocation.setBackground(Color.WHITE);
            //fileName.setBackground(Color.WHITE);

        } 
        else
        {
        	setEnableButtonGroup(confidential, true);
            setEnableButtonGroup(applicant, true);
            
            pmraDocNo.setEditable(false);
            appNo.setEditable(false);
            
            appNo.setBackground(Color.LIGHT_GRAY);
            pmraDocNo.setBackground(Color.LIGHT_GRAY);            

        }	
        
        // INITIALIZATION
        // set state of doc no and app no
        if (crossRef.getSelection() != null) 
        {
            String actionCommand = crossRef.getSelection().getActionCommand();
            if ("N".equalsIgnoreCase(actionCommand)) 
            {
                selectFileButton.setEnabled(true);
                clearButton.setEnabled(true);

                if(SubmissionBuilder.getOpenFileName()==null && fileLocation.getText().length() < 1){// && SubmissionBuilder.getOpenPRZFileName().endsWith(".prz")   )
                	fileLocation.setBackground(Color.LIGHT_GRAY);
                }
                else if(SubmissionBuilder.getOpenFileName()==null && fileLocation.getText().length() > 1){
                	fileLocation.setBackground(Color.WHITE);
                }
                else if(SubmissionBuilder.getOpenFileName()!=null && fileLocation.getText().length() < 1){
                	fileLocation.setBackground(Color.LIGHT_GRAY);
                }
                else if(SubmissionBuilder.getOpenPRZFileName()!=null && SubmissionBuilder.getOpenPRZFileName().endsWith(".prz")){
                	fileLocation.setBackground(Color.LIGHT_GRAY);
                }
                else{
                	fileLocation.setBackground(Color.WHITE);
                }
                
                fileName.setBackground(Color.WHITE);
            } 
            else 
            {
                selectFileButton.setEnabled(false);
                clearButton.setEnabled(false);
            }
        } 
        else 
        {
        	/* TODO 
        	 * This looks like un-reachable code. 
        	 * confirm when there is time.
        	 */
            selectFileButton.setEnabled(false);
            clearButton.setEnabled(false);
        }

        /*************START**************/
        String dox_md28 = entry.getValue(IndexEntry.DOX_MD28);
        
        
        if (dox_md28 == null || dox_md28.trim().length() == 0) 
        {
            Enumeration confidentialButtons = confidential.getElements();
            confidentialButtons.nextElement();
            confidentialButtons.nextElement();
            
            while (confidentialButtons.hasMoreElements()) 
            {
                JRadioButton b = (JRadioButton) confidentialButtons.nextElement();
                b.setVisible(false);
            }

            menuItem1.setEnabled(true);
            transferButton.setEnabled(true);            
            
		    setEnableButtonGroup(crossRef, true);
	       	setEnableButtonGroup(published, true);
	        //selectFileButton.setEnabled(false);
	        //clearButton.setEnabled(false);
		    clearDateButton.setEnabled(true);
		    dateButton.setEnabled(true);
		    report_number.setEnabled(true);
		    title.setEnabled(true);
		    author.setEnabled(true);
		    reportDate.setEnabled(true);
		    nopages.setEnabled(true);
	        volNb.setEnabled(true);
		    epaMridNo.setEnabled(true);
		    labName.setEnabled(true);
		    ownerID.setEnabled(true);
		    multOwners.setEnabled(true);
		    city.setEnabled(true);
		    reportNb.setEnabled(true);
		    documentGroup.setEnabled(true);
		    docIdComboBox.setEnabled(true);
		    country.setEnabled(true);
		    glpGepStatus.setEnabled(true);
	        docId.setEnabled(true);

        } 
        else 
        {
            Enumeration confidentialButtons = confidential.getElements();
            while (confidentialButtons.hasMoreElements()) 
            {
                JRadioButton b = (JRadioButton) confidentialButtons.nextElement();
                b.setVisible(true);
            }
            menuItem1.setEnabled(false);
            transferButton.setEnabled(false);
            
		    setEnableButtonGroup(crossRef, false);
	        setEnableButtonGroup(applicant, false);
		    setEnableButtonGroup(published, false);
		    
	        pmraDocNo.setEditable(false);
	        appNo.setEditable(false);
	        
            appNo.setBackground(Color.LIGHT_GRAY);
            pmraDocNo.setBackground(Color.LIGHT_GRAY);	        
	        
	        selectFileButton.setEnabled(false);
	        clearButton.setEnabled(false);
		    clearDateButton.setEnabled(false);
		    dateButton.setEnabled(false);
		    report_number.setEnabled(false);
		    title.setEnabled(false);
		    author.setEnabled(false);
		    reportDate.setEnabled(false);
		    reportDate.setBackground(Color.LIGHT_GRAY);
		    nopages.setEnabled(false);
	        volNb.setEnabled(false);
		    epaMridNo.setEnabled(false);
		    labName.setEnabled(false);
		    city.setEnabled(false);
		    reportNb.setEnabled(false);
		    documentGroup.setEnabled(false);
		    docIdComboBox.setEnabled(false);;
		    country.setEnabled(false);
		    glpGepStatus.setEnabled(false);
	        docId.setEnabled(false);
	        ownerID.setEnabled(false);
	        multOwners.setEnabled(false);
       }
    }
    
   
   

    private SBTextField newTextLine(JPanel panel, String labelTxt, int fieldNb, int textColumns, int x, int y) {

        JLabel l = new JLabel(labelTxt);
        panel.add(l, new GridBagConstraints(x, y, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0,
                        0));

        SBTextField textField = new SBTextField(textColumns);
        textField.addActionListener(new TextFieldListener(textField, /* rowNb, */
        fieldNb));
        textField.addFocusListener(new TextFieldListener(textField, /* rowNb, */
        fieldNb));
        panel.add(textField, new GridBagConstraints(x + 1, y, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        return textField;
    }

    private NumberBox newNumberLine(JPanel panel, String labelTxt, int fieldNb, int textColumns, int x, int y) {

        JLabel l = new JLabel(labelTxt);
        
        panel.add(l, new GridBagConstraints(x, y, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0,
                        0));

        NumberBox textField = new NumberBox(textColumns);
        textField.addActionListener(new TextFieldListener(textField, /* rowNb, */
        fieldNb));
        textField.addFocusListener(new TextFieldListener(textField, /* rowNb, */
        fieldNb));
        panel.add(textField, new GridBagConstraints(x + 1, y, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        return textField;
    }

    private JTextField newNumberMaskLine(JPanel panel, String labelTxt, int fieldNb, int textColumns, int x, int y, String mask, String delimiters) {

        JLabel l = new JLabel(labelTxt);
        panel.add(l, new GridBagConstraints(x, y, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0, 0));

        NumberMaskedField textField = new NumberMaskedField(mask, delimiters, false);
        textField.setAllowSpace(false);
        textField.addActionListener(new TextFieldListener(textField, fieldNb));
        textField.addFocusListener(new TextFieldListener(textField, fieldNb));
        panel.add(textField, new GridBagConstraints(x + 1, y, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(Constants.DETAIL_INTERVAL, 0, Constants.DETAIL_INTERVAL, 10), 0, 0));

        return textField;

    }

    /*
     * private JTextArea newTextArea(JPanel panel, String labelTxt, int rowNb,
     * int fieldNb, int textRows, int textColumns) { JLabel l = new
     * JLabel(labelTxt, JLabel.TRAILING); panel.add(l); JTextArea textArea = new
     * JTextArea("", textRows , textColumns); SubmissionData.IndexEntry entry =
     * SubmissionBuilder.getIndexData().getEntry(rowNb); String entryValue =
     * entry.getValue(fieldNb); textArea.setText(entryValue);
     * textArea.addFocusListener(new TextAreaListener(textArea, fieldNb));
     * 
     * JScrollPane scrollPane = new JScrollPane(textArea);
     * l.setLabelFor(scrollPane); panel.add(scrollPane);
     * 
     * panel.incrementLineCount(); return textArea; }
     */
    private SBComboBox newSelectionLine(JPanel panel, String labelTxt, int fieldNb, boolean isEditable, Vector codes, int x, int y) {
        JLabel l = new JLabel(labelTxt, JLabel.TRAILING);
        panel.add(l, new GridBagConstraints(x, y, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0,
                        0));

        SBComboBox selectionBox;
        if (codes != null) {
            selectionBox = new SBComboBox(codes);
            selectionBox.setEditable(true);
            selectionBox.setEditor(new SBComboBoxEditor(selectionBox));
        } else {
            selectionBox = new SBComboBox();
            selectionBox.setEditable(true);
            selectionBox.setEditor(new SBComboBoxEditor(selectionBox));
        }
        	
        selectionBox.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.LIGHT_GRAY, Color.DARK_GRAY));
        selectionBox.addPopupMenuListener(new SelectFieldListener(selectionBox, fieldNb));
        selectionBox.addFocusListener(new SelectFieldListener(selectionBox, fieldNb));
        selectionBox.addChangeListener(new SelectFieldListener(selectionBox, fieldNb));

        l.setLabelFor(selectionBox);
        panel.add(selectionBox, new GridBagConstraints(x + 1, y, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        return selectionBox;
    }

    /*
     * private JTextField newDateSelectLine(JPanel panel, String labelTxt, int
     * rowNb, int fieldNb) { JLabel l = new JLabel(labelTxt, JLabel.TRAILING);
     * panel.add(l);
     * 
     * JPanel innerPanel = new JPanel(); innerPanel.setLayout(new
     * BoxLayout(innerPanel, BoxLayout.LINE_AXIS));
     * 
     * JTextField dateField = new SBTextField(DATE_FORMAT.format(new Date()));
     * dateField.setEditable(false); SubmissionData.IndexEntry entry =
     * SubmissionBuilder.getIndexData().getEntry(rowNb); String entryValue =
     * entry.getValue(fieldNb); dateField.setText(entryValue);
     * 
     * innerPanel.add(dateField);
     * 
     * JButton b = new JButton("Select Date"); b.addActionListener(new
     * DateListener(dateField, fieldNb));
     * 
     * innerPanel.add(b); panel.add(innerPanel); panel.incrementLineCount();
     * return dateField; }
     */
    private ButtonGroup newRadioLine(JPanel panel, String labelTxt, int fieldNb, int nbOfButtons, String[] labels, int x, int y) {

        return newRadioLine(panel, labelTxt, fieldNb, nbOfButtons, labels, x, y, new String[] { "Y", "N" });
    }

    /*
     * private JTextField newDateSelectLine(JPanel panel, String labelTxt, int
     * rowNb, int fieldNb) { JLabel l = new JLabel(labelTxt, JLabel.TRAILING);
     * panel.add(l);
     * 
     * JPanel innerPanel = new JPanel(); innerPanel.setLayout(new
     * BoxLayout(innerPanel, BoxLayout.LINE_AXIS));
     * 
     * JTextField dateField = new SBTextField(DATE_FORMAT.format(new Date()));
     * dateField.setEditable(false); SubmissionData.IndexEntry entry =
     * SubmissionBuilder.getIndexData().getEntry(rowNb); String entryValue =
     * entry.getValue(fieldNb); dateField.setText(entryValue);
     * 
     * innerPanel.add(dateField);
     * 
     * JButton b = new JButton("Select Date"); b.addActionListener(new
     * DateListener(dateField, fieldNb));
     * 
     * innerPanel.add(b); panel.add(innerPanel); panel.incrementLineCount();
     * return dateField; }
     */
    private ButtonGroup newRadioLine(JPanel panel, String labelTxt, int fieldNb, int nbOfButtons, String[] labels, int x, int y, String[] commands) {

        JLabel l = new JLabel(labelTxt, JLabel.TRAILING);
        panel.add(l, new GridBagConstraints(x, y, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0,
                        0));

        JPanel innerPanel = new JPanel(new GridBagLayout());
        JRadioButton rb;
        ButtonGroup group = new ButtonGroup();

        for (int i = 0; i < nbOfButtons; i++) {
            rb = new JRadioButton(labels[i]);
            rb.setActionCommand(commands[i]);

            rb.addActionListener(new RadioButtonListener(rb, fieldNb));

            group.add(rb);
            innerPanel.add(rb, new GridBagConstraints(i, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 10), 0, 0));
        }

        JRadioButton rbHidden = new JRadioButton();
        rbHidden.setActionCommand("hidden button");
        rbHidden.addActionListener(new RadioButtonListener(rbHidden, fieldNb));
        rbHidden.setFocusable(false);

        group.add(rbHidden);

        panel.add(innerPanel, new GridBagConstraints(x + 1, y, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));

        return group;
    }

    private ButtonGroup newButtonGroup(String labelTxt, int fieldNb, int nbOfButtons, String[] labels) {

        JRadioButton rb;
        ButtonGroup group = new ButtonGroup();

        for (int i = 0; i < nbOfButtons; i++) {
            rb = new JRadioButton(labels[i]);
            if (i == 0) {
                rb.setActionCommand("Y");
            } else {
                rb.setActionCommand("N");
            }

            rb.addActionListener(new RadioButtonListener(rb, fieldNb));

            group.add(rb);
        }

        JRadioButton rbHidden = new JRadioButton();
        rbHidden.setActionCommand("hidden button");
        rbHidden.addActionListener(new RadioButtonListener(rbHidden, fieldNb));
        //rbHidden.setFocusable(false);
        group.add(rbHidden);

        return group;
    }
    
    /*
     * private JTextField newDateSelectLine(JPanel panel, String labelTxt, int
     * rowNb, int fieldNb) { JLabel l = new JLabel(labelTxt, JLabel.TRAILING);
     * panel.add(l);
     * 
     * JPanel innerPanel = new JPanel(); innerPanel.setLayout(new
     * BoxLayout(innerPanel, BoxLayout.LINE_AXIS));
     * 
     * JTextField dateField = new SBTextField(DATE_FORMAT.format(new Date()));
     * dateField.setEditable(false); SubmissionData.IndexEntry entry =
     * SubmissionBuilder.getIndexData().getEntry(rowNb); String entryValue =
     * entry.getValue(fieldNb); dateField.setText(entryValue);
     * 
     * innerPanel.add(dateField);
     * 
     * JButton b = new JButton("Select Date"); b.addActionListener(new
     * DateListener(dateField, fieldNb));
     * 
     * innerPanel.add(b); panel.add(innerPanel); panel.incrementLineCount();
     * return dateField; }
     */
    private ButtonGroup addConfidential(JPanel panel, int x, int y) {
        
        JLabel l = new JLabel(Resources.getString("field.confidential_html"), JLabel.TRAILING);
        panel.add(l, new GridBagConstraints(x, y, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0,
                        0));

        JPanel innerPanel = new JPanel(new GridBagLayout());
        JRadioButton rb;
        ButtonGroup group = new ButtonGroup();

        rb = new JRadioButton(Resources.getString("field.cbi_yes"));
        rb.setActionCommand("Y");
        rb.addActionListener(new RadioButtonListener(rb, IndexEntry.CONFIDENTIAL));
        group.add(rb);
        innerPanel.add(rb, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 5), 0, 0));

        rb = new JRadioButton(Resources.getString("field.cbi_no"));
        rb.setActionCommand("N");
        rb.addActionListener(new RadioButtonListener(rb, IndexEntry.CONFIDENTIAL));
        group.add(rb);
        innerPanel.add(rb, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 5), 0, 0));
	
        rb = new JRadioButton(Resources.getString("field.cbi_partial"));
        rb.setActionCommand("X");
        rb.addActionListener(new RadioButtonListener(rb, IndexEntry.CONFIDENTIAL));
        rb.setFocusable(false);
        group.add(rb);
        innerPanel.add(rb, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 10), 0, 0));

        rb = new JRadioButton(Resources.getString("field.cbi_requestcopy"));
        rb.setActionCommand("C");
        rb.addActionListener(new RadioButtonListener(rb, IndexEntry.CONFIDENTIAL));
        rb.setFocusable(false);
        group.add(rb);
        innerPanel.add(rb, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 10), 0, 0));
       

        rb = new JRadioButton(Resources.getString("field.cbi_noauth"));
        rb.setActionCommand("A");
        rb.addActionListener(new RadioButtonListener(rb, IndexEntry.CONFIDENTIAL));
        rb.setFocusable(false);
        group.add(rb);
        innerPanel.add(rb, new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 10), 0, 0));
        
        //text extra space
       // innerPanel.add(new JLabel(" "), new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 10), 0, 0));
        
        
        
        JRadioButton rbHidden = new JRadioButton();
        rbHidden.setActionCommand("hidden button");
        rbHidden.addActionListener(new RadioButtonListener(rbHidden, IndexEntry.CONFIDENTIAL));
        rbHidden.setFocusable(false);
        group.add(rbHidden);
        //rbHidden.setFocusable(false);

        panel.add(innerPanel, new GridBagConstraints(x + 1, y, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(15, 0, 0, 10), 0, 0));

        return group;
    }

    private void addDocOwner(JPanel details, int x, int y) {
    	//refactored method to add owned by a third party checkbox. bdempsey Jan, 2017
    	
        // owner label and textbox
    	JPanel crossRefPanelLeft = new JPanel(new GridBagLayout());
        
        crossRefPanelLeft.add(new JLabel(Resources.getString("field.madco"), JLabel.TRAILING), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
                new Insets(0, 20, Constants.DETAIL_INTERVAL, 10), 0, 0));  
       
        details.add(crossRefPanelLeft, new GridBagConstraints(x, y, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, 
        		new Insets(20, 0, 40, 0), 0, 0));
        
        
     // owner textbox
        JPanel crossRefPanelRight = new JPanel(new GridBagLayout());
      
        ownerID = new SBTextField(Constants.DETAIL_TEXT_SIZE);
        ownerID.setMaxLen(4);

        ownerID.addActionListener(new TextFieldListener(ownerID, /* rowNb, */ IndexEntry.DOX_MD36));
        ownerID.addFocusListener(new TextFieldListener(ownerID, /* rowNb, */
     		   IndexEntry.DOX_MD36));
         crossRefPanelRight.add( ownerID, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, 
        		 new Insets(0, 0, Constants.DETAIL_INTERVAL, 10), 0, 0));
           
         //owned by a 3rd party checkbox and label
         crossRefPanelRight.add(new JLabel(Resources.getString("field.madcocheck"), JLabel.TRAILING), new GridBagConstraints(1, 0, 1, 1, 0, 2.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                 new Insets(Constants.DETAIL_INTERVAL, 25, 0, 0), 0, 0));
         ownedByThirdParty=new JCheckBox();
         ownedByThirdParty.addActionListener(new CheckBoxNumberListener(ownedByThirdParty, /* rowNb, */
                 IndexEntry.DOX_MD36C));
         ownedByThirdParty.addFocusListener(new CheckBoxNumberListener(ownedByThirdParty, /* rowNb, */
                 IndexEntry.DOX_MD36C));
         crossRefPanelRight.add(ownedByThirdParty, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
        		 new Insets(0, 0, 0, 0), 0, 0));
         
         ActionListener ownedByThirdPartyListener = new ActionListener()
         {
             public void actionPerformed(ActionEvent e) 
             {
             	JCheckBox cb = (JCheckBox) e.getSource();
                 
                 if (cb.isSelected()) 
                 {
                 	madcocode.setVisible(true);
                 } else {
                 	madcocode.setVisible(false);
                 }
             }
         };
         
         ownedByThirdParty.addActionListener(ownedByThirdPartyListener);
         
         details.add(crossRefPanelRight, new GridBagConstraints(x + 1, y, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, 
        		 new Insets(20, 0, 40, 0), 0, 0));
         
         
         // owner label and textbox
     	JPanel panelLeftPlaceHolder = new JPanel(new GridBagLayout());
          
     	panelLeftPlaceHolder.add(new JLabel("", JLabel.TRAILING), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, 
     			GridBagConstraints.HORIZONTAL, new Insets(0, 20, Constants.DETAIL_INTERVAL, 10), 0, 0));  
        
         details.add(panelLeftPlaceHolder, new GridBagConstraints(x, y, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, 
         		new Insets(20, 0, 40, 0), 0, 0));
         
         
         //hiden text area which displays if the Owned by a 3rd party checkbox is checked. This is the TBD message.
         JPanel panelRightMadcoTextArea = new JPanel(new GridBagLayout());
         
         madcocode = new JTextArea(Resources.getString("field.madcocode"));
         madcocode.setFont(new JLabel().getFont());
         madcocode.setLineWrap(false);
         madcocode.setVisible(false);  
         madcocode.setBackground(getBackground());
         
         panelRightMadcoTextArea.add(madcocode, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.HORIZONTAL,
                 new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 0), 0, 0));
         
         details.add(panelRightMadcoTextArea, new GridBagConstraints(x, y, 2, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.HORIZONTAL, 
        		 new Insets(20, 5, 0, 5), 0, 0));
        
         JPanel panelLeft = new JPanel(new GridBagLayout());
        
        
        //crossRefPanelLeft.add(new JLabel(Resources.getString("field.madcocheck"), JLabel.TRAILING), new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
        //        new Insets(Constants.DETAIL_INTERVAL + 0, 10, Constants.DETAIL_INTERVAL, 10), 0, 0));
        //details.add(innerOwner, new GridBagConstraints(x+1, y, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));
        panelLeft.add(new JLabel(Resources.getString("field.mult_owners"), JLabel.TRAILING), new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, 
        		GridBagConstraints.HORIZONTAL, new Insets(0, 20, Constants.DETAIL_INTERVAL, 0), 0, 0)); 
        
        details.add(panelLeft, new GridBagConstraints(x, y, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.HORIZONTAL,
        		new Insets(60, 80, 0, 0), 0, 0));
         
        
        //multiple owners label and checkbox
        JPanel panelRight = new JPanel(new GridBagLayout());
        
        multOwners=new JCheckBox();
        multOwners.addActionListener(new CheckBoxNumberListener(multOwners, /* rowNb, */
                IndexEntry.DOX_MD44));
        multOwners.addFocusListener(new CheckBoxNumberListener(multOwners, /* rowNb, */
                IndexEntry.DOX_MD44));
        panelRight.add(multOwners, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, 
        		new Insets(0, 0, 0, 0), 0, 0));

        details.add(panelRight, new GridBagConstraints(x + 1, y, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
        		new Insets(60, 0, 0, 100), 0, 0));
    
    }
    
    private void addCrossRef(JPanel details, int x, int y) {
        // add labels
        JPanel crossRefPanelLeft = new JPanel(new GridBagLayout());

        crossRefPanelLeft.add(new JLabel(Resources.getString("field.cross_ref_html"), JLabel.TRAILING), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
                new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0, 0));
        crossRefPanelLeft.add(new JLabel(Resources.getString("field.pmra_doc_number"), JLabel.TRAILING), new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
                new Insets(Constants.DETAIL_INTERVAL + 6, 20, Constants.DETAIL_INTERVAL, 10), 0, 0));
       
        
        crossRefPanelLeft.add(new JLabel(Resources.getString("field.app_number"), JLabel.TRAILING), new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
                new Insets(Constants.DETAIL_INTERVAL + 6, 20, Constants.DETAIL_INTERVAL, 10), 0, 0));

        details.add(crossRefPanelLeft, new GridBagConstraints(x, y, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

        // add componnts
        JPanel crossRefPanelRight = new JPanel(new GridBagLayout());

        // add cross
        JPanel innerPanel = new JPanel(new GridBagLayout());
        crossRef = new ButtonGroup();

        for (int i = 0; i < 2; i++) 
        {
            JRadioButton rb;
            if (i == 0) 
            {
                rb = new JRadioButton(Resources.getString("string.yes"));
                rb.setActionCommand("Y");
            } 
            else 
            {
                rb = new JRadioButton(Resources.getString("string.no"));
                rb.setActionCommand("N");
            }

            rb.addActionListener(new RadioButtonListener(rb, IndexEntry.CROSS_REF));

            crossRef.add(rb);
            innerPanel.add(rb, new GridBagConstraints(i, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 5, 0, 10), 0, 0));
        }

        JRadioButton rbHidden = new JRadioButton();
        rbHidden.setActionCommand("");
        rbHidden.addActionListener(new RadioButtonListener(rbHidden, IndexEntry.CROSS_REF));
        rbHidden.setFocusable(false);
        crossRef.add(rbHidden);

        crossRefPanelRight.add(innerPanel, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));

        ActionListener crossRefListener = new ActionListener()
        {
            public void actionPerformed(ActionEvent e) 
            {
                JRadioButton rb = (JRadioButton) e.getSource();
                
                if (rb.isSelected()) 
                {
                    String actionCommand = rb.getActionCommand();
                    
                    if ("Y".equalsIgnoreCase(actionCommand)) 
                    {
                        pmraDocNo.setEditable(true);
                        appNo.setEditable(true);
                        
                        appNo.setBackground(Color.WHITE);
                        pmraDocNo.setBackground(Color.WHITE);

                        // set CIB and APP DER
                        clickButtonGroupSelection(confidential, "N", null);
                        clickButtonGroupSelection(applicant, "N", null);

                        setEnableButtonGroup(confidential, false);
                        setEnableButtonGroup(applicant, false);

                        // reset fileLocation and fileName
                        fileLocation.setText("");
                        fileName.setText("");
                        fileLocation.setBackground(Color.LIGHT_GRAY);
                        fileName.setBackground(Color.LIGHT_GRAY);

                        SubmissionData sd = SubmissionBuilder.getIndexData();
                        IndexEntry entry = sd.getEntry(rowNb);

                        sd.modifyValue(rowNb, IndexEntry.FILELOCATION, "");
                        sd.modifyValue(rowNb, IndexEntry.FILENAME, "");

                        if (entry.getTableColumnNumber(IndexEntry.FILELOCATION) > -1) 
                            table.setCellStringAt("", rowNb, entry.getTableColumnNumber(IndexEntry.FILELOCATION));
                        
                        if (entry.getTableColumnNumber(IndexEntry.FILENAME) > -1)
                            table.setCellStringAt("", rowNb, entry.getTableColumnNumber(IndexEntry.FILENAME));

                        selectFileButton.setEnabled(false);
                        clearButton.setEnabled(false);

                    } 
                    else if ("N".equalsIgnoreCase(actionCommand)) 
                    {
                        pmraDocNo.setText("");
                        pmraDocNo.setEditable(false);

                        // call action listener to change data in adata modle.
                        ActionListener[] ls;
                        ls = pmraDocNo.getActionListeners();
                        
                        if (ls != null) 
                        {
                            for (int i = 0; i < ls.length; i++) 
                                ls[i].actionPerformed(new ActionEvent(pmraDocNo, 0, ""));
                        }

                        appNo.setText("");
                        appNo.setEditable(false);

                        // call action listener to change data in adata modle.
                        ls = appNo.getActionListeners();
                       
                        if (ls != null) 
                        {
                            for (int i = 0; i < ls.length; i++) 
                                ls[i].actionPerformed(new ActionEvent(appNo, 0, ""));
                        }

                        // set CIB and APP DER
                        if( !isButtonGroupEnabled(confidential) )
                        	clickButtonGroupSelection(confidential, null, null);
                        
                        appNo.setBackground(Color.LIGHT_GRAY);
                        pmraDocNo.setBackground(Color.LIGHT_GRAY);                        
                        
                        setEnableButtonGroup(confidential, true);
                        setEnableButtonGroup(applicant, true);

                        SubmissionData data = SubmissionBuilder.getIndexData();
                        IndexEntry entry = data.getEntry(rowNb);
                        String dox_md28 = entry.getValue(IndexEntry.DOX_MD28);
                        
                        if (dox_md28 == null || dox_md28.trim().length() == 0) 
                        {
	                        selectFileButton.setEnabled(true);
        	                clearButton.setEnabled(true);
                            fileLocation.setBackground(Color.LIGHT_GRAY);
                            fileName.setBackground(Color.WHITE);
                        }
                    }
                }
            }
        };

        Enumeration crossRefButtonEnum = crossRef.getElements();
        while (crossRefButtonEnum.hasMoreElements()) 
        {
            JRadioButton rb = (JRadioButton) crossRefButtonEnum.nextElement();
            rb.addActionListener(crossRefListener);
        }

        // add doc no
        pmraDocNo = new SBTextField(Constants.DETAIL_TEXT_SIZE);
        pmraDocNo.setMaxLen(40);

        pmraDocNo.addActionListener(new TextFieldListener(pmraDocNo, /* rowNb, */
        IndexEntry.PMRA_DOC_NO));
        pmraDocNo.addFocusListener(new TextFieldListener(pmraDocNo, /* rowNb, */
        IndexEntry.PMRA_DOC_NO));

        crossRefPanelRight.add(pmraDocNo, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        pmraDocNo.setColumns(15);
        pmraDocNo.setEditable(false);

        // add app no
        appNo = new NumberMaskedField("####-#####", "    -     ", false);
       //appNo.setAllowSpace(false);
        
        appNo.addActionListener(new TextFieldListener(appNo, IndexEntry.APP_NO));
        appNo.addFocusListener(new TextFieldListener(appNo, IndexEntry.APP_NO));
        crossRefPanelRight.add(appNo, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(Constants.DETAIL_INTERVAL, 0, Constants.DETAIL_INTERVAL, 10), 0, 0));

        appNo.setEditable(false);

        details.add(crossRefPanelRight, new GridBagConstraints(x + 1, y, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    }

    private void clickButtonGroupSelection(ButtonGroup bg, String selectionValue, String defaultValue) {

        Enumeration buttons = bg.getElements();

        while (buttons.hasMoreElements()) {

            JRadioButton b1 = (JRadioButton) buttons.nextElement();

            if ((selectionValue != null && selectionValue.equalsIgnoreCase(b1.getActionCommand())) || (defaultValue != null && defaultValue.equalsIgnoreCase(b1.getActionCommand()))) 
            {
                b1.doClick();
                break;
            } 
            else 
            {
                // if the button is the last one in the group, it is hidden button
                if (!buttons.hasMoreElements()) {
                    // for unknow reason, doClick does NOT work. So manualy do
                    // doClick
                    // rbHidden.doClick();

                    ActionListener[] ls = b1.getActionListeners();
                    if (ls != null) 
                    {
                        for (int i = 0; i < ls.length; i++)
                        {
                            ls[i].actionPerformed(new ActionEvent(b1, 0, "hidden button"));
                        }
                    }
                    setButtonGroupSelection(bg, selectionValue, defaultValue);
                }
            }
        }
    }

    private void setButtonGroupSelection(ButtonGroup bg, String selectionValue, String defaultValue) {
        
        Enumeration buttons = bg.getElements();

        while (buttons.hasMoreElements()) {

            JRadioButton b1 = (JRadioButton) buttons.nextElement();

            if ((selectionValue != null && selectionValue.equalsIgnoreCase(b1.getActionCommand())) || (defaultValue != null && defaultValue.equalsIgnoreCase(b1.getActionCommand()))) {
                b1.setSelected(true);
                break;
            } else {
                // if the button is the last one in the group, it is hidden button
                if (!buttons.hasMoreElements()) {
                    b1.setSelected(true);
                }
            }
        }
    }
        
    private void setEnableButtonGroup(ButtonGroup bg, boolean enable) {

        Enumeration buttons = bg.getElements();
        while (buttons.hasMoreElements()) {
            JRadioButton b1 = (JRadioButton) buttons.nextElement();
            b1.setEnabled(enable);
        }
    }
    private boolean isButtonGroupEnabled(ButtonGroup bg)
    {
    	boolean isEnabled = false;
    	
        Enumeration buttons = bg.getElements();
        while (buttons.hasMoreElements()) {
            JRadioButton b1 = (JRadioButton) buttons.nextElement();
            if(b1.isEnabled())
            	isEnabled = b1.isEnabled();
        }
    	
    	return isEnabled;
    }
    

    private void addDetailsFilePanel(JPanel panel, int x, int y) {

        // create file name

        // create file name label
        JLabel dfnLabel = new JLabel(Resources.getString("field.filename"), JLabel.TRAILING);
        panel.add(dfnLabel, new GridBagConstraints(x, y, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
                new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL, 10), 0, 0));

        JPanel dfnPanel = new JPanel(new GridBagLayout());

        // create file name
        fileName = new SBTextField(Constants.DETAIL_TEXT_SIZE);
        fileName.setEditable(false);

        // create file name
        fileName = new DisableTextField(Constants.DETAIL_TEXT_SIZE);

        // get mon-editable color and set it for fileLocation
        SBTextField tmpTextField1 = new SBTextField();
        tmpTextField1.setEditable(false);
        //Color fileNameColor = tmpTextField1.getBackground();
        // The same color doesn't work. Don't know why
        //fileNameColor = new Color(fileNameColor.getRed() + 1, fileNameColor.getGreen() + 1, fileNameColor.getBlue() + 1);
        fileName.setBackground(Color.LIGHT_GRAY);

        fileName.addActionListener(new TextFieldListener(fileName, /* rowNb, */
        IndexEntry.FILENAME));
        fileName.addFocusListener(new TextFieldListener(fileName, /* rowNb, */
        IndexEntry.FILENAME));
        dfnPanel.add(fileName, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));

        // browse button
        selectFileButton = new JButton(Resources.getString("field.browse"));
        dfnPanel.add(selectFileButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

        // Code for CLEAR BUTTON - added by Damithri - Oct 25th,
        // 2005***********************

        // clear button
        clearButton = new JButton(Resources.getString("field.clear"));
        dfnPanel.add(clearButton, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

        // End code for CLEAR BUTTON******************

        panel.add(dfnPanel, new GridBagConstraints(x + 1, y, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        // create file loaction

        // create file location label
        JLabel dflLabel = new JLabel(Resources.getString("field.filelocation"), JLabel.TRAILING);
        panel.add(dflLabel, new GridBagConstraints(x + 2, y, 1, 1, 0.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL, new Insets(Constants.DETAIL_INTERVAL, 20, Constants.DETAIL_INTERVAL,
                10), 0, 0));

        // create file name
        fileLocation = new DisableTextField(Constants.DETAIL_TEXT_SIZE);

        // get mon-editable color and set it for fileLocation
        SBTextField tmpTextField2 = new SBTextField();
        tmpTextField2.setEditable(false);
        //Color fileLocationColor = tmpTextField2.getBackground();
        // The same color doesn't work. Don't know why
        //fileLocationColor = new Color(fileLocationColor.getRed() + 1, fileLocationColor.getGreen() + 1, fileLocationColor.getBlue() + 1);
        fileLocation.setBackground(Color.LIGHT_GRAY);

        fileLocation.addActionListener(new TextFieldListener(fileLocation, /* rowNb, */
        IndexEntry.FILELOCATION));
        fileLocation.addFocusListener(new TextFieldListener(fileLocation, /* rowNb, */
        IndexEntry.FILELOCATION));

        panel.add(fileLocation, new GridBagConstraints(x + 3, y, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(Constants.DETAIL_INTERVAL, 0,
                Constants.DETAIL_INTERVAL, 10), 0, 0));

        BrowseFileListener listener = new BrowseFileListener(IndexEntry.FILELOCATION, IndexEntry.FILENAME);
        fileLocation.addFocusListener(listener);
        fileName.addFocusListener(listener);
        selectFileButton.addActionListener(listener);

        // CLEAR BUTTON CODE - Added by Damithri - Oct 25th,
        // 2005***********************
        ClearButtonListener listener_clear = new ClearButtonListener(IndexEntry.FILELOCATION, IndexEntry.FILENAME);
        clearButton.addActionListener(listener_clear);

        // END CLEAR BUTTON Code******************

    }

    /**
     * Makes the Document Id selection panel.
     */
    private JPanel docIdPanel(int fieldNb, Vector codes) {

        // We need an inner pane
        JPanel innerPane = new JPanel(new GridBagLayout());
        // And we set for it a border
        innerPane.setBorder(BorderFactory.createLineBorder(Color.black));

        // This is the area where we show the selections made
        // This is the list of user added Selections from the code
        docId = new JList(new DefaultListModel());

        // docId.setFont(selectDocIdFont);
        // docId.setFixedCellHeight(Constants.DETAILS_MONOSPACE_FONT_SIZE + 4);
        // docId.setVisibleRowCount(Constants.DETAIL_PRODID_ROWS);
        docId.setVisibleRowCount(3);

        docId.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        DocIdListListener listener = new DocIdListListener();
        docId.addKeyListener(listener);
        docId.addMouseListener(listener);
        docId.addFocusListener(listener);

        // SubmissionData.IndexEntry entry =
        // SubmissionBuilder.getIndexData().getEntry(rowNb);

        // selection is a string made of comma separated codes
        DefaultListModel lm = (DefaultListModel) docId.getModel();
        String[] entryCodes = docIdStr.split(",");
        
        if (entryCodes.length > 0) {
            String ret = makeDocIdLine(entryCodes[0]);
            
            if (ret.length() > 0) {
                lm.addElement(ret);
            }
            
            
            for (int i = 1; i < entryCodes.length; i++) {
                ret = makeDocIdLine(entryCodes[i]);
                lm.addElement(ret);
            }
        }
        // JScrollPane scrollPane = new JScrollPane(docId,
        // JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
        // JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        JScrollPane scrollPane = new JScrollPane(docId);
        //scrollPane.setFocusable(false);
        scrollPane.setPreferredSize(new Dimension(10, 10));
        innerPane.add(scrollPane, new GridBagConstraints(0, 0, 1, 1, 1.0, 2.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));

        // This is how the selections are done
        Vector selectionList = new Vector();
        String line;
        
        if (codes != null) {
            for (int i = 0; i < codes.size(); i++) {
                line = makeDocIdLine((String) codes.get(i));
                if (line != null && line.trim().length() > 0) {
                    // if (line.trim().length() > 41)
                    // selectionList.add(line.trim().substring(0, 40));
                    // else
                    selectionList.add(line.trim());
                }
            }
            docIdComboBox = new SBComboBox(selectionList);
            docIdComboBox.setEditable(true);
            docIdComboBox.setEditor(new SBComboBoxEditor(docIdComboBox));
            docIdComboBox.setPreferredSize(new Dimension(20, 20));
        } else {
            docIdComboBox = new SBComboBox();
            docIdComboBox.setEditable(true);
            docIdComboBox.setEditor(new SBComboBoxEditor(docIdComboBox));
            docIdComboBox.setPreferredSize(new Dimension(20, 20));
        }
        
        // docIdComboBox.setFont();
        SelectDocIdListener docIdListener = new SelectDocIdListener();
        docIdComboBox.addItemListener(docIdListener);
        docIdComboBox.addPopupMenuListener(docIdListener);

        ((JTextField) docIdComboBox.getEditor().getEditorComponent()).setColumns(Constants.DETAIL_TEXT_SIZE);
        (docIdComboBox.getEditor().getEditorComponent()).addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                if (e.getOppositeComponent() != docId) {
                    docId.getSelectionModel().clearSelection();
                }
            }
        });

        //Add a transfer button
          transferButton = new JButton(Resources.getString("string.addselected"));
         	innerPane.add(transferButton, new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0,
				GridBagConstraints.SOUTH, GridBagConstraints.CENTER, new Insets(
						2, 2, 2, 2), 0, 0));
         	transferButton.addActionListener(new SelectionTranfer());
	
        //This is the list from which the selections are made
        itemSelectionList = new JList(selectionList);
        itemSelectionList.setVisibleRowCount(3);
        itemSelectionList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        itemSelectionList.addKeyListener(new ListKeyboardSearcher(itemSelectionList));
        
        JScrollPane selectionListSscrollPane = new JScrollPane(itemSelectionList);
        selectionListSscrollPane.setFocusable(true);
        selectionListSscrollPane.setPreferredSize(new Dimension(10, 10));
        
        innerPane.add(selectionListSscrollPane, new GridBagConstraints(0, 2, 1, 1, 1.0, 2.5, GridBagConstraints.SOUTH, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
        
        
        //innerPane.add(docIdComboBox, new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0, GridBagConstraints.SOUTH, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 2), 0, 0));

        return innerPane;
    }

    private String makeDocIdLine(String key) {
    	
        if (key == null || key.length() == 0) {
            return "";
        }
        String line = key;

        //used to handle spaces in the codes
        if(line.indexOf('$') != -1)
        	line = line.replace('$', ' ');
        else if(key.indexOf(' ') != -1 && !key.startsWith("--"))
        	key = key.replace(' ', '$').trim();
        
        if (line.length() > Constants.DETAILS_MAX_CODE_STRING) 
            line += "   "; // add 3 spaces if the code is longer
        
        String codeDescription = null;
        
        //Get the code description from standard or expired codes
        try 
        {
    	   codeDescription = Resources.getCodeDescription(SubmissionBuilder.getCodingStandardInt(), key);
        }
       	catch (java.util.MissingResourceException ex)
        {
       		if(codeDescription==null)
       		{
       			try
       			{
	       			codeDescription = Resources.getCodeDescription(Constants.CODING_EXPIREDDACO, key);
       			}
       			catch (java.util.MissingResourceException exp)
       			{
       				codeDescription = null;
       				line="";
       			}
       		}	
       		else
       		{
       			return new String();
       		}
        }
       	
       	if(codeDescription!=null && line.trim().compareTo(codeDescription.trim())!=0)  
           	line += "      "+codeDescription;
       	
        return line;
    }

    /**
	 * Constructs a code number line
	 * 
	 * @param key
	 *            a string representing the DACO code
	 */
	public String makeDocIdLines(String key) {
		return this.makeDocIdLine(key);
	}
    
	
	/**
	 * The SelectionTranfer class handles the action of sending selected
	 * numbering codes to the upper list.
	 * 
	 * @author kokou ahadjitse
	 * 
	 */
	class SelectionTranfer implements ActionListener 
	{
		boolean bFound = false;
		String fisrtEntry  = null;
		boolean bAlreadySelected = false;

	    //----------------------------------------------------------------------------
	    //March 2011 for unique 0.* code  
	    //added in:
		String UNIQUE_REGEX = "^0\\.|,0\\.";
	    //-----------------------------------------------------------------------------		
		/**
		 * Process the selected list elements.
		 * @param e	the action event  that is fired. 
		 */
		public void actionPerformed(ActionEvent e) 
		{
			int selectedIndices[] = itemSelectionList.getSelectedIndices();
			ListModel lmItemSelectionList = (ListModel) itemSelectionList.getModel();
			fisrtEntry = (String) lmItemSelectionList.getElementAt(0);
			
		    //----------------------------------------------------------------------------
		    //March 2011 for unique 0.* code  
		    //added in:
			
			boolean bIncludeUniqueCode = false;
            Pattern pattern = Pattern.compile(UNIQUE_REGEX);
            Matcher matcher; 
            String codes[] = new String[selectedIndices.length];
            String warningString = "\t" + 
            	Resources.getString("message.unique.error") + "\n";
			for (int index = 0; index < selectedIndices.length; index++)
			{
				codes[index] = 
					(String) Resources.getCodes(SubmissionBuilder.getCodingStandardInt(), Resources.CODES)
						.get(selectedIndices[index]);
				matcher = pattern.matcher(codes[index]);
				if (matcher.find()) bIncludeUniqueCode = true;
			}
			
			if (bIncludeUniqueCode)
			{
				if (!(codes.length > 1 || !docIdStr.equals("")))
					bIncludeUniqueCode = false;
			} 
			else
			{
				matcher = pattern.matcher(docIdStr);
				if (matcher.find()) bIncludeUniqueCode = true;
			}
			
			if (bIncludeUniqueCode) {
				JOptionPane.showMessageDialog(
						SubmissionBuilder.getAppFrame(), 
						warningString, 
						Resources.getString("unique.dialog.title", Resources.getString("app.name")), 
						JOptionPane.WARNING_MESSAGE
					);
				return;
			}
		    //-----------------------------------------------------------------------------		

			for (int index = 0; index < selectedIndices.length; index++) 
			{
				String code = null;
				StringTokenizer st = null;

				code = (String) Resources.getCodes(SubmissionBuilder.getCodingStandardInt(), Resources.CODES).get(selectedIndices[index]);
				
				//Prevent the first entry prompting for selection to be added
				if (!code.equalsIgnoreCase(fisrtEntry)) 
				{
					st = new StringTokenizer(docIdStr, ",");
		
					//If the element has already been added, discard
					bAlreadySelected = false;
					while (st.hasMoreElements()) 
					{
						String s = st.nextToken();
						
						if(code.indexOf("$") != -1)
							code = code.replace('$', ' ');
						
						if (s.equals(code)) 
						{
							bAlreadySelected = true;
							Resources.getString("table.head.docid");
		            		warningString = "\t" + Resources.getString("duplicate.docid.added",code) + "\n";
	                		JOptionPane.showMessageDialog(SubmissionBuilder.getAppFrame(), warningString, Resources.getString("validation.box.title", Resources.getString("app.name")), JOptionPane.WARNING_MESSAGE);		            								
						}
					}
	
					if (!bAlreadySelected) 
					{
							if (docIdStr.length() != 0) 
								docIdStr += ",";
	
							docIdStr += code;
					}
	
					bFound = false;
					for (int charIndex = 0; charIndex < code.length(); charIndex++)
					{
						if (code.charAt(charIndex) == '_') 
							bFound = true;
					}
	
					// Add to the list only if the element has not been added and if not the select indication string
					if ( (!bFound)  && !( bAlreadySelected) && !(code.equalsIgnoreCase(fisrtEntry) ))
					{
						
						
						DefaultListModel lm = (DefaultListModel) docId.getModel();
						lm.addElement(makeDocIdLine(code));
	
						SubmissionData sd = SubmissionBuilder.getIndexData();
						IndexEntry entry = sd.getEntry(rowNb);
						//Updated Aug 11 For ADR0156
						/*boolean isDaco2to12=Utils.isDacoCodeBetween2And12(code);
						if(isDaco2to12==true){
							String confidentialValue=entry.getValue(IndexEntry.CONFIDENTIAL);
							if(confidentialValue==null ||confidentialValue.length()==0){
								//update data
								sd.modifyValue(rowNb, IndexEntry.CONFIDENTIAL, _NO);
								//update table
								table.setCellStringAt(_NO, rowNb, entry.getTableColumnNumber(IndexEntry.CONFIDENTIAL));
								//set ui
								setButtonGroupSelection(confidential,String.valueOf(rowNb), _NO);
							}
							String derValue=entry.getValue(IndexEntry.APPLICANT_DER);
							if(derValue==null ||derValue.length()==0){
								//update data
								sd.modifyValue(rowNb, IndexEntry.APPLICANT_DER, _NO);
								//update table UI
								table.setCellStringAt(_NO, rowNb, entry.getTableColumnNumber(IndexEntry.APPLICANT_DER));
								//set ui
								setButtonGroupSelection(applicant,String.valueOf(rowNb), _NO);
							}
							
						
						}*/
						if(docIdStr.indexOf("$") != -1)
							docIdStr = docIdStr.replace('$', ' ');
						
						sd.modifyValue(rowNb, IndexEntry.DOCID, docIdStr);
	
						if (entry.getTableColumnNumber(IndexEntry.DOCID) > -1) 
						{
							//table.setCellStringAt(docIdStr.replaceAll(",", ", "), rowNb, entry.getTableColumnNumber(IndexEntry.DOCID));
							table.setCellStringAt(docIdStr, rowNb, entry.getTableColumnNumber(IndexEntry.DOCID));
						}
					}
				}//if (!code.equalsIgnoreCase(fisrtEntry))
			}//for			
		}
	}
      
 /**
	 * ListKeyboardSearcher is the class for handling the position of the DACO
	 * number list elements based on the keyboard input.
	 * <p>
	 * 
	 * @author kokou Aahadjitse
	 * 
	 */
	class ListKeyboardSearcher extends KeyAdapter {
		public int pauseTime = 10000;

		protected JList list;

		protected ListModel model;

		protected String key = "";

		protected long theTime = 0;

		/**
		 * Class constructor with a list to act on
		 */
		public ListKeyboardSearcher(JList list) {

			list = list;
			model = list.getModel();

		}

		/**
		 * Process the keyboard input to position the list selection on the user input.
		 * 
		 * @param e
		 *            the keyboard event
		 */
		public void keyPressed(KeyEvent e) 
		{
			char ch = e.getKeyChar();

			if (theTime + pauseTime < System.currentTimeMillis())
				key = "";
			theTime = System.currentTimeMillis();

			key += Character.toLowerCase(ch);
			for (int i = 0; i < model.getSize(); i++) 
			{
				String str = ((String) model.getElementAt(i)).toLowerCase();

				if (str.startsWith(key)) 
				{
					if(list!=null)
					{
						list.setSelectedIndex(i);
						list.ensureIndexIsVisible(i);
						break;					
					}
				}
			}
		}
	}
}