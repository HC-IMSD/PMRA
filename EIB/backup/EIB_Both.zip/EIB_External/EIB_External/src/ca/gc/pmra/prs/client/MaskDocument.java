package ca.gc.pmra.prs.client;

import java.util.ArrayList;

import javax.swing.event.DocumentEvent;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

/**
 * Mask document object used for <code>ECTextBox</code> control.
 */
public class MaskDocument extends PlainDocument {
    private boolean allowSpace = true;

    private String mask;

    private String origMask;

    private String delims;

    private ArrayList delimsArr;

    //Reserved characters for the mask.
    private final char UPPER_CASE_ALPHA = 'A';

    private final char LOWER_CASE_ALPHA = 'a';

    private final char NUMBER = '#';

    private final char ANY_CHARACTER = '!';

    /**
     * Constructor used to create a custom mask that has not been created as a predetermined mask.
     * 
     * @param maskVlu
     *            the mask to be used including the special characters such as 'A', 'a', '#' and '!'.
     * @param delimiters
     *            the mask without the special characters. The special characters have to be replaced by spaces.
     * @param showAll
     *            <code>false</code> to display only the delimiters, <code>true</code> to show the special characters.
     */
    public MaskDocument(String maskVlu, String delimiters, boolean showAll) {
        setupMask(maskVlu, delimiters, showAll);
    }

    /**
     * set whether or not allow input space
     * 
     * @param allow
     *            true - allow input space, otherwise not.
     */
    public void setAllowSpace(boolean allow) {
        allowSpace = allow;
    }

    /**
     * check whether or not allow input space
     * 
     * @return true - allow input space, otherwise not.
     */
    public boolean isAllowSpace() {
        return allowSpace;
    }

    /**
     * Initializes the mask.
     */
    private void setupMask(String maskVlu, String delimiters, boolean showAll) {
        //Setup the delimiters array that will be used
        //to check the next position of the caret.
        delimsArr = new ArrayList();
        setupDelimiters(maskVlu, delimiters);

        delims = delimiters;
        origMask = maskVlu;
        mask = maskVlu;

        //Validate for correct format of the mask.
        try {
            validateMask(maskVlu, delimiters);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        //If false, strip the special characters out so that
        //only the delimiters will be seen.
        if (!showAll) {
            mask = stripNonDelimiterChars(maskVlu);
        }

        try {
            super.insertString(0, mask, null);
        } catch (BadLocationException be) {
            be.printStackTrace();
        }
    }

    /**
     * Formats the mask so that only the delimiters are displayed.
     * 
     * @param mask
     *            the unformated mask.
     * @return Formated mask.
     */
    private String stripNonDelimiterChars(String mask) {
        StringBuffer retVlu = new StringBuffer("");

        //Remove all characters from the mask except
        //for the delimiters.
        for (int cnt = 0; cnt < mask.length(); cnt++) {
            if (delims.charAt(cnt) == mask.charAt(cnt)) {
                retVlu.append(String.valueOf(delims.charAt(cnt)));
            } else {
                retVlu.append(" ");
            }
        }
        return retVlu.toString();
    }

    /**
     * Places the delimiters into a ArrayList at their respective positions.
     * 
     * @param maskVlu
     *            the mask.
     * @param delimiters
     *            the delimiters
     */
    private void setupDelimiters(String maskVlu, String delimiters) {
        char delimChar;
        char maskChar;

        //Place null if the character is not a delimiter and
        //the delimiter value if the character is a delimiter
        //into the ArrayList. This is to make it easier to calculate
        //positions for the caret based on if the value is null or not.
        for (int cnt = 0; cnt < maskVlu.length(); cnt++) {
            delimChar = delimiters.charAt(cnt);
            maskChar = maskVlu.charAt(cnt);
            if (delimChar == maskChar) {
                delimsArr.add(String.valueOf(delimChar));
            } else {
                delimsArr.add(null);
            }
        }
    }

    /**
     * The purpose of this method is only for developers. It is here to validate if the mask and delimiter arguments are being used properly.
     */
    private void validateMask(String maskVlu, String delimiters) throws Exception {

        if (maskVlu.length() != delimiters.length()) {
            //The Mask and Delimiter length must match.
        }

        if (!stripNonDelimiterChars(origMask).equals(delimiters)) {
            // Mask and Delimiters don't match.
        }

        //Validate that all the characters used are
        //valid characters that have been predetermined
        //by this class.
        for (int cnt = 0; cnt < origMask.length(); cnt++) {
            if (origMask.charAt(cnt) != delims.charAt(cnt) && origMask.charAt(cnt) != UPPER_CASE_ALPHA && origMask.charAt(cnt) != LOWER_CASE_ALPHA && origMask.charAt(cnt) != NUMBER
                    && origMask.charAt(cnt) != this.ANY_CHARACTER) {
                // Invalid character used in mask.
            }
        }
    }

    /**
     * Validates if the character at the position sent is a valid one based on the reserved characters.
     * 
     * @param charVlu
     *            the character to be validated against the mask
     * @param pos
     *            the position within the mask to be validated.
     * @return <code>true</code> if the validation passes. <code>false</code> otherwise.
     */
    private boolean validateChar(char charVlu, int pos) {
        boolean rslt = false;

        //Validate the character based on the mask.
        switch (origMask.charAt(pos)) {
        //Character has to be alpha character only from a to z.
        case UPPER_CASE_ALPHA:
            if (!Character.isDigit(charVlu) && ((charVlu >= 'A' && charVlu <= 'Z') || (charVlu >= 'a' && charVlu <= 'z'))) {
                rslt = true;
            }
            break;
        //Character has to be alpha character only from a to z.
        case LOWER_CASE_ALPHA:
            if (!Character.isDigit(charVlu) && ((charVlu >= 'A' && charVlu <= 'Z') || (charVlu >= 'a' && charVlu <= 'z'))) {
                rslt = true;
            }
            break;
        //Can only be a number.
        case NUMBER:
            if (charVlu == ' ') {
                if (allowSpace) {
                    rslt = true;
                } else {
                    rslt = false;
                }
            } else {
                rslt = Character.isDigit(charVlu);
            }
            break;
        case ANY_CHARACTER:
            rslt = true;
            break;
        }
        return rslt;
    }

    /**
     * Formats the character to be what it is expected based on the mask set.
     * 
     * @return char The formatted character.
     */
    private char formatChar(char charVlu, int pos) {
        String vlu = String.valueOf(charVlu);
        char retVlu = charVlu;

        switch (origMask.charAt(pos)) {
        case UPPER_CASE_ALPHA:
            retVlu = vlu.toUpperCase().charAt(0);
            break;
        case LOWER_CASE_ALPHA:
            retVlu = vlu.toLowerCase().charAt(0);
            break;
        }
        return retVlu;
    }

    /**
     * Calculates where the caret should be in a field based on the mask set. This is so that the cursor is not placed at a delimiter.
     * 
     * @param currCarotPos
     *            the current position of the cursor.
     * @param forward
     *            <code>true</code> will check for the next valid position, <code>false</code>, will check for the previous valid position.
     * @return the next appropriate position in the mask.
     */
    public int getNextCarotPosition(int currCarotPos, boolean forward) {
        int i;

        if (forward) {
            i = currCarotPos + 1;

            //Check for the next valid position that is
            //not on a delimiter.
            while (i < delimsArr.size()) {
                if (delimsArr.get(i) == null) {
                    currCarotPos = i;
                    break;
                }
                i++;
            }
        } else {
            i = currCarotPos - 1;

            //Check for the next valid position that is
            //not on a delimiter that is before the
            //current position.
            while (i >= 0) {
                if (delimsArr.get(i) == null) {
                    currCarotPos = i;
                    break;
                }
                i--;
            }
        }

        //Return the position the cursor
        //should go to.
        return currCarotPos;
    }

    /**
     * Checks if the character at the position passed in is a delimiter or not.
     * 
     * @param pos
     *            the position the cursor is currently at.
     * @return <code>true</code> if the character at the position passed in is a delimiter.
     */
    public boolean isDelimiter(int pos) {
        if (delimsArr.size() > pos && delimsArr.get(pos) != null)
            return true;

        return false;
    }

    /**
     * Checks if the character passed in is a delimiter or not.
     * 
     * @param pos
     *            the position the cursor is currently at.
     * @return <code>true</code> if the character is a delimiter within the mask.
     */
    public boolean isDelimiter(String delim) {
        return delimsArr.contains(delim);
    }

    /**
     * Returns the next position of the delimiter passed in after the position specified.
     * 
     * @param delim
     *            the delimiter to test for.
     * @param pos
     *            the position in the mask to search after.
     * @return the position of the delimiter
     */
    public int getDelimPos(String delim, int pos) {
        for (int i = pos; i < delimsArr.size(); i++) {
            if (delim.equals(String.valueOf(delimsArr.get(i))))
                return i;
        }
        return pos;
    }

    /**
     * Handles the string validation before allowing the value of the JTExtBox to be modified.
     */
    public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
        //Don't allow the fields mask to be erased.
        if (str == null || str.length() == 0) {
            //Set the mask.
            super.remove(offs, getLength());
            super.insertString(offs, mask, a);
            return;
        }

        if (offs >= mask.length()) {
            return;
        }

        //The user is typing in the field.
        if (str.length() == 1) {
            //Check to see if we need to jump after the delimiter
            //if the current character being typed in is a delimiter.
            if (isDelimiter(str)) {
                //get the position of the dellimiter.
                int delimPos = getDelimPos(str, offs);
                if (delimPos > offs) {
                    //Set the text so that the cursor places itself at
                    //the appropriate place.
                    String vlu = getText(offs, (delimPos - offs) + 1);
                    super.remove(offs, vlu.length());
                    super.insertString(offs, vlu, a);

                    return;
                }
            }

            //Make sure the character typed in matches
            //the type expected from the mask.
            if (!validateChar(str.charAt(0), offs)) {
                return;
            }

            StringBuffer vlu = new StringBuffer("");
            char currChar = str.charAt(0);

            //Don't allow the cursor to be placed on a delimiter.
            if (offs + 1 < mask.length() && isDelimiter(offs + 1)) {
                int nxtPos = getNextCarotPosition(offs, true);

                for (int i = offs + 1; i < nxtPos; i++) {
                    vlu.append(delimsArr.get(i));
                }
            }

            //Format the character being inserted so that
            //it is the right case etc...
            currChar = formatChar(str.charAt(0), offs);

            //Build the value to be placed in the field.
            str = String.valueOf(currChar) + vlu.toString();

            //Remove the characters so that they can
            //be replaced.
            super.remove(offs, str.length());

            //Place the formated text in the field.
            super.insertString(offs, str, a);

        } else if (str.length() == 0) {
            return;
        } else {
            //Value being pasted since there is
            //more than 1 character in the string.
            if (!validateString(str, offs)) {
                return;
            }

            //Format the string based on the mask.
            str = formatString(str, offs);

            //Remove the characters so that they can
            //be replaced with the formated string.
            super.remove(offs, str.length());

            //Populate the field with the formated
            //information.
            super.insertString(offs, str, a);
        }
    }

    /**
     * Validates a string based on the maks set.
     * 
     * @param vlu
     *            the string to be validated.
     * @@param pos the position the cursor is at in the field.
     * @return <code>true</code> if the string passed the validation based on the mask.
     */
    private boolean validateString(String vlu, int pos) {
        ArrayList validateList = (ArrayList) delimsArr.clone();
        int stringPos = 0;

        //If the length of the string is greater than the
        //mask, we know that the value is not valid.
        if (vlu.length() > delimsArr.size())
            return false;

        for (int cnt = pos; cnt < delimsArr.size(); cnt++) {

            if (delimsArr.get(cnt) == null && !validateChar(vlu.charAt(stringPos), cnt)) {
                return false;
            } else if (delimsArr.get(cnt) == null && validateChar(vlu.charAt(stringPos), cnt)) {
                stringPos++;
            } else if (delimsArr.get(cnt) != null && vlu.charAt(stringPos) == String.valueOf(delimsArr.get(cnt)).charAt(0)) {
                stringPos++;
            }

            if (stringPos >= vlu.length())
                break;
        }
        return true;
    }

    /**
     * Formats a string based on the maks set.
     * 
     * @param vlu
     *            the string to be validated.
     * @@param pos the position the cursor is at in the field.
     * @return the formated value of the <code>String</code> passed in.
     */
    private String formatString(String vlu, int pos) {
        StringBuffer retVlu = new StringBuffer("");
        int strCnt = 0;
        for (int cnt = pos; cnt < delimsArr.size(); cnt++) {
            if (delimsArr.get(cnt) == null) {
                retVlu.append(formatChar(vlu.charAt(strCnt), cnt));
                strCnt++;
            } else if (delimsArr.get(cnt).toString().equals(String.valueOf(vlu.charAt(strCnt)))) {
                retVlu.append(delimsArr.get(cnt).toString());
                strCnt++;
            } else {
                retVlu.append(delimsArr.get(cnt).toString());
            }
            if (strCnt >= vlu.length())
                break;
        }

        return retVlu.toString();
    }

    /**
     * Returns the mask value being set to the field.
     * 
     * @return the mask.
     */
    public String getMask() {
        return mask;
    }

    /**
     * Handles the removal of characters in the field.
     */
    public void remove(int offs, int len) throws BadLocationException {

        if (isDelimiter(offs)) {
            int newOffs = getNextCarotPosition(offs, false);

            len = offs - newOffs + len;
            offs = newOffs;
        }

        String value = mask.substring(offs, offs + len);

        super.remove(offs, len);
        super.insertString(offs, value, null);

        fireRemoveUpdate(new AbstractDocument.DefaultDocumentEvent(offs, len, DocumentEvent.EventType.REMOVE));

    }

    /**
     * Returns the value passed in without the delimiters.
     * 
     * @param str
     *            the string which contains the delimiters.
     * @return the <code>String</code> without the delimiters in it.
     */
    public String stripDelims(String str) {

        StringBuffer retString = new StringBuffer("");
        for (int i = 0; i < delimsArr.size(); i++) {
            if (delimsArr.get(i) == null) {
                if (str != null && str.length() > i)
                    retString.append(str.charAt(i));
                else
                    retString.append(" ");
            }
        }
        return retString.toString();
    }
}